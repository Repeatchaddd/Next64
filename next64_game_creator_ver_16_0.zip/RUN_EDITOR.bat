@echo off
cd /d "%~dp0"
python next64_game_creator.py
if errorlevel 1 (
  echo.
  echo Could not start the editor.
  echo Make sure Python 3 is installed and available in PATH.
  pause
)
