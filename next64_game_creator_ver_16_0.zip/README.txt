Next64 Studios C64 Game Creator VER 16.0

VER 16.0 Next64 Studio editor theme
------------------------------------
- Redesigned the full editor to match the branded startup artwork.
- Added a dark navy workspace, layered blue panels, cyan highlights, lavender pressed states, and restrained red warning accents.
- Added a compact NEXT64 STUDIOS command header and prominent blue Build PRG action.
- Restyled tabs, buttons, inputs, checkboxes, radio buttons, group panels, tables, scrollbars, menus, lists, text logs, and the status bar.
- Improved selection and focus visibility throughout the editor with consistent cyan and blue states.
- Preserved authentic project-defined C64 colors in sprite, tile, room, and Test Play canvases.
- The theme is centralized so newly added ttk controls inherit the same appearance automatically.

VER 15.1 branded startup splash screen
---------------------------------------
- Added the new Next64 Studios C64 Game Creator splash artwork.
- The borderless splash is centered and shown while the editor initializes.
- The main workspace stays hidden until initialization is complete, preventing startup window flashing.
- The splash remains visible for at least 1.6 seconds and then closes automatically.
- A lightweight text fallback is used if Pillow or the bundled image cannot be loaded.
- The version-neutral artwork is bundled at assets/next64_splash.png for reuse in future releases.

VER 15.0 camera and scrolling-room support
------------------------------------------
- Rooms can now be 320-512 pixels wide and 200-256 pixels high in 8-pixel steps.
- Room Properties includes world width and height controls.
- Each room has a fixed or follow camera, target object ID, and initial X/Y position.
- The room editor scales to the complete world and outlines the 320x200 C64 viewport in yellow.
- Tiles, objects, reusable instances, and player starts use world coordinates across the larger room.
- Generated C64 games maintain world coordinates for logic/collision while rendering camera-relative sprites.
- Follow cameras center on their target, clamp at world edges, and scroll in tile-aligned 8-pixel steps.
- Tile maps now export at the room's full dimensions; visible 40x25 cells are selected from the camera position.
- Camera state is refreshed after room changes and save-game loads.
- Existing 320x200 projects migrate as fixed-camera rooms without behavioral changes.
- C64 scrolling rooms currently require 8x8 tiles. The validator reports incompatible tile dimensions.

VER 14.1 save-game compile fix
--------------------------------
- Fixed generated_save.asm header validation when larger save payloads pushed
  SaveGameBadData beyond the 6502 relative-branch range.
- Save-game magic/version checks now use local branches plus absolute jumps,
  so generated projects compile regardless of the enabled save-state fields.

VER 14.0 reusable UI/HUD system
- New UI / HUD editor tab with reusable named layouts.
- Assign one layout to one or several levels; it appears in every room belonging to those levels.
- HUD elements support fixed tiles, 1-3 digit variable values, and variable-driven bars.
- Number elements use ten consecutive tiles beginning with the configured digit-0 tile.
- Bar elements use configurable empty/full tiles, width, and maximum value.
- Test Play previews the same level-assigned HUD over the room.
- Generated games include the HUD renderer and refresh variable values each frame.
- Project Validator checks level assignments, variable references, bounds, and tileset availability.

VER 13.0 save-game support
===========================
- Adds a Save Game workspace with an enable switch, 1-16 character disk filename, and C64 device number.
- Choose whether saves include global variables, inventory state, and complete live-object state.
- Adds Visual Logic actions: Save Game, Load Game, and Reset Save Status.
- Adds conditions for successful save, successful load, and failed save/load operations.
- Generated projects use standard C64 KERNAL disk SAVE/LOAD routines and a versioned snapshot format.
- Saved object state includes position, room, active state, animation frame, and P0-P7 values.
- Test Play simulates the same snapshot behavior in memory and reports save/load status in its HUD.

VER 12.1 validation and debugging remain included below.

VER 12.1 validator correction
===============================
- Direction-property validation now checks every Set Direction event independently.
- Mixed P-property targets across W/A/S/D events are reported instead of passing when only one valid route exists.

VER 12.0 project validation and Test Play debugging
===================================================
- Adds a dedicated Validator workspace and one-click full-project scan.
- Detects missing level, room, sprite, object, instance, path, tile, and inventory references.
- Calculates the actual player sprite bounding box and reports starts that overlap solid/hazard tiles or extend outside the room.
- Detects the control bug where Set Direction writes one P property but Move In Direction Property / Apply Queued Direction reads another.
- Test Play adds live bounding boxes, solid/hazard tile outlines, object/instance IDs, P0-P7 values, and held-key reporting.
- Test Play can now pause and advance exactly one frame at a time.

The VER 11.0 inventory, VER 10.0 tile editor, and earlier runtime fixes remain included below.

VER 11.0 persistent tile-based inventory update
================================================
- Adds a dedicated Inventory workspace with 1-32 persistent slots.
- Define item IDs, names, icon tile IDs, and maximum stack quantities.
- Configure initial item/quantity contents and the initially selected slot.
- Configure an inventory display room, starting tile cell, column count, and empty-slot tile.
- Adds Visual Logic conditions: Inventory Contains Item, Inventory Slot Equals, and Inventory Quantity At Least.
- Adds Visual Logic actions: Add/Remove/Use Inventory Item, Move Inventory Slot, Set Selected Inventory Slot, and Render Inventory Tiles.
- Generated C64 projects include persistent item and quantity arrays plus stacking, removal, slot swapping, selection, lookup, and tile-grid rendering routines.
- Test Play mirrors the inventory operations and tile renderer and shows the selected slot in its HUD.
- Inventory state remains intact across room changes.

The VER 10.0 integrated tile editor and all VER 09.12 runtime fixes remain included below.

VER 10.0 integrated tile-editor major update
============================================
- Adds a dedicated Tiles workspace based on the Sky Strike Level Editor VER 11.2 tile studio.
- Create and resize per-level hires or multicolor tilesets.
- Paint and erase C64-constrained tile pixels with Background, MC1, MC2, and Local values.
- Add, duplicate, delete, and clear tiles; deleted IDs are safely remapped in room tilemaps.
- Load a PNG into an individual tile and save the selected tile as PNG.
- Existing tile-sheet and Sky Strike ASM import remain available from both Tiles and Rooms.
- Tile edits immediately feed the Room preview, collision/property data, save format, test play, and ASM export.
- Software-to-VIC conversion now warns about fixed 24x21 geometry, artwork loss, and collision overlap.
- The recommended Duplicate and Convert option preserves the original software sprite.

The previous VER 09.12 runtime input/render reliability work remains included below.

VER 09.12 runtime input/render reliability update
- C64 W/A/S/D/SPACE input keeps the direct CIA1 matrix scan and now merges an independent KERNAL SCNKEY result into the same cached key state. This provides a reliable fallback in VICE/real-C64 environments while retaining multi-key support from the direct scan.
- Added generic Visual Logic action: Apply Queued Direction. Use one P property for current direction and another for requested direction; at a tile intersection the requested direction is adopted only when the tile ahead is not Solid.
- Maze-chase example now queues W/A/S/D immediately into P1 and applies P1 to P0 at valid intersections.
- Software-rendered hires sprites now set their foreground screen-RAM color from the sprite local color instead of appearing only black/white.
- VIC-II live sprite register updates are committed atomically with interrupts held during slot collection/sort/commit, so live object X/Y changes cannot be split by an IRQ during the refresh.
- Existing freeze, tile-render, software dirty-rectangle, and Test Play performance fixes remain intact.
- Golf Solitaire, Galaga-style, pathing, and maze-chase editable examples are retained.

Kick Assembler is required to compile generated ASM into a .prg. KickAss.jar is not bundled.
