Next64 Golf Solitaire Example
=============================

Open this project in Next64 C64 Game Creator VER 08.22:

  examples\golf_solitaire.n64game

This is a real Golf Solitaire example built from ordinary Next64 objects,
per-instance properties, variables, sprites, and Visual Logic. There is no
hard-coded Solitaire mode in the editor/runtime.

HOW TO PLAY
-----------
W / A / S / D  Move the yellow cursor around the seven tableau cards.
SPACE          Play the card under the cursor, or deal when the cursor is over the waste/stock pile.

A tableau card is playable when its rank is exactly one above or below the
current waste card. Move the cursor onto a legal exposed tableau card and press
SPACE to play it. Merely crossing a card does not select it. Move the cursor
over the waste/stock pile and press SPACE when you need to deal another card.

Remove all 35 tableau cards to win. A WIN banner appears when score reaches 35.
Aces are low and Kings are high; this example does NOT wrap King <-> Ace.

WHY GOLF SOLITAIRE
------------------
Golf uses a full 52-card deck but its rules do not require suit matching,
multi-card dragging, or Klondike-specific hidden logic. That makes it a clean
example of a solitaire game that is actually authored with the same general
Next64 systems available to users.

HOW THE EXAMPLE IS BUILT
------------------------
Player Cursor (Object 0)
  P0 mirrors the current waste rank.
  SPACE + topmost overlap + the adjacent-rank conditions determine whether a
  tableau card is legal. Cursor movement uses +/-8 per frame in this example.

Tableau Columns (Objects 1-7)
  Each column contains five pre-shuffled ranks.
  P0 = current visible rank.
  P1 = depth in that column (0-5).
  Playing a card increments P1. Visual Logic then changes P0/frame to expose
  the next card. At P1=5 the column object destroys itself.

Waste / Stock Controller (Object 8)
  Displays waste_rank as a card frame.
  Sixteen SPACE-key Visual Logic blocks advance through the remainder of the
  17-card stock, but only while the Player Cursor overlaps this object. They are
  intentionally stored in reverse stock_pos order so one keypress cannot
  cascade through several stock cards in one frame.

WIN Banner (Object 9)
  Starts inactive. Object 0 activates it when score=35.

Press D Stock Marker (Object 10)
  Visual reminder near the waste card.

Variables
  waste_rank = current waste rank (1-13)
  stock_pos  = number of additional stock cards dealt (0-16)
  score      = tableau cards removed (win at 35)

MODDING
-------
Everything important is editable in the normal tabs:
  Sprites      card faces, cursor, marker, WIN banner
  Objects      object properties and object resources
  Visual Logic movement, rank rules, stock sequence, win condition
  Rooms        layout and positions
  Variables    starting state

DECK_LAYOUT.txt lists the supplied deterministic shuffle. It contains exactly
four of every rank across the seven 5-card tableau columns and 17-card stock.
The supplied shuffle was chosen because it has a complete winning line under
this example's rules.

COMPILING
---------
1. Open golf_solitaire.n64game.
2. Open the Build tab.
3. Select your KickAss.jar.
4. Use Build PRG, or Generate ASM Folder if you want to inspect the generated
   Kick Assembler source first.

VER 09.0 adds two general-purpose Visual Logic comparisons used by this game:
  Self Property One Greater Than Other Property
  Self Property One Less Than Other Property

These are generic object-property comparisons and are not Solitaire-specific.

PRE-GENERATED ASM SNAPSHOT
--------------------------
The folder:
  examples\golf_solitaire_generated_asm

contains ASM generated directly from the supplied example project. To compile
that snapshot without regenerating it first, copy KickAss.jar into that folder
and run build.bat.

If you modify golf_solitaire.n64game in the editor, regenerate the ASM so the
source snapshot reflects your changes before compiling the modified game.

VER 09.0 NOTE
--------------
The Rank Card sprite intentionally has Auto Animate turned OFF. Its 14 frames are used as card-state graphics (Blank, A through K), not as an animation. Do not enable Auto Animate for the Rank Card unless you specifically want its faces to cycle.


VER 09.0 DISPLAY FIX
The initial 08.16 example accidentally used a hires bitmap scene and software-rendered cards/cursor. A real C64 compile exposed visual corruption and a cursor that could move logically without clean visible motion.

08.17 changes the example to the intended C64 configuration:
- Scene: multicolor bitmap
- Cursor: VIC-II multicolor hardware sprite
- Rank Card: VIC-II multicolor hardware sprite, 14 fixed-state frames
- DEAL/WIN: native multicolor software artwork

WASD moves the visible hardware cursor. SPACE deals. Card ranks do not auto-animate.


VER 09.0 CONTROL / VIC MULTIPLEXER FIX
---------------------------------------
- Tableau cards no longer play merely because the cursor touches them.
- Move over a legal card and press SPACE to play it.
- Move over the waste/stock pile and press SPACE to deal.
- Golf cursor movement is now +/-8 per frame, based on real C64 play testing.
- Added generic Visual Logic triggers:
    Keyboard Pressed Over Object
    Keyboard Pressed Over Topmost Object
  These combine a keypress with overlap selection while still allowing the
  normal IF condition to validate card rank or any other property.
- The VIC-II raster multiplexer now disables the previous frame's raster IRQ
  chain before rebuilding slot/event tables. This prevents a pending IRQ from
  reading half-updated sprite assignments, which could make the cursor/card
  sprite channels appear to flash or trade display state.


VER 09.0 MULTIPLEXER FRAME-TIMING FIX
----------------------------------------
Real C64/VICE testing exposed a slot-reuse timing fault when Golf had nine VIC
objects on screen. Hardware slot 0 was shared by the upper sprite and waste
pile; moving the cursor below the tableau changed which upper object occupied
that slot, making the apparent flashing move to Tableau Column 1. VER 09.0
commits the new VIC sprite assignments at raster $FC, after all current-frame
multiplexer reuse events have completed.


VER 08.20 NOTE
--------------
The engine multiplexer now uses an 8-raster-line pre-start safety window for
VIC slot reuse. This specifically addresses the cursor/Tableau Column 1/waste
pile flashing handoff exposed by the nine-object Golf layout.

VER 08.21 NOTE
--------------
Sprite Renderer selections now commit immediately. For renderer diagnostics, setting every
Golf sprite to Software and regenerating must produce objectRenderer values of all 0 and
VIC_FRAME_COUNT = 0. This patch intentionally does not modify the VIC multiplexer.

VER 08.22 SOFTWARE RENDERER FIX
If Golf sprites are switched to Software rendering, plain rooms with no tile graphics now use the fast blank-background dirty-rectangle restore path. This fixes the null tile-pointer reconstruction bug that could create trails and extreme slowdown. The VIC-II multiplexer was not changed in VER 08.22.


VER 09.0 CONTROL UPDATE
-----------------------
SPACE over a tableau stack attempts to play the top exposed card.
SPACE anywhere not overlapping tableau objects 1-7 requests the next stock card.
This demonstrates the generic Self Does Not Overlap Object condition; ranges such as 1-7 are accepted.
