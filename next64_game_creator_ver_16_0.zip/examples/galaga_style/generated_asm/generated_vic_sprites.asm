// Next64 VIC-II hardware sprite data mirrored into both bitmap banks.
// $0900-$0fff and $4900-$4fff hold mirrored VIC sprite frames; main engine is at $8000+.
