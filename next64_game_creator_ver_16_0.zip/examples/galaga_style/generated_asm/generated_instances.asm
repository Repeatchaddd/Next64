// Reusable room object instances
.const ROOM_INSTANCE_COUNT = 4
instanceRuntimeSlot: .byte 1,2,3,4
instanceTemplate: .byte 1,2,3,20
instanceRoom: .byte 0,0,0,0
instanceXLo: .byte 64,144,224,156
instanceXHi: .byte 0,0,0,0
instanceY: .byte 0,0,0,168
instanceActive: .byte 1,1,1,0
