// Generated 8-bit globals
var_score: .byte 0
