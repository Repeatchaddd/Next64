// Generated sprite resources
// Contiguous with Main; no fixed origin here.
.const SPR_Arcade_000_MODE = 1
.const SPR_Arcade_000_WIDTH = 8
.const SPR_Arcade_000_HEIGHT = 8
.const SPR_Arcade_000_FRAMES = 1
.const SPR_Arcade_000_FRAME_SIZE = 24
.const SPR_Arcade_000_IMAGE_BYTES = 16
sprite_Arcade_000_data: .import binary "sprite_Arcade_000.bin"

.const SPR_Arcade_001_MODE = 1
.const SPR_Arcade_001_WIDTH = 8
.const SPR_Arcade_001_HEIGHT = 8
.const SPR_Arcade_001_FRAMES = 1
.const SPR_Arcade_001_FRAME_SIZE = 24
.const SPR_Arcade_001_IMAGE_BYTES = 16
sprite_Arcade_001_data: .import binary "sprite_Arcade_001.bin"

.const SPR_Arcade_002_MODE = 1
.const SPR_Arcade_002_WIDTH = 8
.const SPR_Arcade_002_HEIGHT = 8
.const SPR_Arcade_002_FRAMES = 1
.const SPR_Arcade_002_FRAME_SIZE = 24
.const SPR_Arcade_002_IMAGE_BYTES = 16
sprite_Arcade_002_data: .import binary "sprite_Arcade_002.bin"
