// Generated visual event/action code
compareOtherTemp: .byte 0
events_slot_000: // template 0, instance 255
    ldx #0
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda keyMatrixCurrent+2
    and #$02
    bne !skip_0_0+
    ldx #0
    lda objectXLo,x
    clc
    adc #252
    sta objectXLo,x
    bcs !mx_done+
    dec objectXHi,x
!mx_done:
!skip_0_0:
    lda keyMatrixCurrent+2
    and #$04
    bne !skip_0_1+
    ldx #0
    lda objectXLo,x
    clc
    adc #4
    sta objectXLo,x
    bcc !mx_done+
    inc objectXHi,x
!mx_done:
!skip_0_1:
    lda keyMatrixCurrent+7
    and #$10
    bne !skip_0_2+
    lda keyMatrixPrevious+7
    and #$10
    beq !skip_0_2+
    ldx #4
    lda objectActive,x
    bne !skip_0_2+
    lda #20
    jsr FindInactiveTemplateSlot
    bcc !skip_0_2+
    stx spawnTargetSlot
    ldx #0
    ldy spawnTargetSlot
    lda objectXLo,x
    sta objectXLo,y
    lda objectXHi,x
    sta objectXHi,y
    lda objectY,x
    sec
    sbc objectHeight,y
    sta objectY,y
    lda objectRoom,x
    sta objectRoom,y
    lda #$00
    sta objectFrame,y
    sta objectAnimTimer,y
    lda #$01
    sta objectActive,y
!skip_0_2:
    rts

events_slot_001: // template 1, instance 0
    ldx #1
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    ldx #1
    lda objectPathDone,x
    beq !skip_1_0+
    lda #0
    sta objectPathDone,x
    ldx #1
    lda #1
    sta objectP0,x
!skip_1_0:
    ldx #1
    lda objectP0,x
    cmp #1
    bne !skip_1_1+
    ldx #1
    ldy #0
    lda #1
    jsr MoveIndexTowardIndex
!skip_1_1:
    ldx #1
    lda #0
    jsr CheckCollisionWithTemplate
    bcc !skip_1_2+
    ldx #1
    lda #0
    sta objectP0,x
    ldx #1
    lda #0
    sta objectPathPoint,x
    lda #1
    sta objectPathDir,x
    lda #0
    sta objectPathDone,x
    lda #1
    sta objectPathActive,x
!skip_1_2:
    rts

events_slot_002: // template 2, instance 1
    ldx #2
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    ldx #2
    lda objectPathDone,x
    beq !skip_2_0+
    lda #0
    sta objectPathDone,x
    ldx #2
    lda #1
    sta objectP0,x
!skip_2_0:
    ldx #2
    lda objectP0,x
    cmp #1
    bne !skip_2_1+
    ldx #2
    ldy #0
    lda #1
    jsr MoveIndexTowardIndex
!skip_2_1:
    ldx #2
    lda #0
    jsr CheckCollisionWithTemplate
    bcc !skip_2_2+
    ldx #2
    lda #0
    sta objectP0,x
    ldx #2
    lda #0
    sta objectPathPoint,x
    lda #1
    sta objectPathDir,x
    lda #0
    sta objectPathDone,x
    lda #1
    sta objectPathActive,x
!skip_2_2:
    rts

events_slot_003: // template 3, instance 2
    ldx #3
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    ldx #3
    lda objectPathDone,x
    beq !skip_3_0+
    lda #0
    sta objectPathDone,x
    ldx #3
    lda #1
    sta objectP0,x
!skip_3_0:
    ldx #3
    lda objectP0,x
    cmp #1
    bne !skip_3_1+
    ldx #3
    ldy #0
    lda #1
    jsr MoveIndexTowardIndex
!skip_3_1:
    ldx #3
    lda #0
    jsr CheckCollisionWithTemplate
    bcc !skip_3_2+
    ldx #3
    lda #0
    sta objectP0,x
    ldx #3
    lda #0
    sta objectPathPoint,x
    lda #1
    sta objectPathDir,x
    lda #0
    sta objectPathDone,x
    lda #1
    sta objectPathActive,x
!skip_3_2:
    rts

events_slot_004: // template 20, instance 3
    ldx #4
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    ldx #4
    lda objectActive,x
    beq !skip_4_0+
    ldx #4
    lda objectY,x
    clc
    adc #250
    sta objectY,x
!skip_4_0:
    ldx #4
    lda objectY,x
    cmp #200
    bcc !skip_4_1+
    ldx #4
    lda #0
    sta objectActive,x
!skip_4_1:
    ldx #4
    lda #1
    jsr CheckCollisionWithTemplate
    bcc !skip_4_2+
    lda var_score
    clc
    adc #10
    sta var_score
    ldx collisionOtherIndex
    lda #$00
    sta objectActive,x
    ldx #4
    sta objectActive,x
!skip_4_2:
    ldx #4
    lda #2
    jsr CheckCollisionWithTemplate
    bcc !skip_4_3+
    lda var_score
    clc
    adc #10
    sta var_score
    ldx collisionOtherIndex
    lda #$00
    sta objectActive,x
    ldx #4
    sta objectActive,x
!skip_4_3:
    ldx #4
    lda #3
    jsr CheckCollisionWithTemplate
    bcc !skip_4_4+
    lda var_score
    clc
    adc #10
    sta var_score
    ldx collisionOtherIndex
    lda #$00
    sta objectActive,x
    ldx #4
    sta objectActive,x
!skip_4_4:
    rts
