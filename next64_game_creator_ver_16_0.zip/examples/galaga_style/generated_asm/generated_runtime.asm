// Next64 integrated hires/multicolor software-sprite runtime v0.5
// Double-buffered, dirty-region, pixel-X proof runtime.
// Hybrid renderer: software sprites plus up to 8 VIC-II hardware sprites.

.const SS_IMG_LO  = $f0
.const SS_IMG_HI  = $f1
.const SS_MASK_LO = $f2
.const SS_MASK_HI = $f3
.const SS_DST_LO  = $f4
.const SS_DST_HI  = $f5

.const ROOM_MAP_LO       = $e0
.const ROOM_MAP_HI       = $e1
.const ROOM_PTRLO_LO     = $e2
.const ROOM_PTRLO_HI     = $e3
.const ROOM_PTRHI_LO     = $e4
.const ROOM_PTRHI_HI     = $e5
.const ROOM_COLL_LO      = $e6
.const ROOM_COLL_HI      = $e7
.const ROOM_XCELL_LO     = $e8
.const ROOM_XCELL_HI     = $e9
.const ROOM_YCELL_LO     = $ea
.const ROOM_YCELL_HI     = $eb
.const ROOM_YOFFLO_LO    = $ec
.const ROOM_YOFFLO_HI    = $ed
.const ROOM_YOFFHI_LO    = $ee
.const ROOM_YOFFHI_HI    = $ef

frontBuffer: .byte 0
renderBuffer: .byte 1
currentRoom: .byte START_ROOM_ID
drawIndex: .byte 0
drawOrderPos: .byte 0
ss_xcell: .byte 0
ss_xshift: .byte 0
ss_ypixel: .byte 0
ss_widthbytes: .byte 1
ss_clearbytes: .byte 1
ss_height: .byte 8
ss_xoff_lo: .byte 0
ss_xoff_hi: .byte 0
ss_cur_y: .byte 0
ss_rows_left: .byte 0
ss_col: .byte 0
ss_img_temp: .byte 0
ss_spill_temp: .byte 0
ss_shift_count: .byte 0
ss_mc_maskbyte: .byte 0
ss_mc_shift: .byte 0
ss_mask_temp: .byte 0
ss_mask_spill: .byte 0
ss_count: .byte 0
keyColumn: .byte 0
keyMask: .byte 0
keyResult: .byte 0
keySavedPortA: .byte 0
keySavedDDRA: .byte 0
keySavedDDRB: .byte 0
vicEnableMask: .byte 0
vicMulticolorMask: .byte 0
vicXHighMask: .byte 0
vicSlot: .byte 0
vicObjectIndex: .byte 0
roomMetaIndex: .byte 0
roomCols: .byte 40
roomRows: .byte 25
roomTileWidthBytesRT: .byte 1
roomTileHeightRT: .byte 8
roomDrawRow: .byte 0
roomDrawCol: .byte 0
roomDrawBaseY: .byte 0
roomDrawCurrentY: .byte 0
roomDrawXByte: .byte 0
roomTileRow: .byte 0
roomTileByte: .byte 0
roomTileIdTemp: .byte 0
tileCollisionWanted: .byte 0
tileCollisionSource: .byte 0
tilePropertyMode: .byte 0
tilePropertyIndex: .byte 0
tilePropertyWanted: .byte 0
tileAheadDirection: .byte 0
tileAheadWanted: .byte 0
directionPropertyIndex: .byte 0
directionAvoidReverse: .byte 0
directionTryCount: .byte 0
directionOriginal: .byte 0
directionMask: .byte 0
directionCandidate: .byte 0
tileAlignAxis: .byte 0
tileGridSize: .byte 8
tileGridRemainder: .byte 0
tileProbeXLo: .byte 0
tileProbeXHi: .byte 0
tileProbeY: .byte 0
tileProbeCol: .byte 0
tileProbeRowOffLo: .byte 0
tileProbeRowOffHi: .byte 0
tileWriteId: .byte 0
tileWriteCol: .byte 0
tileWriteRow: .byte 0
tileWriteXByte: .byte 0
tileWriteY: .byte 0
pathDiffHi: .byte 0
tileLeftCell: .byte 0
tileRightCell: .byte 0
tileTopCell: .byte 0
tileBottomCell: .byte 0
tileCurrentRow: .byte 0
tileRowOffLo: .byte 0
tileRowOffHi: .byte 0
tileMapIndexLo: .byte 0
tileMapIndexHi: .byte 0
tileRightXLo: .byte 0
tileRightXHi: .byte 0
tileBottomY: .byte 0
restoreAbsXByte: .byte 0
restoreTileCol: .byte 0
restoreTileRow: .byte 0
restoreWithinX: .byte 0
restoreWithinY: .byte 0
restoreOffsetLo: .byte 0
restoreOffsetHi: .byte 0
restoreTemp: .byte 0
ss_color_value: .byte 0
ss_color_row: .byte 0
ss_color_lastrow: .byte 0
ss_color_col: .byte 0

// Cached keyboard matrix. Scan once per frame instead of reprogramming CIA1
// separately for every visual-logic key condition. A pressed key reads as 0.
keyMatrixCurrent: .byte $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff
keyMatrixPrevious: .byte $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff
keyboardColumnMasks: .byte $fe,$fd,$fb,$f7,$ef,$df,$bf,$7f
keySavedPortB: .byte 0

ScanKeyboardMatrix:
    // Preserve the caller's interrupt state and all CIA1 keyboard port state.
    php
    sei
    lda $dc00
    sta keySavedPortA
    lda $dc01
    sta keySavedPortB
    lda $dc02
    sta keySavedDDRA
    lda $dc03
    sta keySavedDDRB
    // CIA1 port A drives columns; port B reads rows.
    lda #$ff
    sta $dc02
    lda #$00
    sta $dc03
    ldy #$00
!scan_key_column:
    lda keyboardColumnMasks,y
    sta $dc00
    // Give the CIA/matrix a few cycles to settle before sampling Port B.
    nop
    nop
    lda $dc01
    sta keyMatrixCurrent,y
    iny
    cpy #$08
    bne !scan_key_column-
    // Restore latches first, then original data directions.
    lda keySavedPortA
    sta $dc00
    lda keySavedPortB
    sta $dc01
    lda keySavedDDRA
    sta $dc02
    lda keySavedDDRB
    sta $dc03

    // VER 09.12: KERNAL SCNKEY fallback.  The direct CIA matrix remains the
    // primary multi-key path, but SCNKEY gives us an independent, known-good
    // held-key result on real C64s and VICE.  Merge W/A/S/D/SPACE into the
    // cached matrix so existing Visual Logic needs no special case.
    jsr $ff9f
    lda $cb
    cmp #$09              // W
    bne !kernal_not_w+
    lda keyMatrixCurrent+1
    and #$fd
    sta keyMatrixCurrent+1
!kernal_not_w:
    lda $cb
    cmp #$0a              // A
    bne !kernal_not_a+
    lda keyMatrixCurrent+2
    and #$fd
    sta keyMatrixCurrent+2
!kernal_not_a:
    lda $cb
    cmp #$0d              // S
    bne !kernal_not_s+
    lda keyMatrixCurrent+5
    and #$fd
    sta keyMatrixCurrent+5
!kernal_not_s:
    lda $cb
    cmp #$12              // D
    bne !kernal_not_d+
    lda keyMatrixCurrent+2
    and #$fb
    sta keyMatrixCurrent+2
!kernal_not_d:
    lda $cb
    cmp #$3c              // SPACE
    bne !kernal_key_done+
    lda keyMatrixCurrent+7
    and #$ef
    sta keyMatrixCurrent+7
!kernal_key_done:
    plp
    rts

CommitKeyboardMatrix:
    ldy #$00
!commit_key_column:
    lda keyMatrixCurrent,y
    sta keyMatrixPrevious,y
    iny
    cpy #$08
    bne !commit_key_column-
    rts

// Compatibility helper retained for generated/custom code that may call it.
// A=column select mask, X=row mask. Returns Z=1 while the key is held.
CheckMatrixKeyHeld:
    sta keyColumn
    stx keyMask
    jsr ScanKeyboardMatrix
    ldy #$00
!find_key_column:
    lda keyboardColumnMasks,y
    cmp keyColumn
    beq !check_cached_key+
    iny
    cpy #$08
    bne !find_key_column-
    lda #$ff
    rts
!check_cached_key:
    lda keyMatrixCurrent,y
    and keyMask
    rts

InitSoftwareDisplay:
    lda #$00
    sta $d015
    sta $d017
    sta $d01d
    sta $d020
    sta $d021
    sta frontBuffer
    lda #$01
    sta renderBuffer

    lda #$18
    sta $d018
    lda #$3b
    sta $d011
    lda #SCENE_BG
    sta $d021
    lda #SCENE_MODE
    beq InitHiresMode
    lda #$18
    sta $d016
    jmp InitModeDone
InitHiresMode:
    lda #$08
    sta $d016
InitModeDone:
    lda #SCENE_MC1
    sta $d025
    lda #SCENE_MC2
    sta $d026

    lda $dd00
    and #$fc
    ora #$03
    sta $dd00

    lda #SCENE_MODE
    beq InitHiresColors
    // Multicolor bitmap mapping in VER 08.8:
    // screen high nibble = per-cell local color
    // screen low nibble  = MC2
    // Color RAM          = MC1
    lda #((SCENE_LOCAL << 4) | SCENE_MC2)
    jmp InitScreenColorReady
InitHiresColors:
    lda #$10
InitScreenColorReady:
    ldx #$00
InitColorsLoop:
    sta $0400,x
    sta $0500,x
    sta $0600,x
    sta $0700,x
    sta $4400,x
    sta $4500,x
    sta $4600,x
    sta $4700,x
    pha
    lda #SCENE_MC1
    sta $d800,x
    sta $d900,x
    sta $da00,x
    sta $db00,x
    pla
    inx
    bne InitColorsLoop

    jsr LoadCurrentRoomBackground
    jsr InitRasterMultiplexer
    rts

ClearBothBitmaps:
    lda #$00
    ldx #$00
ClearBothLoop:
    sta $2000,x
    sta $2100,x
    sta $2200,x
    sta $2300,x
    sta $2400,x
    sta $2500,x
    sta $2600,x
    sta $2700,x
    sta $2800,x
    sta $2900,x
    sta $2a00,x
    sta $2b00,x
    sta $2c00,x
    sta $2d00,x
    sta $2e00,x
    sta $2f00,x
    sta $3000,x
    sta $3100,x
    sta $3200,x
    sta $3300,x
    sta $3400,x
    sta $3500,x
    sta $3600,x
    sta $3700,x
    sta $3800,x
    sta $3900,x
    sta $3a00,x
    sta $3b00,x
    sta $3c00,x
    sta $3d00,x
    sta $3e00,x
    sta $3f00,x
    sta $6000,x
    sta $6100,x
    sta $6200,x
    sta $6300,x
    sta $6400,x
    sta $6500,x
    sta $6600,x
    sta $6700,x
    sta $6800,x
    sta $6900,x
    sta $6a00,x
    sta $6b00,x
    sta $6c00,x
    sta $6d00,x
    sta $6e00,x
    sta $6f00,x
    sta $7000,x
    sta $7100,x
    sta $7200,x
    sta $7300,x
    sta $7400,x
    sta $7500,x
    sta $7600,x
    sta $7700,x
    sta $7800,x
    sta $7900,x
    sta $7a00,x
    sta $7b00,x
    sta $7c00,x
    sta $7d00,x
    sta $7e00,x
    sta $7f00,x
    inx
    beq ClearBothDone
    jmp ClearBothLoop
ClearBothDone:
    rts

// ------------------------------------------------------------
// C64 Room tile renderer.
// The selected Room tile map is rendered directly into both bitmap buffers.
// Dirty software-sprite restoration reconstructs original bytes from the tile
// map and tile graphics, so no extra 8 KB background copy is required.
// ------------------------------------------------------------
FindRoomTileMeta:
    // A = room ID. Returns C=1, X=metadata index.
    sta roomMetaIndex
    ldx #$00
FindRoomTileMetaLoop:
    cpx #ROOM_TILE_META_COUNT
    bne FindRoomTileMetaCheck
    clc
    rts
FindRoomTileMetaCheck:
    lda roomTileId,x
    cmp roomMetaIndex
    beq FindRoomTileMetaFound
    inx
    jmp FindRoomTileMetaLoop
FindRoomTileMetaFound:
    stx roomMetaIndex
    sec
    rts

LoadRoomTilePointers:
    // X = room metadata index.
    stx roomMetaIndex
    lda roomTileMapLo,x
    sta ROOM_MAP_LO
    lda roomTileMapHi,x
    sta ROOM_MAP_HI
    lda roomTilePtrLoLo,x
    sta ROOM_PTRLO_LO
    lda roomTilePtrLoHi,x
    sta ROOM_PTRLO_HI
    lda roomTilePtrHiLo,x
    sta ROOM_PTRHI_LO
    lda roomTilePtrHiHi,x
    sta ROOM_PTRHI_HI
    lda roomTileCollisionLo,x
    sta ROOM_COLL_LO
    lda roomTileCollisionHi,x
    sta ROOM_COLL_HI
    lda roomTileXCellLo,x
    sta ROOM_XCELL_LO
    lda roomTileXCellHi,x
    sta ROOM_XCELL_HI
    lda roomTileYCellLo,x
    sta ROOM_YCELL_LO
    lda roomTileYCellHi,x
    sta ROOM_YCELL_HI
    lda roomTileYOffLoLo,x
    sta ROOM_YOFFLO_LO
    lda roomTileYOffLoHi,x
    sta ROOM_YOFFLO_HI
    lda roomTileYOffHiLo,x
    sta ROOM_YOFFHI_LO
    lda roomTileYOffHiHi,x
    sta ROOM_YOFFHI_HI
    lda roomTileCols,x
    sta roomCols
    lda roomTileRows,x
    sta roomRows
    lda roomTileWidthBytes,x
    sta roomTileWidthBytesRT
    lda roomTileHeight,x
    sta roomTileHeightRT
    rts

LoadCurrentRoomBackground:
    jsr ClearBothBitmaps
    lda currentRoom
    jsr FindRoomTileMeta
    bcs LoadCurrentRoomBGMetaFound
    rts

LoadCurrentRoomBGMetaFound:
    jsr LoadRoomTilePointers
    lda ROOM_PTRLO_LO
    ora ROOM_PTRLO_HI
    bne RoomRenderHaveTiles
    rts

RoomRenderHaveTiles:
    lda #$00
    sta roomDrawRow
    sta roomDrawBaseY

RoomRenderRowLoop:
    lda roomDrawRow
    cmp roomRows
    bcc RoomRenderRowOkay
    rts
RoomRenderRowOkay:
    lda #$00
    sta roomDrawCol
    sta roomDrawXByte

RoomRenderCellLoop:
    lda roomDrawCol
    cmp roomCols
    bcc RoomRenderCellOkay
    clc
    lda roomDrawBaseY
    adc roomTileHeightRT
    sta roomDrawBaseY
    inc roomDrawRow
    jmp RoomRenderRowLoop

RoomRenderCellOkay:
    ldy #$00
    lda (ROOM_MAP_LO),y
    sta roomTileIdTemp
    inc ROOM_MAP_LO
    bne RoomRenderMapAdvanced
    inc ROOM_MAP_HI
RoomRenderMapAdvanced:

    lda roomTileIdTemp
    cmp #$ff
    bne RoomRenderHaveTile
    jmp RoomRenderNextCell
RoomRenderHaveTile:

    tay
    lda (ROOM_PTRLO_LO),y
    sta SS_IMG_LO
    lda (ROOM_PTRHI_LO),y
    sta SS_IMG_HI

    lda #$00
    sta roomTileRow
    lda roomDrawBaseY
    sta roomDrawCurrentY

RoomRenderTileRowLoop:
    lda roomTileRow
    cmp roomTileHeightRT
    bcc RoomRenderTileRowOkay
    jmp RoomRenderNextCell
RoomRenderTileRowOkay:
    ldx roomDrawCurrentY
    cpx #200
    bcc RoomRenderYInBounds
    jmp RoomRenderNextCell
RoomRenderYInBounds:
    // C64 bitmap memory is character-cell interleaved: neighboring
    // 8-pixel columns are 8 bytes apart, not 1 byte apart.
    // Convert the logical bitmap-byte column to a 16-bit *8 offset.
    lda roomDrawXByte
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi

    lda bitmapRowLo,x
    clc
    adc ss_xoff_lo
    sta SS_DST_LO
    sta SS_MASK_LO
    lda bitmapRowHi,x
    adc ss_xoff_hi
    sta SS_DST_HI
    clc
    adc #$40
    sta SS_MASK_HI

    lda #$00
    sta roomTileByte
RoomRenderTileByteLoop:
    lda roomTileByte
    cmp roomTileWidthBytesRT
    bcc RoomRenderTileByteOkay
    jmp RoomRenderTileRowDone
RoomRenderTileByteOkay:
    // Tile source bytes are packed, but destination bitmap cells are
    // separated by 8 bytes horizontally.
    tay
    lda (SS_IMG_LO),y
    sta roomTileIdTemp
    ldx roomTileByte
    ldy offset8,x
    lda roomTileIdTemp
    sta (SS_DST_LO),y
    sta (SS_MASK_LO),y
    inc roomTileByte
    jmp RoomRenderTileByteLoop

RoomRenderTileRowDone:
    clc
    lda SS_IMG_LO
    adc roomTileWidthBytesRT
    sta SS_IMG_LO
    bcc RoomRenderSourceAdvanced
    inc SS_IMG_HI
RoomRenderSourceAdvanced:
    inc roomDrawCurrentY
    inc roomTileRow
    jmp RoomRenderTileRowLoop

RoomRenderNextCell:
    clc
    lda roomDrawXByte
    adc roomTileWidthBytesRT
    sta roomDrawXByte
    inc roomDrawCol
    jmp RoomRenderCellLoop

SelectBackBuffer:
    lda frontBuffer
    eor #$01
    sta renderBuffer
    rts

SwapDisplayBuffer:
    lda renderBuffer
    sta frontBuffer
    beq ShowBufferA
    lda $dd00
    and #$fc
    ora #$02
    sta $dd00
    rts
ShowBufferA:
    lda $dd00
    and #$fc
    ora #$03
    sta $dd00
    rts

SetDestinationFromCurrentRow:
    ldx ss_cur_y
    lda bitmapRowLo,x
    clc
    adc ss_xoff_lo
    sta SS_DST_LO
    lda bitmapRowHi,x
    adc ss_xoff_hi
    ldx renderBuffer
    beq SetDestDone
    clc
    adc #$40
SetDestDone:
    sta SS_DST_HI
    rts

ErasePreviousObjects:
    ldx #$00
ErasePrevLoop:
    cpx #OBJ_COUNT
    bne ErasePrevContinue
    jmp ErasePrevDone
ErasePrevContinue:
    stx drawIndex
    lda objectRenderer,x
    beq ErasePrevContinueSoftware
    jmp ErasePrevNext
ErasePrevContinueSoftware:
    lda objectRoom,x
    cmp currentRoom
    beq ErasePrevContinueSoftwareRoomOkay
    jmp ErasePrevNext
ErasePrevContinueSoftwareRoomOkay:
    lda objectMode,x
    cmp #SCENE_MODE
    beq EraseModeOkay
    jmp ErasePrevNext
EraseModeOkay:
    lda renderBuffer
    beq EraseA

EraseB:
    lda objectPrevBActive,x
    bne EraseBActive
    jmp ErasePrevNext
EraseBActive:
    lda objectPrevBXLo,x
    sta ss_img_temp
    lda objectMode,x
    beq EraseBShiftHires
    lda ss_img_temp
    and #$06
    sta ss_xshift
    jmp EraseBShiftDone
EraseBShiftHires:
    lda ss_img_temp
    and #$07
    sta ss_xshift
EraseBShiftDone:
    lda ss_img_temp
    lsr
    lsr
    lsr
    sta ss_xcell
    lda objectPrevBXHi,x
    beq EraseBHiDone
    lda ss_xcell
    clc
    adc #32
    sta ss_xcell
EraseBHiDone:
    lda objectPrevBY,x
    sta ss_ypixel
    jmp EraseHaveState

EraseA:
    lda objectPrevAActive,x
    bne EraseAActive
    jmp ErasePrevNext
EraseAActive:
    lda objectPrevAXLo,x
    sta ss_img_temp
    lda objectMode,x
    beq EraseAShiftHires
    lda ss_img_temp
    and #$06
    sta ss_xshift
    jmp EraseAShiftDone
EraseAShiftHires:
    lda ss_img_temp
    and #$07
    sta ss_xshift
EraseAShiftDone:
    lda ss_img_temp
    lsr
    lsr
    lsr
    sta ss_xcell
    lda objectPrevAXHi,x
    beq EraseAHiDone
    lda ss_xcell
    clc
    adc #32
    sta ss_xcell
EraseAHiDone:
    lda objectPrevAY,x
    sta ss_ypixel

EraseHaveState:
    lda ss_ypixel
    cmp #200
    bcc EraseYOkay
    jmp ErasePrevNext
EraseYOkay:
    lda ss_xcell
    cmp #40
    bcc EraseXOkay
    jmp ErasePrevNext
EraseXOkay:

    lda objectWidthBytes,x
    sta ss_clearbytes
    lda ss_xshift
    beq EraseWidthReady
    inc ss_clearbytes
EraseWidthReady:
    lda ss_xcell
    clc
    adc ss_clearbytes
    cmp #41
    bcc EraseWidthInBounds
    jmp ErasePrevNext
EraseWidthInBounds:
    lda objectHeight,x
    sta ss_height
    jsr RestoreSpriteRect
    ldx drawIndex
    lda objectActive,x
    bne ErasePrevNext
    lda renderBuffer
    beq ClearPrevAFlag
    lda #$00
    sta objectPrevBActive,x
    jmp ErasePrevNext
ClearPrevAFlag:
    lda #$00
    sta objectPrevAActive,x

ErasePrevNext:
    ldx drawIndex
    inx
    jmp ErasePrevLoop
ErasePrevDone:
    rts

// Clear the latest logical object rectangle in the selected back buffer too.
// Each bitmap is displayed every other frame, so its saved previous rectangle
// can lag the current logical position. Clearing both rectangles before redraw
// prevents sub-byte/fast-moving software sprites from leaving isolated pixels.
EraseCurrentObjectRects:
    ldx #$00
EraseCurrentLoop:
    cpx #OBJ_COUNT
    bne EraseCurrentContinue
    jmp EraseCurrentDone
EraseCurrentContinue:
    stx drawIndex
    lda objectRenderer,x
    beq EraseCurrentContinueSoftware
    jmp EraseCurrentNext
EraseCurrentContinueSoftware:
    lda objectRoom,x
    cmp currentRoom
    beq EraseCurrentContinueSoftwareRoomOkay
    jmp EraseCurrentNext
EraseCurrentContinueSoftwareRoomOkay:
    lda objectActive,x
    bne EraseCurrentActive
    jmp EraseCurrentNext
EraseCurrentActive:
    lda objectMode,x
    cmp #SCENE_MODE
    beq EraseCurrentModeOkay
    jmp EraseCurrentNext
EraseCurrentModeOkay:
    // The saved dirty rectangle already clears stationary objects. The second
    // safety clear is needed only when the object's logical position differs
    // from the position last drawn into this specific back buffer.
    lda renderBuffer
    beq EraseCurrentCompareA
EraseCurrentCompareB:
    lda objectPrevBActive,x
    bne EraseCurrentBWasActive
    jmp EraseCurrentNext
EraseCurrentBWasActive:
    lda objectXLo,x
    cmp objectPrevBXLo,x
    bne EraseCurrentMoved
    lda objectXHi,x
    cmp objectPrevBXHi,x
    bne EraseCurrentMoved
    lda objectY,x
    cmp objectPrevBY,x
    bne EraseCurrentMoved
    jmp EraseCurrentNext
EraseCurrentCompareA:
    lda objectPrevAActive,x
    bne EraseCurrentAWasActive
    jmp EraseCurrentNext
EraseCurrentAWasActive:
    lda objectXLo,x
    cmp objectPrevAXLo,x
    bne EraseCurrentMoved
    lda objectXHi,x
    cmp objectPrevAXHi,x
    bne EraseCurrentMoved
    lda objectY,x
    cmp objectPrevAY,x
    bne EraseCurrentMoved
    jmp EraseCurrentNext
EraseCurrentMoved:
    lda objectXLo,x
    sta ss_img_temp
    lda objectMode,x
    beq EraseCurrentShiftHires
    lda ss_img_temp
    and #$06
    sta ss_xshift
    jmp EraseCurrentShiftDone
EraseCurrentShiftHires:
    lda ss_img_temp
    and #$07
    sta ss_xshift
EraseCurrentShiftDone:
    lda ss_img_temp
    lsr
    lsr
    lsr
    sta ss_xcell
    lda objectXHi,x
    beq EraseCurrentHiDone
    lda ss_xcell
    clc
    adc #32
    sta ss_xcell
EraseCurrentHiDone:
    lda objectY,x
    sta ss_ypixel

    lda ss_ypixel
    cmp #200
    bcc EraseCurrentYOkay
    jmp EraseCurrentNext
EraseCurrentYOkay:
    lda ss_xcell
    cmp #40
    bcc EraseCurrentXOkay
    jmp EraseCurrentNext
EraseCurrentXOkay:
    lda objectWidthBytes,x
    sta ss_clearbytes
    lda ss_xshift
    beq EraseCurrentWidthReady
    inc ss_clearbytes
EraseCurrentWidthReady:
    lda ss_xcell
    clc
    adc ss_clearbytes
    cmp #41
    bcc EraseCurrentWidthOkay
    jmp EraseCurrentNext
EraseCurrentWidthOkay:
    lda objectHeight,x
    sta ss_height
    jsr RestoreSpriteRect
EraseCurrentNext:
    ldx drawIndex
    inx
    jmp EraseCurrentLoop
EraseCurrentDone:
    rts

SaveCurrentObjectState:
    ldx #$00
SaveStateLoop:
    cpx #OBJ_COUNT
    beq SaveStateDone
    lda renderBuffer
    beq SaveStateA
    lda objectXLo,x
    sta objectPrevBXLo,x
    lda objectXHi,x
    sta objectPrevBXHi,x
    lda objectY,x
    sta objectPrevBY,x
    lda objectActive,x
    sta objectPrevBActive,x
    jmp SaveStateNext
SaveStateA:
    lda objectXLo,x
    sta objectPrevAXLo,x
    lda objectXHi,x
    sta objectPrevAXHi,x
    lda objectY,x
    sta objectPrevAY,x
    lda objectActive,x
    sta objectPrevAActive,x
SaveStateNext:
    inx
    jmp SaveStateLoop
SaveStateDone:
    rts

// Restore a dirty sprite rectangle. Current C64 runtime background is blank,
 // so restoration writes zero. When room-tile rendering is enabled, this is
 // the single hook that will copy the underlying room background instead.
// ------------------------------------------------------------
// Multicolor bitmap local-color compositor - VER 08.8.
//
// Color RAM ($D800) is NOT double-buffered. Writing per-object colors there
// while rendering the back bitmap made the currently displayed frame visibly
// change row-by-row before SwapDisplayBuffer.
//
// VER 08.8 keeps MC1 permanently in Color RAM and moves the per-object local
// color to the HIGH nibble of the screen byte. Screen RAM is already separate
// for bitmap A ($0400) and bitmap B ($4400), so local-color changes remain
// hidden until the matching bitmap is swapped to the VIC-II.
//
// Logical editor colors are encoded as:
//   value 1 (MC1)   -> VIC bitmap %11 -> Color RAM
//   value 2 (MC2)   -> VIC bitmap %10 -> screen low nibble
//   value 3 (local) -> VIC bitmap %01 -> screen high nibble
//
// Inputs:
//   A = local VIC color index
//   ss_xcell / ss_clearbytes = physical 8-pixel cells touched
//   ss_ypixel / ss_height    = physical vertical rectangle
// ------------------------------------------------------------
SetSoftwareHiresScreenRect:
    // A = foreground color. Preserve each cell's existing background nibble.
    and #$0f
    asl
    asl
    asl
    asl
    sta ss_color_value
    lda ss_ypixel
    lsr
    lsr
    lsr
    sta ss_color_row
    clc
    lda ss_ypixel
    adc ss_height
    bcc !hsc_bottom_no_overflow+
    lda #199
    jmp !hsc_bottom_ready+
!hsc_bottom_no_overflow:
    beq !hsc_bottom_zero+
    sec
    sbc #1
    cmp #200
    bcc !hsc_bottom_ready+
    lda #199
    jmp !hsc_bottom_ready+
!hsc_bottom_zero:
    lda #0
!hsc_bottom_ready:
    lsr
    lsr
    lsr
    sta ss_color_lastrow
!hsc_row_loop:
    lda ss_color_row
    cmp #25
    bcc !hsc_row_valid+
    rts
!hsc_row_valid:
    tay
    lda screenRowLo,y
    clc
    adc ss_xcell
    sta SS_DST_LO
    lda renderBuffer
    beq !hsc_use_a+
    lda screenRowHiB,y
    jmp !hsc_have_hi+
!hsc_use_a:
    lda screenRowHiA,y
!hsc_have_hi:
    adc #0
    sta SS_DST_HI
    ldy #0
!hsc_col_loop:
    cpy ss_clearbytes
    bcs !hsc_row_done+
    lda (SS_DST_LO),y
    and #$0f
    ora ss_color_value
    sta (SS_DST_LO),y
    iny
    jmp !hsc_col_loop-
!hsc_row_done:
    lda ss_color_row
    cmp ss_color_lastrow
    beq !hsc_done+
    inc ss_color_row
    jmp !hsc_row_loop-
!hsc_done:
    rts

SetSoftwareScreenRect:
    and #$0f
    asl
    asl
    asl
    asl
    ora #SCENE_MC2
    sta ss_color_value

    lda ss_ypixel
    lsr
    lsr
    lsr
    sta ss_color_row

    clc
    lda ss_ypixel
    adc ss_height
    bcc SetScreenBottomNoOverflow
    lda #199
    jmp SetScreenBottomReady
SetScreenBottomNoOverflow:
    beq SetScreenBottomZero
    sec
    sbc #$01
    cmp #200
    bcc SetScreenBottomReady
    lda #199
    jmp SetScreenBottomReady
SetScreenBottomZero:
    lda #$00
SetScreenBottomReady:
    lsr
    lsr
    lsr
    sta ss_color_lastrow

SetScreenRowLoop:
    lda ss_color_row
    cmp #25
    bcc SetScreenRowValid
    rts
SetScreenRowValid:
    tay
    lda screenRowLo,y
    clc
    adc ss_xcell
    sta SS_DST_LO

    lda renderBuffer
    beq SetScreenUseA
    lda screenRowHiB,y
    jmp SetScreenHaveHi
SetScreenUseA:
    lda screenRowHiA,y
SetScreenHaveHi:
    adc #$00
    sta SS_DST_HI

    ldy #$00
SetScreenColumnLoop:
    cpy ss_clearbytes
    bcc SetScreenWrite
    jmp SetScreenRowDone
SetScreenWrite:
    lda ss_color_value
    sta (SS_DST_LO),y
    iny
    jmp SetScreenColumnLoop

SetScreenRowDone:
    lda ss_color_row
    cmp ss_color_lastrow
    beq SetScreenDone
    inc ss_color_row
    jmp SetScreenRowLoop
SetScreenDone:
    rts

// Return the original Room background byte for screen byte X/Y.
// restoreAbsXByte = 0..39, ss_cur_y = 0..199. A returns bitmap byte.
GetRoomBackgroundByte:
    lda restoreAbsXByte
    cmp #40
    bcc GetRoomBGXValid
    lda #$00
    rts
GetRoomBGXValid:
    lda ss_cur_y
    cmp #200
    bcc GetRoomBGYValid
    lda #$00
    rts
GetRoomBGYValid:

    // Tile column from physical X = bitmap byte * 8.
    lda restoreAbsXByte
    cmp #32
    bcc GetRoomBGXPage0
    sec
    sbc #32
    asl
    asl
    asl
    tay
    lda ROOM_XCELL_LO
    sta SS_MASK_LO
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_MASK_HI
    lda (SS_MASK_LO),y
    sta restoreTileCol
    jmp GetRoomBGXCellReady
GetRoomBGXPage0:
    asl
    asl
    asl
    tay
    lda ROOM_XCELL_LO
    sta SS_MASK_LO
    lda ROOM_XCELL_HI
    sta SS_MASK_HI
    lda (SS_MASK_LO),y
    sta restoreTileCol
GetRoomBGXCellReady:

    // Tile row and room-map row offset from Y.
    ldy ss_cur_y
    lda (ROOM_YCELL_LO),y
    sta restoreTileRow
    lda (ROOM_YOFFLO_LO),y
    sta tileMapIndexLo
    lda (ROOM_YOFFHI_LO),y
    sta tileMapIndexHi

    // Map address = room map + row offset + tile column.
    clc
    lda ROOM_MAP_LO
    adc tileMapIndexLo
    sta SS_MASK_LO
    lda ROOM_MAP_HI
    adc tileMapIndexHi
    sta SS_MASK_HI
    clc
    lda SS_MASK_LO
    adc restoreTileCol
    sta SS_MASK_LO
    bcc GetRoomBGMapReady
    inc SS_MASK_HI
GetRoomBGMapReady:
    ldy #$00
    lda (SS_MASK_LO),y
    cmp #$ff
    bne GetRoomBGHaveTile
    lda #$00
    rts

GetRoomBGHaveTile:
    tay
    lda (ROOM_PTRLO_LO),y
    sta SS_IMG_LO
    lda (ROOM_PTRHI_LO),y
    sta SS_IMG_HI

    // within-X byte = absolute bitmap byte - tileCol * tileWidthBytes.
    lda #$00
    sta restoreTemp
    ldx restoreTileCol
GetRoomBGWithinXLoop:
    cpx #$00
    beq GetRoomBGWithinXReady
    clc
    lda restoreTemp
    adc roomTileWidthBytesRT
    sta restoreTemp
    dex
    jmp GetRoomBGWithinXLoop
GetRoomBGWithinXReady:
    sec
    lda restoreAbsXByte
    sbc restoreTemp
    sta restoreWithinX

    // within-Y = y - tileRow * tileHeight.
    lda #$00
    sta restoreTemp
    ldx restoreTileRow
GetRoomBGWithinYLoop:
    cpx #$00
    beq GetRoomBGWithinYReady
    clc
    lda restoreTemp
    adc roomTileHeightRT
    sta restoreTemp
    dex
    jmp GetRoomBGWithinYLoop
GetRoomBGWithinYReady:
    sec
    lda ss_cur_y
    sbc restoreTemp
    sta restoreWithinY

    // Source offset = withinY * widthBytes + withinX.
    lda #$00
    sta restoreOffsetLo
    sta restoreOffsetHi
    ldx restoreWithinY
GetRoomBGOffsetLoop:
    cpx #$00
    beq GetRoomBGOffsetReady
    clc
    lda restoreOffsetLo
    adc roomTileWidthBytesRT
    sta restoreOffsetLo
    bcc GetRoomBGOffsetNoCarry
    inc restoreOffsetHi
GetRoomBGOffsetNoCarry:
    dex
    jmp GetRoomBGOffsetLoop
GetRoomBGOffsetReady:
    clc
    lda restoreOffsetLo
    adc restoreWithinX
    sta restoreOffsetLo
    bcc GetRoomBGOffsetAdded
    inc restoreOffsetHi
GetRoomBGOffsetAdded:

    clc
    lda SS_IMG_LO
    adc restoreOffsetLo
    sta SS_IMG_LO
    lda SS_IMG_HI
    adc restoreOffsetHi
    sta SS_IMG_HI
    ldy #$00
    lda (SS_IMG_LO),y
    rts

RestoreSpriteRect:
    // Restore the back buffer's per-cell local color as well as its bitmap bytes.
    // This writes only the non-visible screen buffer; Color RAM is untouched.
    lda #SCENE_MODE
    beq RestoreRectSkipColor
    lda #SCENE_LOCAL
    jsr SetSoftwareScreenRect
RestoreRectSkipColor:
    // Load Room/tile pointers once for this dirty rectangle.
    lda currentRoom
    jsr FindRoomTileMeta
    bcs RestoreRectHaveMeta
    jmp ClearSpriteRectFallback
RestoreRectHaveMeta:
    jsr LoadRoomTilePointers
    // VER 09.1: A Room can have tile metadata even when it has no tile
    // graphics/pointer tables (for example a plain bitmap/card-game room).
    // The old path still called GetRoomBackgroundByte in that case, causing
    // null-pointer reads through $0000 and bogus tile-row/column loops.  That
    // produced software-sprite trails, corrupted restores, and severe stalls.
    // If no tile pointer table exists, restore as a plain background instead.
    lda ROOM_PTRLO_LO
    ora ROOM_PTRLO_HI
    bne RestoreRectTileDataReady
    jmp ClearSpriteRectFallback
RestoreRectTileDataReady:

    lda ss_xcell
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    lda ss_ypixel
    sta ss_cur_y
    lda ss_height
    sta ss_rows_left

RestoreRectRow:
    lda ss_cur_y
    cmp #200
    bcc RestoreRectRowOkay
    rts
RestoreRectRowOkay:
    jsr SetDestinationFromCurrentRow
    lda #$00
    sta ss_col

RestoreRectByte:
    clc
    lda ss_xcell
    adc ss_col
    sta restoreAbsXByte
    jsr GetRoomBackgroundByte
    ldx ss_col
    ldy offset8,x
    sta (SS_DST_LO),y
    inc ss_col
    lda ss_col
    cmp ss_clearbytes
    bne RestoreRectByte

    inc ss_cur_y
    dec ss_rows_left
    bne RestoreRectRow
    rts

ClearSpriteRectFallback:
    lda ss_xcell
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    lda ss_ypixel
    sta ss_cur_y
    lda ss_height
    sta ss_rows_left
ClearFallbackRow:
    lda ss_cur_y
    cmp #200
    bcs ClearFallbackDone
    jsr SetDestinationFromCurrentRow
    lda #$00
    sta ss_col
ClearFallbackByte:
    ldx ss_col
    ldy offset8,x
    lda #$00
    sta (SS_DST_LO),y
    inc ss_col
    lda ss_col
    cmp ss_clearbytes
    bne ClearFallbackByte
    inc ss_cur_y
    dec ss_rows_left
    bne ClearFallbackRow
ClearFallbackDone:
    rts

// VER 09.1 named path runtime. Each active object moves toward its current
// waypoint, then advances according to Loop / Patrol / Once mode.
pathObjIndex: .byte 0
pathTargetXLo: .byte 0
pathTargetXHi: .byte 0
pathTargetY: .byte 0
pathTempIndex: .byte 0
pathDiffLo: .byte 0

// Move object X toward object Y by A pixels on each axis.
// X=self runtime index, Y=target runtime index, A=speed (1-16).
// Movement is performed as one-pixel steps so it cannot overshoot a target.
MoveIndexTowardIndex:
    sta pathMoveSpeed
    stx pathMoveSelf
    sty pathMoveTarget
!mt_step:
    lda pathMoveSpeed
    beq !mt_done+
    dec pathMoveSpeed
    ldx pathMoveSelf
    ldy pathMoveTarget
    lda objectXHi,x
    cmp objectXHi,y
    bcc !mt_x_right+
    bne !mt_x_left+
    lda objectXLo,x
    cmp objectXLo,y
    bcc !mt_x_right+
    beq !mt_y+
!mt_x_left:
    lda objectXLo,x
    bne !mt_x_left_low+
    dec objectXHi,x
!mt_x_left_low:
    dec objectXLo,x
    jmp !mt_y+
!mt_x_right:
    inc objectXLo,x
    bne !mt_y+
    inc objectXHi,x
!mt_y:
    ldx pathMoveSelf
    ldy pathMoveTarget
    lda objectY,x
    cmp objectY,y
    bcc !mt_y_down+
    beq !mt_next+
    dec objectY,x
    jmp !mt_next+
!mt_y_down:
    inc objectY,x
!mt_next:
    jmp !mt_step-
!mt_done:
    rts

pathMoveSpeed: .byte 1
pathMoveSelf: .byte 0
pathMoveTarget: .byte 0

UpdatePaths:
    ldx #$00
UpdatePathsLoop:
    cpx #OBJ_COUNT
    bne PathHaveObject
    jmp UpdatePathsDone
PathHaveObject:
    stx pathObjIndex
    lda objectActive,x
    bne PathObjectActive
    jmp UpdatePathsNext
PathObjectActive:
    lda objectPathActive,x
    bne PathObjectPathActive
    jmp UpdatePathsNext
PathObjectPathActive:
    lda objectPathId,x
    cmp #$ff
    bne PathHaveId
    jmp UpdatePathsNext
PathHaveId:
    tay
    cpy #PATH_COUNT
    bcc PathIdValid
    jmp UpdatePathsNext
PathIdValid:
    lda pathCount,y
    bne PathCountValid
    jmp UpdatePathsNext
PathCountValid:
    lda pathStart,y
    clc
    adc objectPathPoint,x
    sta pathTempIndex
    tay
    lda pathPointXLo,y
    sta pathTargetXLo
    lda pathPointXHi,y
    sta pathTargetXHi
    lda pathPointY,y
    sta pathTargetY

    // X: determine direction from 9-bit current/target values.
    ldx pathObjIndex
    lda objectXHi,x
    cmp pathTargetXHi
    bcc PathXPositive
    bne PathXNegative
    lda objectXLo,x
    cmp pathTargetXLo
    bcc PathXPositive
    beq PathMoveYStart

PathXNegative:
    // diff = current - target. Clamp when diff <= speed.
    sec
    lda objectXLo,x
    sbc pathTargetXLo
    sta pathDiffLo
    lda objectXHi,x
    sbc pathTargetXHi
    bne PathXNegativeStep
    ldy objectPathId,x
    lda pathDiffLo
    cmp pathSpeed,y
    bcc PathClampX
    beq PathClampX
PathXNegativeStep:
    ldy objectPathId,x
    sec
    lda objectXLo,x
    sbc pathSpeed,y
    sta objectXLo,x
    lda objectXHi,x
    sbc #$00
    and #$01
    sta objectXHi,x
    jmp PathMoveYStart

PathXPositive:
    // diff = target - current. Clamp when diff <= speed.
    sec
    lda pathTargetXLo
    sbc objectXLo,x
    sta pathDiffLo
    lda pathTargetXHi
    sbc objectXHi,x
    bne PathXPositiveStep
    ldy objectPathId,x
    lda pathDiffLo
    cmp pathSpeed,y
    bcc PathClampX
    beq PathClampX
PathXPositiveStep:
    ldy objectPathId,x
    clc
    lda objectXLo,x
    adc pathSpeed,y
    sta objectXLo,x
    lda objectXHi,x
    adc #$00
    and #$01
    sta objectXHi,x
    jmp PathMoveYStart

PathClampX:
    lda pathTargetXLo
    sta objectXLo,x
    lda pathTargetXHi
    sta objectXHi,x

PathMoveYStart:
    lda objectY,x
    cmp pathTargetY
    bcc PathYPositive
    beq PathCheckArrived

PathYNegative:
    sec
    lda objectY,x
    sbc pathTargetY
    sta pathDiffLo
    ldy objectPathId,x
    lda pathDiffLo
    cmp pathSpeed,y
    bcc PathClampY
    beq PathClampY
    sec
    lda objectY,x
    sbc pathSpeed,y
    sta objectY,x
    jmp PathCheckArrived

PathYPositive:
    sec
    lda pathTargetY
    sbc objectY,x
    sta pathDiffLo
    ldy objectPathId,x
    lda pathDiffLo
    cmp pathSpeed,y
    bcc PathClampY
    beq PathClampY
    clc
    lda objectY,x
    adc pathSpeed,y
    sta objectY,x
    jmp PathCheckArrived
PathClampY:
    lda pathTargetY
    sta objectY,x

PathCheckArrived:
    lda objectXHi,x
    cmp pathTargetXHi
    bne UpdatePathsNext
    lda objectXLo,x
    cmp pathTargetXLo
    bne UpdatePathsNext
    lda objectY,x
    cmp pathTargetY
    bne UpdatePathsNext
    jsr AdvancePathWaypoint
UpdatePathsNext:
    ldx pathObjIndex
    inx
    jmp UpdatePathsLoop
UpdatePathsDone:
    rts

AdvancePathWaypoint:
    ldx pathObjIndex
    ldy objectPathId,x
    lda pathCount,y
    cmp #$02
    bcs PathAdvanceMulti
    lda pathMode,y
    cmp #$02
    bne PathAdvanceDone
    lda #$00
    sta objectPathActive,x
    lda #$01
    sta objectPathDone,x
PathAdvanceDone:
    rts
PathAdvanceMulti:
    lda pathMode,y
    cmp #$01
    beq PathAdvancePatrol
    cmp #$02
    beq PathAdvanceOnce
    // Loop
    inc objectPathPoint,x
    lda objectPathPoint,x
    cmp pathCount,y
    bcc PathAdvanceDone
    lda #$00
    sta objectPathPoint,x
    rts
PathAdvanceOnce:
    inc objectPathPoint,x
    lda objectPathPoint,x
    cmp pathCount,y
    bcc PathAdvanceDone
    lda pathCount,y
    sec
    sbc #$01
    sta objectPathPoint,x
    lda #$00
    sta objectPathActive,x
    lda #$01
    sta objectPathDone,x
    rts
PathAdvancePatrol:
    lda objectPathDir,x
    bmi PathPatrolBackward
    inc objectPathPoint,x
    lda objectPathPoint,x
    cmp pathCount,y
    bcc PathAdvanceDone
    lda pathCount,y
    sec
    sbc #$02
    sta objectPathPoint,x
    lda #$ff
    sta objectPathDir,x
    rts
PathPatrolBackward:
    lda objectPathPoint,x
    beq PathPatrolTurnForward
    dec objectPathPoint,x
    rts
PathPatrolTurnForward:
    lda #$01
    sta objectPathDir,x
    sta objectPathPoint,x
    rts

SaveLogicPositions:
    ldx #$00
SaveLogicPositionLoop:
    cpx #OBJ_COUNT
    beq SaveLogicPositionsDone
    lda objectXLo,x
    sta objectLastXLo,x
    lda objectXHi,x
    sta objectLastXHi,x
    lda objectY,x
    sta objectLastY,x
    inx
    jmp SaveLogicPositionLoop
SaveLogicPositionsDone:
    rts

UpdateAnimations:
    ldx #$00
UpdateAnimLoop:
    cpx #OBJ_COUNT
    bne UpdateAnimContinue
    jmp UpdateAnimDone
UpdateAnimContinue:
    lda objectActive,x
    beq UpdateAnimNext
    lda objectAutoAnimate,x
    beq UpdateAnimNext
    lda objectFrameCount,x
    cmp #2
    bcc UpdateAnimNext
    lda objectAnimLoop,x
    bne UpdateAnimAdvance
    lda objectFrame,x
    clc
    adc #1
    cmp objectFrameCount,x
    bcs UpdateAnimNext
UpdateAnimAdvance:
    inc objectAnimTimer,x
    lda objectAnimTimer,x
    cmp objectAnimDuration,x
    bcc UpdateAnimNext
    lda #$00
    sta objectAnimTimer,x
    inc objectFrame,x
    lda objectFrame,x
    cmp objectFrameCount,x
    bcc UpdateAnimNext
    lda objectAnimLoop,x
    beq UpdateAnimClampLast
    lda #$00
    sta objectFrame,x
    jmp UpdateAnimNext
UpdateAnimClampLast:
    lda objectFrameCount,x
    sec
    sbc #1
    sta objectFrame,x
UpdateAnimNext:
    inx
    jmp UpdateAnimLoop
UpdateAnimDone:
    rts

DrawAllObjects:
    lda #$00
    sta drawOrderPos
DrawObjectLoop:
    ldy drawOrderPos
    cpy #OBJ_COUNT
    bne DrawObjectContinue
    jmp DrawObjectDone
DrawObjectContinue:
    ldx objectDrawOrder,y
    stx drawIndex
    lda objectRenderer,x
    beq DrawObjectContinueSoftware
    jmp DrawObjectNext
DrawObjectContinueSoftware:
    lda objectRoom,x
    cmp currentRoom
    beq DrawObjectContinueSoftwareRoomOkay
    jmp DrawObjectNext
DrawObjectContinueSoftwareRoomOkay:
    lda objectActive,x
    bne DrawActiveOkay
    jmp DrawObjectNext
DrawActiveOkay:
    lda objectMode,x
    cmp #SCENE_MODE
    beq DrawModeOkay
    jmp DrawObjectNext
DrawModeOkay:
    lda objectY,x
    cmp #200
    bcc DrawYOkay
    jmp DrawObjectNext
DrawYOkay:

    lda objectXLo,x
    sta ss_img_temp
    lda objectMode,x
    beq DrawShiftHires
    lda ss_img_temp
    and #$06
    sta ss_xshift
    jmp DrawShiftDone
DrawShiftHires:
    lda ss_img_temp
    and #$07
    sta ss_xshift
DrawShiftDone:
    lda ss_img_temp
    lsr
    lsr
    lsr
    sta ss_xcell
    lda objectXHi,x
    beq DrawXHiDone
    lda ss_xcell
    clc
    adc #32
    sta ss_xcell
DrawXHiDone:
    lda ss_xcell
    cmp #40
    bcc DrawXInBounds
    jmp DrawObjectNext
DrawXInBounds:

    lda objectWidthBytes,x
    sta ss_widthbytes
    sta ss_clearbytes
    lda ss_xshift
    beq DrawWidthReady
    inc ss_clearbytes
DrawWidthReady:
    lda ss_xcell
    clc
    adc ss_clearbytes
    cmp #41
    bcc DrawWidthInBounds
    jmp DrawObjectNext
DrawWidthInBounds:

    lda objectDataLo,x
    sta SS_IMG_LO
    lda objectDataHi,x
    sta SS_IMG_HI

    lda objectFrame,x
    sta ss_count
    beq DrawFrameReady
DrawFrameAdvance:
    clc
    lda SS_IMG_LO
    adc objectFrameSizeLo,x
    sta SS_IMG_LO
    lda SS_IMG_HI
    adc objectFrameSizeHi,x
    sta SS_IMG_HI
    dec ss_count
    bne DrawFrameAdvance

DrawFrameReady:
    clc
    lda SS_IMG_LO
    adc objectImageBytesLo,x
    sta SS_MASK_LO
    lda SS_IMG_HI
    adc objectImageBytesHi,x
    sta SS_MASK_HI

    lda objectY,x
    sta ss_ypixel
    lda objectHeight,x
    sta ss_height
    lda objectMode,x
    beq DrawHiresObject
    lda objectUsesLocal,x
    beq DrawMulticolorPixels
    lda objectVICColor,x
    jsr SetSoftwareScreenRect
DrawMulticolorPixels:
    jsr BlitMulticolorShifted
    jmp DrawObjectNext
DrawHiresObject:
    // Hires bitmap pixels take their foreground color from the screen-RAM
    // high nibble.  Previously software hires sprites changed bitmap bits but
    // never supplied their sprite color, so they appeared white/black.
    lda objectVICColor,x
    jsr SetSoftwareHiresScreenRect
    jsr BlitHiresShifted

DrawObjectNext:
    inc drawOrderPos
    jmp DrawObjectLoop
DrawObjectDone:
    rts

// ------------------------------------------------------------
// VIC-II hardware sprite renderer.
// First eight active VIC-rendered object-table entries get hardware slots 0-7.
// X/Y are game coordinates; VIC register coordinates add the visible-area
// offsets (24,50). Pointer bytes are mirrored to both screen buffers.
// ------------------------------------------------------------
// ------------------------------------------------------------
// VIC-II raster multiplexer - VER 07.0
//
// Up to 16 active VIC-rendered object-table entries are collected and sorted
// by Y each frame. The first eight occupy hardware slots 0-7. Later sprites
// reuse a slot only after that slot's previous 21-line sprite has cleared.
// Reuse is scheduled by raster IRQ shortly before the next sprite begins.
// ------------------------------------------------------------
UpdateVICSprites:
    // VER 09.12: keep VIC slot collection/sort/register commit atomic.
    // A KERNAL IRQ in the middle of the update used to be allowed after the
    // old mux chain was disabled; keeping the caller's IRQ state preserved
    // ensures live object X/Y and slot assignment are committed as one unit.
    php
    sei
    lda #$00
    sta $d01a
    lda #$01
    sta $d019

    lda #$00
    sta vicEnableMask
    sta vicMulticolorMask
    sta vicXHighMask
    sta vicSortedCount
    sta muxEventCount
    sta muxEventPos

    // Collect up to 16 active VIC objects in the current room.
    ldx #$00
VICCollectLoop:
    cpx #OBJ_COUNT
    bne VICCollectContinue
    jmp VICCollectDone
VICCollectContinue:
    stx vicObjectIndex
    lda objectRenderer,x
    cmp #$01
    bne VICCollectNext
    lda objectActive,x
    beq VICCollectNext
    lda objectRoom,x
    cmp currentRoom
    bne VICCollectNext
    ldy vicSortedCount
    cpy #$10
    bcs VICCollectDone
    txa
    sta vicSortedObjects,y
    inc vicSortedCount
VICCollectNext:
    ldx vicObjectIndex
    inx
    jmp VICCollectLoop

VICCollectDone:
    jsr VICSortByY

    // Mark every slot free. slotEndY is the earliest game-Y at which it can
    // safely be reused.
    ldx #$00
VICClearSlotEnds:
    lda #$00
    sta vicSlotEndY,x
    inx
    cpx #$08
    bne VICClearSlotEnds

    // Draw first eight sorted sprites directly.
    lda #$00
    sta vicSortPos
VICInitialLoop:
    lda vicSortPos
    cmp vicSortedCount
    bcc VICInitialHasObject
    jmp VICInitialDone
VICInitialHasObject:
    cmp #$08
    bcc VICInitialUseSlot
    jmp VICInitialDone
VICInitialUseSlot:
    tay
    lda vicSortedObjects,y
    tax
    sty vicSlot
    jsr VICWriteObjectToSlot

    // This slot may be reused once Y + 22 has been reached.
    ldx vicObjectIndex
    lda objectY,x
    clc
    adc #22
    bcc VICInitialEndOkay
    lda #$ff
VICInitialEndOkay:
    ldy vicSlot
    sta vicSlotEndY,y

    inc vicSortPos
    jmp VICInitialLoop

VICInitialDone:
    // Remaining sorted objects become raster reuse events when a slot is free.
    lda #$08
    sta vicSortPos
VICSchedObjectLoop:
    lda vicSortPos
    cmp vicSortedCount
    bcc VICSchedHaveObject
    jmp VICSchedDone
VICSchedHaveObject:
    tay
    lda vicSortedObjects,y
    sta muxCandidateObject
    tax
    lda objectY,x
    sta muxCandidateY

    lda #$00
    sta muxSearchSlot
VICSchedSlotLoop:
    lda muxSearchSlot
    cmp #$08
    bcc VICSchedCheckSlot
    jmp VICSchedObjectNext
VICSchedCheckSlot:
    // A reused VIC slot needs enough vertical blank time to rewrite its
    // registers before the next sprite DMA starts.  The previous test only
    // required candidateY >= slotEndY and then scheduled the IRQ two lines
    // before the new sprite.  On a KERNAL-vectored IRQ that margin is too
    // small and produced intermittent old-slot contents (visible flashing).
    // Require at least an 8-line game-coordinate gap beyond slotEndY.
    tay
    lda vicSlotEndY,y
    clc
    adc #8
    bcs VICSchedSlotTooClose
    cmp muxCandidateY
    bcc VICSchedSlotFound
    beq VICSchedSlotFound
VICSchedSlotTooClose:
    inc muxSearchSlot
    jmp VICSchedSlotLoop

VICSchedSlotFound:
    ldx muxEventCount
    cpx #$08
    bcc VICSchedStore
    jmp VICSchedDone
VICSchedStore:
    lda muxCandidateObject
    sta muxEventObject,x
    lda muxSearchSlot
    sta muxEventSlot,x

    // VIC Y register is game Y + 50.  Schedule the reuse IRQ eight raster
    // lines before sprite start, giving the KERNAL-vector path ample time to
    // rewrite X/Y/pointer/color/mode before sprite DMA begins.
    lda muxCandidateY
    clc
    adc #42
    sta muxEventRaster,x
    inc muxEventCount

    // Update availability for a possible later reuse of the same slot.
    lda muxCandidateY
    clc
    adc #22
    bcc VICSchedEndOkay
    lda #$ff
VICSchedEndOkay:
    ldy muxSearchSlot
    sta vicSlotEndY,y

VICSchedObjectNext:
    inc vicSortPos
    jmp VICSchedObjectLoop

VICSchedDone:
    jsr VICCommitMasks

    // Arm the raster IRQ chain only when reuse events exist.
    lda muxEventCount
    beq VICDisableMuxIRQ
    lda #$00
    sta muxEventPos
    tay
    lda muxEventRaster,y
    sta $d012
    lda $d011
    and #$7f
    sta $d011
    lda #$01
    sta $d019
    sta $d01a
    plp
    rts
VICDisableMuxIRQ:
    lda #$00
    sta $d01a
    plp
    rts

// Bubble-sort collected object indexes by objectY (maximum 16 entries).
VICSortByY:
    lda vicSortedCount
    cmp #$02
    bcs VICSortStart
    rts
VICSortStart:
    lda #$00
    sta vicSortPass
VICSortOuter:
    lda #$00
    sta vicSortPos
VICSortInner:
    lda vicSortPos
    clc
    adc #$01
    cmp vicSortedCount
    bcc VICSortPair
    inc vicSortPass
    lda vicSortPass
    cmp vicSortedCount
    bcc VICSortOuter
    rts
VICSortPair:
    ldx vicSortPos
    lda vicSortedObjects,x
    sta vicSortObjA
    tay
    lda objectY,y
    sta vicSortYA
    inx
    lda vicSortedObjects,x
    sta vicSortObjB
    tay
    lda objectY,y
    cmp vicSortYA
    bcs VICSortNoSwap
    ldx vicSortPos
    lda vicSortObjB
    sta vicSortedObjects,x
    inx
    lda vicSortObjA
    sta vicSortedObjects,x
VICSortNoSwap:
    inc vicSortPos
    jmp VICSortInner

// X = object index, vicSlot = hardware slot.
VICWriteObjectToSlot:
    stx vicObjectIndex
    ldy vicSlot

    // Enable the slot.
    lda bitTable,y
    ora vicEnableMask
    sta vicEnableMask

    // Clear this slot's previous X-high and multicolor state.
    lda bitTable,y
    eor #$ff
    and vicXHighMask
    sta vicXHighMask
    lda bitTable,y
    eor #$ff
    and vicMulticolorMask
    sta vicMulticolorMask

    // X = object X + 24.
    ldx vicObjectIndex
    clc
    lda objectXLo,x
    adc #24
    sta vicTempXLo
    lda objectXHi,x
    adc #0
    sta vicTempXHi

    ldy vicSlot
    tya
    asl
    tay
    lda vicTempXLo
    sta $d000,y

    // Y = object Y + 50.
    ldx vicObjectIndex
    clc
    lda objectY,x
    adc #50
    iny
    sta $d000,y

    // X high bit.
    lda vicTempXHi
    beq VICWriteNoXHigh
    ldy vicSlot
    lda bitTable,y
    ora vicXHighMask
    sta vicXHighMask
VICWriteNoXHigh:

    // Multicolor bit.
    ldx vicObjectIndex
    lda objectMode,x
    beq VICWriteHires
    ldy vicSlot
    lda bitTable,y
    ora vicMulticolorMask
    sta vicMulticolorMask
VICWriteHires:

    // Local color and frame pointer.
    ldy vicSlot
    lda objectVICColor,x
    sta $d027,y
    clc
    lda objectVICBasePtr,x
    adc objectFrame,x
    sta $07f8,y
    sta $47f8,y
    rts

VICCommitMasks:
    lda vicXHighMask
    sta $d010
    lda vicMulticolorMask
    sta $d01c
    lda vicEnableMask
    sta $d015
    rts

// Raster IRQ: reuse slots for scheduled lower-screen sprites. Events with the
// same raster line are processed in one interrupt.
RasterMuxIRQ:
    // This handler is installed through $0314/$0315. The KERNAL entry at
    // $FF48 has ALREADY pushed A, X and Y before jumping here. Do not push
    // another copy and do not RTI directly; finish custom raster work via
    // the KERNAL register-restore/RTI exit at $EA81.
    lda $d019
    and #$01
    bne RasterMuxIsRaster
    jmp (oldIRQVector)

RasterMuxIsRaster:
    lda #$01
    sta $d019

RasterMuxEventLoop:
    ldx muxEventPos
    cpx muxEventCount
    bcc RasterMuxHaveEvent
    jmp RasterMuxFinishFrame
RasterMuxHaveEvent:
    lda muxEventObject,x
    sta vicObjectIndex
    lda muxEventSlot,x
    sta vicSlot
    ldx vicObjectIndex
    jsr VICWriteObjectToSlot
    jsr VICCommitMasks

    inc muxEventPos
    ldx muxEventPos
    cpx muxEventCount
    bcc RasterMuxCheckNext
    jmp RasterMuxFinishFrame
RasterMuxCheckNext:
    lda muxEventRaster,x
    cmp $d012
    beq RasterMuxEventLoop
    sta $d012
    jmp $ea81

RasterMuxFinishFrame:
    lda #$00
    sta $d01a
    jmp $ea81

InitRasterMultiplexer:
    sei
    lda $0314
    sta oldIRQVector
    lda $0315
    sta oldIRQVector+1
    lda #<RasterMuxIRQ
    sta $0314
    lda #>RasterMuxIRQ
    sta $0315
    lda #$01
    sta $d019
    lda #$00
    sta $d01a
    cli
    rts

oldIRQVector: .word 0
vicTempXLo: .byte 0
vicTempXHi: .byte 0
vicSortedCount: .byte 0
vicSortPass: .byte 0
vicSortPos: .byte 0
vicSortObjA: .byte 0
vicSortObjB: .byte 0
vicSortYA: .byte 0
muxCandidateObject: .byte 0
muxCandidateY: .byte 0
muxSearchSlot: .byte 0
muxEventCount: .byte 0
muxEventPos: .byte 0
vicSortedObjects:
    .fill 16,0
vicSlotEndY:
    .fill 8,0
muxEventObject:
    .fill 8,0
muxEventSlot:
    .fill 8,0
muxEventRaster:
    .fill 8,0
bitTable:
    .byte $01,$02,$04,$08,$10,$20,$40,$80

BlitHiresShifted:
    lda ss_xcell
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi

    lda ss_ypixel
    sta ss_cur_y
    lda ss_height
    sta ss_rows_left

ShiftBlitRow:
    lda ss_cur_y
    cmp #200
    bcc ShiftBlitRowInBounds
    jmp ShiftBlitDone
ShiftBlitRowInBounds:
    jsr SetDestinationFromCurrentRow
    lda #$00
    sta ss_col

ShiftBlitByte:
    ldy #$00
    lda (SS_IMG_LO),y
    sta ss_img_temp
    lda #$00
    sta ss_spill_temp
    // Hires shifts are 0..7. Use fall-through unrolled shifts instead of
    // a DEC/BNE loop for every image byte.
    lda ss_xshift
    beq ShiftReady
    cmp #$01
    beq ShiftOne
    cmp #$02
    beq ShiftTwo
    cmp #$03
    beq ShiftThree
    cmp #$04
    beq ShiftFour
    cmp #$05
    beq ShiftFive
    cmp #$06
    beq ShiftSix
    // 7 falls through all seven single-bit shifts.
ShiftSeven:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftSix:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftFive:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftFour:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftThree:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftTwo:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftOne:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftReady:
    ldx ss_col
    ldy offset8,x
    lda (SS_DST_LO),y
    ora ss_img_temp
    sta (SS_DST_LO),y

    lda ss_xshift
    beq NoSpill
    inx
    ldy offset8,x
    lda (SS_DST_LO),y
    ora ss_spill_temp
    sta (SS_DST_LO),y
NoSpill:
    inc SS_IMG_LO
    bne ImgPtrDone
    inc SS_IMG_HI
ImgPtrDone:
    inc ss_col
    lda ss_col
    cmp ss_widthbytes
    beq ShiftBlitRowFinished
    jmp ShiftBlitByte
ShiftBlitRowFinished:
    inc ss_cur_y
    dec ss_rows_left
    beq ShiftBlitDone
    jmp ShiftBlitRow
ShiftBlitDone:
    rts

// ------------------------------------------------------------
// BlitMulticolorShifted
// 2-bit multicolor image + compact 1-bit logical occupancy mask.
// Odd physical X is rounded down because MC pixels are two pixels wide.
// ------------------------------------------------------------
BlitMulticolorShifted:
    lda ss_xcell
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    lda ss_xshift
    lsr
    sta ss_mc_shift
    lda ss_ypixel
    sta ss_cur_y
    lda ss_height
    sta ss_rows_left
MCRowLoop:
    lda ss_cur_y
    cmp #200
    bcc MCRowInBounds
    jmp MCDone
MCRowInBounds:
    jsr SetDestinationFromCurrentRow
    lda #$00
    sta ss_col
MCByteLoop:
    lda ss_col
    and #$01
    bne MCUseLowMask
    ldy #$00
    lda (SS_MASK_LO),y
    sta ss_mc_maskbyte
    inc SS_MASK_LO
    bne MCMaskPtrReady
    inc SS_MASK_HI
MCMaskPtrReady:
    lda ss_mc_maskbyte
    lsr
    lsr
    lsr
    lsr
    tax
    lda mcMaskExpand,x
    sta ss_mask_temp
    jmp MCMaskReady
MCUseLowMask:
    lda ss_mc_maskbyte
    and #$0f
    tax
    lda mcMaskExpand,x
    sta ss_mask_temp
MCMaskReady:
    ldy #$00
    lda (SS_IMG_LO),y
    sta ss_img_temp
    lda #$00
    sta ss_spill_temp
    sta ss_mask_spill
    // ss_mc_shift is only 0..3. Unroll the variable-count loop so every
    // sprite byte avoids DEC/BNE loop overhead in this hot path.
    lda ss_mc_shift
    beq MCShiftReady
    cmp #$01
    beq MCShiftOne
    cmp #$02
    beq MCShiftTwo
    // Shift three logical multicolor pixels = six physical bits.
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_mask_temp
    ror ss_mask_spill
    lsr ss_mask_temp
    ror ss_mask_spill
MCShiftTwo:
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_mask_temp
    ror ss_mask_spill
    lsr ss_mask_temp
    ror ss_mask_spill
MCShiftOne:
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_mask_temp
    ror ss_mask_spill
    lsr ss_mask_temp
    ror ss_mask_spill
MCShiftReady:
    ldx ss_col
    ldy offset8,x
    lda ss_mask_temp
    eor #$ff
    and (SS_DST_LO),y
    ora ss_img_temp
    sta (SS_DST_LO),y
    lda ss_mc_shift
    beq MCNoSpill
    inx
    ldy offset8,x
    lda ss_mask_spill
    eor #$ff
    and (SS_DST_LO),y
    ora ss_spill_temp
    sta (SS_DST_LO),y
MCNoSpill:
    inc SS_IMG_LO
    bne MCImgPtrReady
    inc SS_IMG_HI
MCImgPtrReady:
    inc ss_col
    lda ss_col
    cmp ss_widthbytes
    beq MCRowFinished
    jmp MCByteLoop
MCRowFinished:
    inc ss_cur_y
    dec ss_rows_left
    beq MCDone
    jmp MCRowLoop
MCDone:
    rts

// ------------------------------------------------------------
// Axis-aligned object collision support.
// Software sprites collide using their physical rectangular bounds.
// Width is objectWidthBytes * 8 physical pixels for both hires and MC.
// ------------------------------------------------------------
collisionSourceIndex: .byte 0
collisionCandidateIndex: .byte 0
collisionOtherIndex: .byte $ff
collisionTargetSprite: .byte 0
colAXLo: .byte 0
colAXHi: .byte 0
colBXLo: .byte 0
colBXHi: .byte 0
colARightLo: .byte 0
colARightHi: .byte 0
colBRightLo: .byte 0
colBRightHi: .byte 0
colABottomLo: .byte 0
colABottomHi: .byte 0
colBBottomLo: .byte 0
colBBottomHi: .byte 0
colWidthLo: .byte 0
colWidthHi: .byte 0

// ------------------------------------------------------------
// Live reusable-instance slot helpers.
// ------------------------------------------------------------
FindInactiveTemplateSlot:
    // A = template ID. Returns C=1 and X=matching inactive live slot.
    sta slotTargetTemplate
    ldx #$00
FindInactiveSlotLoop:
    cpx #OBJ_COUNT
    beq FindInactiveSlotNone
    lda objectId,x
    cmp slotTargetTemplate
    bne FindInactiveSlotNext
    lda objectActive,x
    beq FindInactiveSlotFound
FindInactiveSlotNext:
    inx
    jmp FindInactiveSlotLoop
FindInactiveSlotFound:
    sec
    rts
FindInactiveSlotNone:
    clc
    rts

FindFirstTemplateSlot:
    // A = template ID. Returns C=1 and X=first matching live slot.
    sta slotTargetTemplate
    ldx #$00
FindFirstSlotLoop:
    cpx #OBJ_COUNT
    beq FindFirstSlotNone
    lda objectId,x
    cmp slotTargetTemplate
    beq FindFirstSlotFound
    inx
    jmp FindFirstSlotLoop
FindFirstSlotFound:
    sec
    rts
FindFirstSlotNone:
    clc
    rts

LoadCurrentRoomSlots:
    // VER 08.1 persistent Room state:
    // reusable live slots retain X/Y/Active/frame/timer exactly as modified.
    // Only Object 0 is unique and follows currentRoom.
    ldx #$00
LoadRoomPersistentLoop:
    cpx #OBJ_COUNT
    beq LoadRoomSlotsDone
    lda objectId,x
    bne LoadRoomPersistentNext
    lda currentRoom
    sta objectRoom,x
    lda #$01
    sta objectActive,x
LoadRoomPersistentNext:
    inx
    jmp LoadRoomPersistentLoop
LoadRoomSlotsDone:
    rts

slotTargetTemplate: .byte 0
spawnTargetSlot: .byte 0

// ------------------------------------------------------------
// Tile collision. A=0 Any, 1 Solid, 2 Hazard; X=live object slot.
// Returns C=1 when the object's physical rectangle overlaps a matching tile.
// ------------------------------------------------------------
CheckObjectTileProperty:
    stx tileCollisionSource
    lda #$01
    sta tilePropertyMode
    lda tilePropertyWanted
    sta tileCollisionWanted

    lda objectRoom,x
    jsr FindRoomTileMeta
    bcs TilePropertyMetaFound
    ldx tileCollisionSource
    clc
    rts
TilePropertyMetaFound:
    jsr LoadRoomTilePointers
    ldx roomMetaIndex
    lda tilePropertyIndex
    and #$03
    beq TilePropertyUse0
    cmp #$01
    beq TilePropertyUse1
    cmp #$02
    beq TilePropertyUse2
TilePropertyUse3:
    lda roomTileProp3Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp3Hi,x
    sta ROOM_COLL_HI
    jmp TileCollisionHaveData
TilePropertyUse2:
    lda roomTileProp2Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp2Hi,x
    sta ROOM_COLL_HI
    jmp TileCollisionHaveData
TilePropertyUse1:
    lda roomTileProp1Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp1Hi,x
    sta ROOM_COLL_HI
    jmp TileCollisionHaveData
TilePropertyUse0:
    lda roomTileProp0Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp0Hi,x
    sta ROOM_COLL_HI
    jmp TileCollisionHaveData

CheckObjectCenterTileProperty:
    // X=self, tilePropertyIndex/tilePropertyWanted set by caller. Center cell only.
    stx tileCollisionSource
    jsr LoadObjectRoomTileGeometry
    bcs !cctp_have_geometry+
    jmp !cctp_no+
!cctp_have_geometry:
    ldx roomMetaIndex
    lda tilePropertyIndex
    and #$03
    beq !cctp_p0+
    cmp #1
    beq !cctp_p1+
    cmp #2
    beq !cctp_p2+
    lda roomTileProp3Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp3Hi,x
    sta ROOM_COLL_HI
    jmp !cctp_prop_ready+
!cctp_p2:
    lda roomTileProp2Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp2Hi,x
    sta ROOM_COLL_HI
    jmp !cctp_prop_ready+
!cctp_p1:
    lda roomTileProp1Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp1Hi,x
    sta ROOM_COLL_HI
    jmp !cctp_prop_ready+
!cctp_p0:
    lda roomTileProp0Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp0Hi,x
    sta ROOM_COLL_HI
!cctp_prop_ready:
    lda ROOM_COLL_LO
    ora ROOM_COLL_HI
    beq !cctp_no+
    ldx tileCollisionSource
    lda objectWidthBytes,x
    asl
    asl
    clc
    adc objectXLo,x
    tay
    lda objectXHi,x
    beq !cctp_xlow+
    lda ROOM_XCELL_HI
    clc
    adc #1
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda (SS_IMG_LO),y
    jmp !cctp_xready+
!cctp_xlow:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    lda (SS_IMG_LO),y
!cctp_xready:
    sta tileWriteCol
    ldx tileCollisionSource
    lda objectHeight,x
    lsr
    clc
    adc objectY,x
    cmp #200
    bcc !cctp_yok+
    lda #199
!cctp_yok:
    tay
    lda (ROOM_YOFFLO_LO),y
    sta SS_DST_LO
    lda (ROOM_YOFFHI_LO),y
    sta SS_DST_HI
    clc
    lda ROOM_MAP_LO
    adc SS_DST_LO
    sta SS_DST_LO
    lda ROOM_MAP_HI
    adc SS_DST_HI
    sta SS_DST_HI
    clc
    lda SS_DST_LO
    adc tileWriteCol
    sta SS_DST_LO
    bcc !cctp_addr+
    inc SS_DST_HI
!cctp_addr:
    ldy #0
    lda (SS_DST_LO),y
    cmp #$ff
    beq !cctp_no+
    tay
    lda (ROOM_COLL_LO),y
    cmp tilePropertyWanted
    bne !cctp_no+
    ldx tileCollisionSource
    sec
    rts
!cctp_no:
    ldx tileCollisionSource
    clc
    rts

CheckObjectTileCollision:
    sta tileCollisionWanted
    stx tileCollisionSource
    lda #$00
    sta tilePropertyMode

    lda objectRoom,x
    jsr FindRoomTileMeta
    bcs TileCollisionMetaFound
    ldx tileCollisionSource
    clc
    rts

TileCollisionMetaFound:
    jsr LoadRoomTilePointers

    lda ROOM_COLL_LO
    ora ROOM_COLL_HI
    bne TileCollisionHaveData
    ldx tileCollisionSource
    clc
    rts
TileCollisionHaveData:

    ldx tileCollisionSource

    // Objects starting beyond the 320-pixel room width do not collide.
    lda objectXHi,x
    beq TileLeftLowPage
    cmp #$01
    beq TileCollisionXHiOne
    jmp TileCollisionNoHit
TileCollisionXHiOne:
    lda objectXLo,x
    cmp #64
    bcc TileLeftHighPageOkay
    jmp TileCollisionNoHit
TileLeftHighPageOkay:
    lda objectXHi,x
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    ldy objectXLo,x
    lda (SS_IMG_LO),y
    sta tileLeftCell
    jmp TileLeftReady
TileLeftLowPage:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    ldy objectXLo,x
    lda (SS_IMG_LO),y
    sta tileLeftCell
TileLeftReady:

    // Right physical X = left + widthBytes*8 - 1, clamped to 319.
    lda objectWidthBytes,x
    sta tileRightXLo
    lda #$00
    sta tileRightXHi
    asl tileRightXLo
    rol tileRightXHi
    asl tileRightXLo
    rol tileRightXHi
    asl tileRightXLo
    rol tileRightXHi
    sec
    lda tileRightXLo
    sbc #$01
    sta tileRightXLo
    lda tileRightXHi
    sbc #$00
    sta tileRightXHi

    clc
    lda objectXLo,x
    adc tileRightXLo
    sta tileRightXLo
    lda objectXHi,x
    adc tileRightXHi
    sta tileRightXHi

    lda tileRightXHi
    cmp #$01
    bcc TileRightNotClamped
    bne TileRightClamp
    lda tileRightXLo
    cmp #64
    bcc TileRightNotClamped
TileRightClamp:
    lda #63
    sta tileRightXLo
    lda #$01
    sta tileRightXHi
TileRightNotClamped:

    lda tileRightXHi
    beq TileRightLowPage
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    ldy tileRightXLo
    lda (SS_IMG_LO),y
    sta tileRightCell
    jmp TileRightReady
TileRightLowPage:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    ldy tileRightXLo
    lda (SS_IMG_LO),y
    sta tileRightCell
TileRightReady:

    // Top/bottom cell.
    ldx tileCollisionSource
    lda objectY,x
    cmp #200
    bcc TileTopInRange
    clc
    rts
TileTopInRange:
    tay
    lda (ROOM_YCELL_LO),y
    sta tileTopCell

    clc
    lda objectY,x
    adc objectHeight,x
    bcc TileBottomNoOverflow
    lda #199
    jmp TileBottomReady
TileBottomNoOverflow:
    beq TileBottomZero
    sec
    sbc #$01
    cmp #200
    bcc TileBottomReady
    lda #199
    jmp TileBottomReady
TileBottomZero:
    lda #$00
TileBottomReady:
    sta tileBottomY
    tay
    lda (ROOM_YCELL_LO),y
    sta tileBottomCell

    // Initial row offset from top pixel.
    ldx tileCollisionSource
    ldy objectY,x
    lda (ROOM_YOFFLO_LO),y
    sta tileRowOffLo
    lda (ROOM_YOFFHI_LO),y
    sta tileRowOffHi
    lda tileTopCell
    sta tileCurrentRow

TileCollisionRowLoop:
    lda tileCurrentRow
    cmp tileBottomCell
    bcc TileCollisionRowActive
    beq TileCollisionRowActive
    ldx tileCollisionSource
    clc
    rts

TileCollisionRowActive:
    lda tileLeftCell
    sta roomDrawCol

TileCollisionColLoop:
    lda roomDrawCol
    cmp tileRightCell
    bcc TileCollisionCheckCell
    beq TileCollisionCheckCell
    jmp TileCollisionNextRow

TileCollisionCheckCell:
    // Address room map cell = map base + row offset + column.
    clc
    lda ROOM_MAP_LO
    adc tileRowOffLo
    sta SS_DST_LO
    lda ROOM_MAP_HI
    adc tileRowOffHi
    sta SS_DST_HI
    clc
    lda SS_DST_LO
    adc roomDrawCol
    sta SS_DST_LO
    bcc TileCollisionMapAddrReady
    inc SS_DST_HI
TileCollisionMapAddrReady:
    ldy #$00
    lda (SS_DST_LO),y
    cmp #$ff
    beq TileCollisionNextCol

    tay
    lda (ROOM_COLL_LO),y
    sta roomTileIdTemp
    lda tilePropertyMode
    bne TilePropertyCompareValue
    lda roomTileIdTemp
    beq TileCollisionNextCol
    lda tileCollisionWanted
    beq TileCollisionHit
    cmp roomTileIdTemp
    beq TileCollisionHit
    jmp TileCollisionNextCol
TilePropertyCompareValue:
    lda roomTileIdTemp
    cmp tileCollisionWanted
    beq TileCollisionHit

TileCollisionNextCol:
    inc roomDrawCol
    jmp TileCollisionColLoop

TileCollisionNextRow:
    clc
    lda tileRowOffLo
    adc roomCols
    sta tileRowOffLo
    bcc TileCollisionRowOffsetReady
    inc tileRowOffHi
TileCollisionRowOffsetReady:
    inc tileCurrentRow
    jmp TileCollisionRowLoop

TileCollisionNoHit:
    ldx tileCollisionSource
    clc
    rts

TileCollisionHit:
    ldx tileCollisionSource
    sec
    rts

// ------------------------------------------------------------
// VER 09.4 generic grid / maze helpers.
// Direction codes: 0=Up, 1=Right, 2=Down, 3=Left.
// ------------------------------------------------------------
CheckObjectTileAhead:
    // X=self, A=collision wanted (0 Any/1 Solid/2 Hazard), direction in tileAheadDirection.
    sta tileAheadWanted
    stx tileCollisionSource
    lda objectXLo,x
    sta compareOtherTemp
    lda objectXHi,x
    sta pathDiffHi
    lda objectY,x
    sta pathDiffLo
    lda tileAheadDirection
    and #$03
    beq !ta_up+
    cmp #$01
    beq !ta_right+
    cmp #$02
    beq !ta_down+
!ta_left:
    lda objectXLo,x
    bne !ta_left_dec+
    dec objectXHi,x
!ta_left_dec:
    dec objectXLo,x
    jmp !ta_check+
!ta_up:
    dec objectY,x
    jmp !ta_check+
!ta_right:
    inc objectXLo,x
    bne !ta_check+
    inc objectXHi,x
    jmp !ta_check+
!ta_down:
    inc objectY,x
!ta_check:
    lda tileAheadWanted
    jsr CheckObjectTileCollision
    php
    ldx tileCollisionSource
    lda compareOtherTemp
    sta objectXLo,x
    lda pathDiffHi
    sta objectXHi,x
    lda pathDiffLo
    sta objectY,x
    plp
    rts

// VER 09.12: grid-turn probe used by Apply Queued Direction.
// Unlike the generic one-pixel Tile Ahead test, this samples the CENTER of
// the immediately adjacent grid cell. This makes queued turns deterministic
// at intersections and avoids a moving object's current bounding box from
// influencing the turn decision. Returns C=1 when the adjacent cell is Solid
// or outside the room; C=0 when it is open. X=self, A=direction.
CheckQueuedGridDirectionBlocked:
    and #$03
    sta tileAheadDirection
    stx tileCollisionSource
    jsr LoadObjectRoomTileGeometry
    bcs !qgd_have_geometry+
    ldx tileCollisionSource
    clc
    rts
!qgd_have_geometry:
    ldx tileCollisionSource

    // Object center X = object X + half object width in pixels.
    lda objectWidthBytes,x
    asl
    asl
    clc
    adc objectXLo,x
    sta tileProbeXLo
    lda objectXHi,x
    adc #$00
    sta tileProbeXHi

    // Object center Y = object Y + half object height.
    lda objectHeight,x
    lsr
    clc
    adc objectY,x
    sta tileProbeY

    lda tileAheadDirection
    beq !qgd_up+
    cmp #$01
    beq !qgd_right+
    cmp #$02
    beq !qgd_down+

!qgd_left:
    jsr ComputeTilePixelWidth
    lda tileProbeXHi
    bne !qgd_left_sub+
    lda tileProbeXLo
    cmp tileGridSize
    bcs !qgd_left_sub+
    jmp !qgd_blocked+
!qgd_left_sub:
    sec
    lda tileProbeXLo
    sbc tileGridSize
    sta tileProbeXLo
    lda tileProbeXHi
    sbc #$00
    sta tileProbeXHi
    jmp !qgd_lookup+

!qgd_right:
    jsr ComputeTilePixelWidth
    clc
    lda tileProbeXLo
    adc tileGridSize
    sta tileProbeXLo
    lda tileProbeXHi
    adc #$00
    sta tileProbeXHi
    lda tileProbeXHi
    cmp #$01
    bcc !qgd_lookup+
    beq !qgd_right_hi_one+
    jmp !qgd_blocked+
!qgd_right_hi_one:
    lda tileProbeXLo
    cmp #64
    bcc !qgd_lookup+
    jmp !qgd_blocked+

!qgd_up:
    lda tileProbeY
    cmp roomTileHeightRT
    bcs !qgd_up_ok+
    jmp !qgd_blocked+
!qgd_up_ok:
    sec
    sbc roomTileHeightRT
    sta tileProbeY
    jmp !qgd_lookup+

!qgd_down:
    clc
    lda tileProbeY
    adc roomTileHeightRT
    bcc !qgd_down_no_carry+
    jmp !qgd_blocked+
!qgd_down_no_carry:
    cmp #200
    bcc !qgd_down_in_range+
    jmp !qgd_blocked+
!qgd_down_in_range:
    sta tileProbeY

!qgd_lookup:
    // Convert target center X to map column.
    lda tileProbeXHi
    beq !qgd_xlow+
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    ldy tileProbeXLo
    lda (SS_IMG_LO),y
    sta tileProbeCol
    jmp !qgd_ylookup+
!qgd_xlow:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    ldy tileProbeXLo
    lda (SS_IMG_LO),y
    sta tileProbeCol

!qgd_ylookup:
    // Y offset table directly gives row*roomCols for the target pixel.
    ldy tileProbeY
    lda (ROOM_YOFFLO_LO),y
    sta tileProbeRowOffLo
    lda (ROOM_YOFFHI_LO),y
    sta tileProbeRowOffHi

    clc
    lda ROOM_MAP_LO
    adc tileProbeRowOffLo
    sta SS_DST_LO
    lda ROOM_MAP_HI
    adc tileProbeRowOffHi
    sta SS_DST_HI
    clc
    lda SS_DST_LO
    adc tileProbeCol
    sta SS_DST_LO
    bcc !qgd_addr_ready+
    inc SS_DST_HI
!qgd_addr_ready:
    ldy #$00
    lda (SS_DST_LO),y
    cmp #$ff
    beq !qgd_open+
    tay
    lda (ROOM_COLL_LO),y
    cmp #$01
    beq !qgd_blocked+
!qgd_open:
    ldx tileCollisionSource
    clc
    rts
!qgd_blocked:
    ldx tileCollisionSource
    sec
    rts

LoadObjectRoomTileGeometry:
    // X=self. Returns C=1 and room tile pointers loaded.
    stx tileCollisionSource
    lda objectRoom,x
    jsr FindRoomTileMeta
    bcc !lrtg_no+
    jsr LoadRoomTilePointers
    ldx tileCollisionSource
    sec
    rts
!lrtg_no:
    ldx tileCollisionSource
    clc
    rts

ComputeTilePixelWidth:
    lda roomTileWidthBytesRT
    asl
    asl
    asl
    sta tileGridSize
    rts

CheckObjectTileAligned:
    // A: 0 Both, 1 X, 2 Y. X=self.
    sta tileAlignAxis
    jsr LoadObjectRoomTileGeometry
    bcc !align_no+
    lda tileAlignAxis
    cmp #$02
    beq !align_y+
    jsr ComputeTilePixelWidth
    lda objectXLo,x
!align_x_mod:
    cmp tileGridSize
    bcc !align_x_done+
    sec
    sbc tileGridSize
    jmp !align_x_mod-
!align_x_done:
    bne !align_no+
    lda tileAlignAxis
    cmp #$01
    beq !align_yes+
!align_y:
    lda roomTileHeightRT
    sta tileGridSize
    lda objectY,x
!align_y_mod:
    cmp tileGridSize
    bcc !align_y_done+
    sec
    sbc tileGridSize
    jmp !align_y_mod-
!align_y_done:
    bne !align_no+
!align_yes:
    sec
    rts
!align_no:
    clc
    rts

SnapObjectToTile:
    // A: 0 Both, 1 X, 2 Y. X=self. Nearest grid origin.
    sta tileAlignAxis
    jsr LoadObjectRoomTileGeometry
    bcc !snap_done+
    lda tileAlignAxis
    cmp #$02
    beq !snap_y+
    jsr ComputeTilePixelWidth
    lda objectXLo,x
    sta tileGridRemainder
!snap_x_mod:
    lda tileGridRemainder
    cmp tileGridSize
    bcc !snap_x_have+
    sec
    sbc tileGridSize
    sta tileGridRemainder
    jmp !snap_x_mod-
!snap_x_have:
    lda objectXLo,x
    sec
    sbc tileGridRemainder
    sta objectXLo,x
    lda tileAlignAxis
    cmp #$01
    beq !snap_done+
!snap_y:
    lda roomTileHeightRT
    sta tileGridSize
    lda objectY,x
    sta tileGridRemainder
!snap_y_mod:
    lda tileGridRemainder
    cmp tileGridSize
    bcc !snap_y_have+
    sec
    sbc tileGridSize
    sta tileGridRemainder
    jmp !snap_y_mod-
!snap_y_have:
    lda objectY,x
    sec
    sbc tileGridRemainder
    sta objectY,x
!snap_done:
    rts

MoveObjectInDirection:
    // X=self, A=direction, Y=speed.
    and #$03
    sta directionCandidate
!move_dir_step:
    cpy #$00
    beq !move_dir_done+
    lda directionCandidate
    beq !mdi_up+
    cmp #$01
    beq !mdi_right+
    cmp #$02
    beq !mdi_down+
!mdi_left:
    lda objectXLo,x
    bne !mdi_left_dec+
    dec objectXHi,x
!mdi_left_dec:
    dec objectXLo,x
    jmp !mdi_next+
!mdi_up:
    dec objectY,x
    jmp !mdi_next+
!mdi_right:
    inc objectXLo,x
    bne !mdi_next+
    inc objectXHi,x
    jmp !mdi_next+
!mdi_down:
    inc objectY,x
!mdi_next:
    dey
    jmp !move_dir_step-
!move_dir_done:
    rts

ReadDirectionProperty:
    lda directionPropertyIndex
    beq !rdp0+
    cmp #1
    beq !rdp1+
    cmp #2
    beq !rdp2+
    cmp #3
    beq !rdp3+
    cmp #4
    beq !rdp4+
    cmp #5
    beq !rdp5+
    cmp #6
    beq !rdp6+
    lda objectP7,x
    rts
!rdp0: lda objectP0,x
    rts
!rdp1: lda objectP1,x
    rts
!rdp2: lda objectP2,x
    rts
!rdp3: lda objectP3,x
    rts
!rdp4: lda objectP4,x
    rts
!rdp5: lda objectP5,x
    rts
!rdp6: lda objectP6,x
    rts

WriteDirectionProperty:
    sta directionCandidate
    lda directionPropertyIndex
    beq !wdp0+
    cmp #1
    beq !wdp1+
    cmp #2
    beq !wdp2+
    cmp #3
    beq !wdp3+
    cmp #4
    beq !wdp4+
    cmp #5
    beq !wdp5+
    cmp #6
    beq !wdp6+
    lda directionCandidate
    sta objectP7,x
    rts
!wdp0: lda directionCandidate
    sta objectP0,x
    rts
!wdp1: lda directionCandidate
    sta objectP1,x
    rts
!wdp2: lda directionCandidate
    sta objectP2,x
    rts
!wdp3: lda directionCandidate
    sta objectP3,x
    rts
!wdp4: lda directionCandidate
    sta objectP4,x
    rts
!wdp5: lda directionCandidate
    sta objectP5,x
    rts
!wdp6: lda directionCandidate
    sta objectP6,x
    rts

ChooseObjectAvailableDirection:
    // X=self. directionPropertyIndex selects P0-P7.
    stx tileCollisionSource
    jsr ReadDirectionProperty
    and #$03
    sta directionOriginal
    lda #$00
    sta directionMask
    lda #$00
    sta tileAheadDirection
!cad_scan:
    ldx tileCollisionSource
    lda #$01
    jsr CheckObjectTileAhead
    bcs !cad_blocked+
    lda #$01
    ldy tileAheadDirection
!cad_shift:
    cpy #$00
    beq !cad_add+
    asl
    dey
    jmp !cad_shift-
!cad_add:
    ora directionMask
    sta directionMask
!cad_blocked:
    inc tileAheadDirection
    lda tileAheadDirection
    cmp #$04
    bcc !cad_scan-
    lda directionMask
    beq !cad_done+
    lda directionAvoidReverse
    beq !cad_pick+
    // If more than one direction exists, remove reverse of current direction.
    lda directionMask
    sta pathDiffLo
    sec
    sbc #$01
    and pathDiffLo
    beq !cad_pick+
    lda directionOriginal
    clc
    adc #$02
    and #$03
    tay
    lda #$01
!cad_rev_shift:
    cpy #$00
    beq !cad_have_rev+
    asl
    dey
    jmp !cad_rev_shift-
!cad_have_rev:
    eor #$ff
    and directionMask
    sta directionMask
!cad_pick:
    // Pick one random starting direction, then scan all four at most once.
    // The old code generated another random value after every miss and could
    // become trapped forever on a blocked direction at some RNG states.
    lda #$03
    jsr RandomInclusive
    and #$03
    sta directionCandidate
    lda #$04
    sta directionTryCount
!cad_try:
    lda #$01
    ldy directionCandidate
!cad_pick_shift:
    cpy #$00
    beq !cad_test+
    asl
    dey
    jmp !cad_pick_shift-
!cad_test:
    and directionMask
    bne !cad_store+
    inc directionCandidate
    lda directionCandidate
    and #$03
    sta directionCandidate
    dec directionTryCount
    bne !cad_try-
    jmp !cad_done+
!cad_store:
    ldx tileCollisionSource
    lda directionCandidate
    jsr WriteDirectionProperty
!cad_done:
    ldx tileCollisionSource
    rts

SetTileUnderObject:
    // X=self, A=new room tile ID. Mutates the room map cell under object center.
    sta tileWriteId
    stx tileCollisionSource
    jsr LoadObjectRoomTileGeometry
    bcc !stu_done+
    // center X into pixel->cell table
    ldx tileCollisionSource
    lda objectWidthBytes,x
    asl
    asl
    clc
    adc objectXLo,x
    tay
    lda objectXHi,x
    beq !stu_x_low+
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda (SS_IMG_LO),y
    jmp !stu_x_ready+
!stu_x_low:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    lda (SS_IMG_LO),y
!stu_x_ready:
    sta tileWriteCol
    // center Y into cell and row-offset tables
    ldx tileCollisionSource
    lda objectHeight,x
    lsr
    clc
    adc objectY,x
    cmp #200
    bcc !stu_y_ok+
    lda #199
!stu_y_ok:
    tay
    lda (ROOM_YCELL_LO),y
    sta tileWriteRow
    lda (ROOM_YOFFLO_LO),y
    sta SS_DST_LO
    lda (ROOM_YOFFHI_LO),y
    sta SS_DST_HI
    clc
    lda ROOM_MAP_LO
    adc SS_DST_LO
    sta SS_DST_LO
    lda ROOM_MAP_HI
    adc SS_DST_HI
    sta SS_DST_HI
    clc
    lda SS_DST_LO
    adc tileWriteCol
    sta SS_DST_LO
    bcc !stu_addr+
    inc SS_DST_HI
!stu_addr:
    ldy #0
    lda tileWriteId
    sta (SS_DST_LO),y
    // Redraw only the changed tile into both bitmap buffers.
    jsr DrawChangedRoomTile
!stu_done:
    ldx tileCollisionSource
    rts

DrawChangedRoomTile:
    // Convert tile column to bitmap-cell byte index.
    lda #0
    sta tileWriteXByte
    ldy tileWriteCol
!dct_x_loop:
    cpy #0
    beq !dct_x_done+
    clc
    lda tileWriteXByte
    adc roomTileWidthBytesRT
    sta tileWriteXByte
    dey
    jmp !dct_x_loop-
!dct_x_done:
    lda tileWriteXByte
    sta ss_xoff_lo
    lda #0
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    // Convert tile row to pixel Y.
    lda #0
    sta tileWriteY
    ldy tileWriteRow
!dct_y_loop:
    cpy #0
    beq !dct_y_done+
    clc
    lda tileWriteY
    adc roomTileHeightRT
    sta tileWriteY
    dey
    jmp !dct_y_loop-
!dct_y_done:
    // Resolve source tile pointer; $ff/no graphics draws blank.
    lda #0
    sta SS_IMG_LO
    sta SS_IMG_HI
    lda tileWriteId
    cmp #$ff
    beq !dct_source_ready+
    lda ROOM_PTRLO_LO
    ora ROOM_PTRLO_HI
    beq !dct_source_ready+
    ldy tileWriteId
    lda (ROOM_PTRLO_LO),y
    sta SS_IMG_LO
    lda (ROOM_PTRHI_LO),y
    sta SS_IMG_HI
!dct_source_ready:
    lda #0
    sta roomTileRow
!dct_row_loop:
    lda roomTileRow
    cmp roomTileHeightRT
    bcs !dct_done+
    clc
    adc tileWriteY
    tax
    cpx #200
    bcs !dct_done+
    lda bitmapRowLo,x
    clc
    adc ss_xoff_lo
    sta SS_DST_LO
    lda bitmapRowHi,x
    adc ss_xoff_hi
    sta SS_DST_HI
    lda #0
    sta roomTileByte
!dct_byte_loop:
    lda roomTileByte
    cmp roomTileWidthBytesRT
    bcs !dct_row_done+
    tax
    lda SS_IMG_LO
    ora SS_IMG_HI
    beq !dct_blank+
    ldy roomTileByte
    lda (SS_IMG_LO),y
    jmp !dct_have_byte+
!dct_blank:
    lda #0
!dct_have_byte:
    sta roomTileIdTemp
    ldx roomTileByte
    ldy offset8,x
    lda roomTileIdTemp
    sta (SS_DST_LO),y
    lda SS_DST_HI
    clc
    adc #$40
    sta SS_MASK_HI
    lda SS_DST_LO
    sta SS_MASK_LO
    lda roomTileIdTemp
    sta (SS_MASK_LO),y
    inc roomTileByte
    jmp !dct_byte_loop-
!dct_row_done:
    lda SS_IMG_LO
    ora SS_IMG_HI
    beq !dct_no_src_advance+
    clc
    lda SS_IMG_LO
    adc roomTileWidthBytesRT
    sta SS_IMG_LO
    bcc !dct_no_src_advance+
    inc SS_IMG_HI
!dct_no_src_advance:
    inc roomTileRow
    jmp !dct_row_loop-
!dct_done:
    rts

BringIndexToFront:
    stx zTargetIndex
    lda #$00
    sta zExtreme
    ldy #$00
!zfscan:
    cpy #OBJ_COUNT
    beq !zforder+
    lda objectActive,y
    beq !zfnext+
    lda objectZ,y
    cmp zExtreme
    bcc !zfnext+
    sta zExtreme
!zfnext:
    iny
    jmp !zfscan-
!zforder:
    // Remove target from draw order and append it at the end.
    ldy #$00
    ldx #$00
!zffind:
    cpy #OBJ_COUNT
    beq !zfsetz+
    lda objectDrawOrder,y
    cmp zTargetIndex
    beq !zfshift+
    iny
    jmp !zffind-
!zfshift:
    sty zOrderPos
!zfshiftloop:
    tya
    clc
    adc #1
    tax
    cpx #OBJ_COUNT
    beq !zfappend+
    lda objectDrawOrder,x
    sta objectDrawOrder,y
    iny
    jmp !zfshiftloop-
!zfappend:
    ldy #OBJ_COUNT-1
    lda zTargetIndex
    sta objectDrawOrder,y
!zfsetz:
    ldx zTargetIndex
    lda zExtreme
    clc
    adc #1
    sta objectZ,x
    rts

SendIndexToBack:
    stx zTargetIndex
    lda #$ff
    sta zExtreme
    ldy #$00
!zbscan:
    cpy #OBJ_COUNT
    beq !zborder+
    lda objectActive,y
    beq !zbnext+
    lda objectZ,y
    cmp zExtreme
    bcs !zbnext+
    sta zExtreme
!zbnext:
    iny
    jmp !zbscan-
!zborder:
    // Remove target and insert it at the beginning of draw order.
    ldy #$00
!zbfind:
    cpy #OBJ_COUNT
    beq !zbsetz+
    lda objectDrawOrder,y
    cmp zTargetIndex
    beq !zbshift+
    iny
    jmp !zbfind-
!zbshift:
    sty zOrderPos
!zbshiftloop:
    cpy #$00
    beq !zbinsert+
    tya
    tax
    dey
    lda objectDrawOrder,y
    sta objectDrawOrder,x
    jmp !zbshiftloop-
!zbinsert:
    lda zTargetIndex
    sta objectDrawOrder
!zbsetz:
    ldx zTargetIndex
    lda zExtreme
    sec
    sbc #1
    sta objectZ,x
    rts

NextRandomByte:
    lda randomSeed
    asl
    bcc !rno+
    eor #$1d
!rno:
    clc
    adc frameCounter
    sta randomSeed
    rts

// A = inclusive maximum (0..255). Returns A in 0..maximum.
RandomInclusive:
    sta randomMax
    cmp #$ff
    beq !rfull+
    clc
    adc #1
    sta randomRange
    jsr NextRandomByte
!rmod:
    cmp randomRange
    bcc !rdone+
    sec
    sbc randomRange
    jmp !rmod-
!rdone:
    rts
!rfull:
    jsr NextRandomByte
    rts

randomSeed: .byte $a7
randomMax: .byte $ff
randomRange: .byte 1
zTargetIndex: .byte 0
zExtreme: .byte 0
zOrderPos: .byte 0

CheckCollisionWithTemplate:
    sta collisionTargetTemplate
    stx collisionSourceIndex
    ldy #$00
CollisionTemplateLoop:
    cpy #OBJ_COUNT
    beq CollisionTemplateNo
    tya
    cmp collisionSourceIndex
    beq CollisionTemplateNext
    lda objectActive,y
    beq CollisionTemplateNext
    lda objectId,y
    cmp collisionTargetTemplate
    bne CollisionTemplateNext
    sty collisionCandidateIndex
    ldx collisionSourceIndex
    jsr CheckAABBCollision
    bcs CollisionTemplateFound
    ldy collisionCandidateIndex
CollisionTemplateNext:
    iny
    jmp CollisionTemplateLoop
CollisionTemplateFound:
    ldy collisionCandidateIndex
    sty collisionOtherIndex
    ldx collisionSourceIndex
    sec
    rts
CollisionTemplateNo:
    ldx collisionSourceIndex
    clc
    rts

collisionTargetTemplate: .byte 0

// Find the highest stack-order overlapping object in the same room.
// Generic selection helper for card games, inventory stacks, menus, etc.
// X = source slot. Returns C=1 and collisionOtherIndex = highest objectZ overlap.
CheckCollisionTopmost:
    stx collisionSourceIndex
    lda #$ff
    sta collisionBestIndex
    lda #$00
    sta collisionBestZ
    ldy #$00
CollisionTopmostLoop:
    cpy #OBJ_COUNT
    beq CollisionTopmostDoneScan
    tya
    cmp collisionSourceIndex
    beq CollisionTopmostNext
    lda objectActive,y
    beq CollisionTopmostNext
    sty collisionCandidateIndex
    ldx collisionSourceIndex
    jsr CheckAABBCollision
    bcc CollisionTopmostRestoreY
    ldy collisionCandidateIndex
    lda collisionBestIndex
    cmp #$ff
    beq CollisionTopmostTake
    lda objectZ,y
    cmp collisionBestZ
    bcc CollisionTopmostRestoreY
CollisionTopmostTake:
    tya
    sta collisionBestIndex
    lda objectZ,y
    sta collisionBestZ
CollisionTopmostRestoreY:
    ldy collisionCandidateIndex
CollisionTopmostNext:
    iny
    jmp CollisionTopmostLoop
CollisionTopmostDoneScan:
    lda collisionBestIndex
    cmp #$ff
    beq CollisionTopmostNo
    sta collisionOtherIndex
    ldx collisionSourceIndex
    sec
    rts
CollisionTopmostNo:
    lda #$ff
    sta collisionOtherIndex
    ldx collisionSourceIndex
    clc
    rts

collisionBestIndex: .byte $ff
collisionBestZ: .byte 0

CheckCollisionWithObject:
    sta collisionCandidateIndex
    stx collisionSourceIndex
    cmp collisionSourceIndex
    bne CollisionObjectDifferent
    jmp CollisionNo
CollisionObjectDifferent:
    ldy collisionCandidateIndex
    jsr CheckAABBCollision
    rts

CheckCollisionWithSprite:
    sta collisionTargetSprite
    stx collisionSourceIndex
    ldy #$00
CollisionSpriteLoop:
    cpy #OBJ_COUNT
    bne CollisionSpriteHaveCandidate
    jmp CollisionNo
CollisionSpriteHaveCandidate:
    tya
    cmp collisionSourceIndex
    beq CollisionSpriteNext
    lda objectActive,y
    beq CollisionSpriteNext
    lda objectSpriteId,y
    cmp collisionTargetSprite
    bne CollisionSpriteNext
    sty collisionCandidateIndex
    ldx collisionSourceIndex
    jsr CheckAABBCollision
    bcs CollisionSpriteFound
    ldy collisionCandidateIndex
CollisionSpriteNext:
    iny
    jmp CollisionSpriteLoop
CollisionSpriteFound:
    ldy collisionCandidateIndex
    sty collisionOtherIndex
    ldx collisionSourceIndex
    sec
    rts

CheckAABBCollision:
    stx collisionSourceIndex
    sty collisionCandidateIndex

    lda objectActive,x
    bne CollisionAActive
    jmp CollisionNoRestore
CollisionAActive:
    lda objectActive,y
    bne CollisionBActive
    jmp CollisionNoRestore
CollisionBActive:

    lda objectRoom,x
    cmp objectRoom,y
    beq CollisionSameRoom
    jmp CollisionNoRestore
CollisionSameRoom:

    // A left X
    lda objectXLo,x
    sta colAXLo
    lda objectXHi,x
    and #$01
    sta colAXHi

    // A width = widthBytes * 8, 16-bit
    lda objectWidthBytes,x
    sta colWidthLo
    lda #$00
    sta colWidthHi
    asl colWidthLo
    rol colWidthHi
    asl colWidthLo
    rol colWidthHi
    asl colWidthLo
    rol colWidthHi
    clc
    lda colAXLo
    adc colWidthLo
    sta colARightLo
    lda colAXHi
    adc colWidthHi
    sta colARightHi

    // A bottom
    lda objectY,x
    clc
    adc objectHeight,x
    sta colABottomLo
    lda #$00
    adc #$00
    sta colABottomHi

    // Load B
    ldx collisionCandidateIndex
    lda objectXLo,x
    sta colBXLo
    lda objectXHi,x
    and #$01
    sta colBXHi

    lda objectWidthBytes,x
    sta colWidthLo
    lda #$00
    sta colWidthHi
    asl colWidthLo
    rol colWidthHi
    asl colWidthLo
    rol colWidthHi
    asl colWidthLo
    rol colWidthHi
    clc
    lda colBXLo
    adc colWidthLo
    sta colBRightLo
    lda colBXHi
    adc colWidthHi
    sta colBRightHi

    lda objectY,x
    clc
    adc objectHeight,x
    sta colBBottomLo
    lda #$00
    adc #$00
    sta colBBottomHi

    // A.left < B.right
    lda colAXHi
    cmp colBRightHi
    bcc CollisionX1Pass
    beq CollisionX1CompareLow
    jmp CollisionNoRestore
CollisionX1CompareLow:
    lda colAXLo
    cmp colBRightLo
    bcc CollisionX1Pass
    jmp CollisionNoRestore
CollisionX1Pass:

    // B.left < A.right
    lda colBXHi
    cmp colARightHi
    bcc CollisionX2Pass
    beq CollisionX2CompareLow
    jmp CollisionNoRestore
CollisionX2CompareLow:
    lda colBXLo
    cmp colARightLo
    bcc CollisionX2Pass
    jmp CollisionNoRestore
CollisionX2Pass:

    // A.top < B.bottom
    ldx collisionSourceIndex
    lda objectY,x
    cmp colBBottomLo
    bcc CollisionY1Pass
    lda colBBottomHi
    bne CollisionY1Pass
    jmp CollisionNoRestore
CollisionY1Pass:

    // B.top < A.bottom
    ldx collisionCandidateIndex
    lda objectY,x
    cmp colABottomLo
    bcc CollisionHit
    lda colABottomHi
    bne CollisionHit
    jmp CollisionNoRestore

CollisionHit:
    lda collisionCandidateIndex
    sta collisionOtherIndex
    ldx collisionSourceIndex
    sec
    rts

CollisionNoRestore:
    ldx collisionSourceIndex
CollisionNo:
    clc
    rts

mcMaskExpand:
    .byte $00,$03,$0c,$0f,$30,$33,$3c,$3f,$c0,$c3,$cc,$cf,$f0,$f3,$fc,$ff

offset8:
    .byte $00,$08,$10,$18,$20,$28,$30,$38,$40,$48,$50,$58,$60,$68,$70,$78
    .byte $80,$88,$90,$98,$a0,$a8,$b0,$b8

bitmapRowLo:
    .byte $00,$01,$02,$03,$04,$05,$06,$07,$40,$41,$42,$43,$44,$45,$46,$47
    .byte $80,$81,$82,$83,$84,$85,$86,$87,$c0,$c1,$c2,$c3,$c4,$c5,$c6,$c7
    .byte $00,$01,$02,$03,$04,$05,$06,$07,$40,$41,$42,$43,$44,$45,$46,$47
    .byte $80,$81,$82,$83,$84,$85,$86,$87,$c0,$c1,$c2,$c3,$c4,$c5,$c6,$c7
    .byte $00,$01,$02,$03,$04,$05,$06,$07,$40,$41,$42,$43,$44,$45,$46,$47
    .byte $80,$81,$82,$83,$84,$85,$86,$87,$c0,$c1,$c2,$c3,$c4,$c5,$c6,$c7
    .byte $00,$01,$02,$03,$04,$05,$06,$07,$40,$41,$42,$43,$44,$45,$46,$47
    .byte $80,$81,$82,$83,$84,$85,$86,$87,$c0,$c1,$c2,$c3,$c4,$c5,$c6,$c7
    .byte $00,$01,$02,$03,$04,$05,$06,$07,$40,$41,$42,$43,$44,$45,$46,$47
    .byte $80,$81,$82,$83,$84,$85,$86,$87,$c0,$c1,$c2,$c3,$c4,$c5,$c6,$c7
    .byte $00,$01,$02,$03,$04,$05,$06,$07,$40,$41,$42,$43,$44,$45,$46,$47
    .byte $80,$81,$82,$83,$84,$85,$86,$87,$c0,$c1,$c2,$c3,$c4,$c5,$c6,$c7
    .byte $00,$01,$02,$03,$04,$05,$06,$07

bitmapRowHi:
    .byte $20,$20,$20,$20,$20,$20,$20,$20,$21,$21,$21,$21,$21,$21,$21,$21
    .byte $22,$22,$22,$22,$22,$22,$22,$22,$23,$23,$23,$23,$23,$23,$23,$23
    .byte $25,$25,$25,$25,$25,$25,$25,$25,$26,$26,$26,$26,$26,$26,$26,$26
    .byte $27,$27,$27,$27,$27,$27,$27,$27,$28,$28,$28,$28,$28,$28,$28,$28
    .byte $2a,$2a,$2a,$2a,$2a,$2a,$2a,$2a,$2b,$2b,$2b,$2b,$2b,$2b,$2b,$2b
    .byte $2c,$2c,$2c,$2c,$2c,$2c,$2c,$2c,$2d,$2d,$2d,$2d,$2d,$2d,$2d,$2d
    .byte $2f,$2f,$2f,$2f,$2f,$2f,$2f,$2f,$30,$30,$30,$30,$30,$30,$30,$30
    .byte $31,$31,$31,$31,$31,$31,$31,$31,$32,$32,$32,$32,$32,$32,$32,$32
    .byte $34,$34,$34,$34,$34,$34,$34,$34,$35,$35,$35,$35,$35,$35,$35,$35
    .byte $36,$36,$36,$36,$36,$36,$36,$36,$37,$37,$37,$37,$37,$37,$37,$37
    .byte $39,$39,$39,$39,$39,$39,$39,$39,$3a,$3a,$3a,$3a,$3a,$3a,$3a,$3a
    .byte $3b,$3b,$3b,$3b,$3b,$3b,$3b,$3b,$3c,$3c,$3c,$3c,$3c,$3c,$3c,$3c
    .byte $3e,$3e,$3e,$3e,$3e,$3e,$3e,$3e

screenRowLo:
    .byte $00,$28,$50,$78,$a0,$c8,$f0,$18,$40,$68,$90,$b8,$e0,$08,$30,$58
    .byte $80,$a8,$d0,$f8,$20,$48,$70,$98,$c0

screenRowHiA:
    .byte $04,$04,$04,$04,$04,$04,$04,$05,$05,$05,$05,$05,$05,$06,$06,$06
    .byte $06,$06,$06,$06,$07,$07,$07,$07,$07

screenRowHiB:
    .byte $44,$44,$44,$44,$44,$44,$44,$45,$45,$45,$45,$45,$45,$46,$46,$46
    .byte $46,$46,$46,$46,$47,$47,$47,$47,$47
