// Generated named object paths
pathStart: .byte 0,3,6
pathCount: .byte 3,3,3
pathSpeed: .byte 2,2,2
pathMode: .byte 2,2,2
pathPointXLo: .byte 64,64,40,144,144,144,224,224,248
pathPointXHi: .byte 0,0,0,0,0,0,0,0,0
pathPointY: .byte 0,42,64,0,42,64,0,42,64
