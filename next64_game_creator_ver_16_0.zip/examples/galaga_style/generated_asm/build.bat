@echo off
cd /d "%~dp0"
if not exist KickAss.jar (
  echo Copy KickAss.jar into this folder, then run build.bat.
  pause
  exit /b 1
)
java -jar KickAss.jar game.asm -o game.prg
pause
