Next64 VER 09.3 - Galaga-Style Visual Logic Demo

This is an editable example, not a hard-coded Galaga engine. It uses only general Next64 objects, paths, variables, collisions, and Visual Logic.

Controls: A/D move. SPACE fires.

What it demonstrates:
- Named one-shot entry paths assigned to enemy objects.
- Path Finished visual event.
- Move Toward Object action for generic pursuit/dive behavior.
- Restart Path action after a player collision.
- Create Object At Object for player shots.
- Collision logic and score variable.

New general-purpose path logic tools in VER 09.1:
- Start Path
- Stop Path
- Restart Path
- Set Path
- Path Finished event
- Move Toward Object (target object ID + speed)

Nothing in these commands is Galaga-specific. They can be used for guards, racers, NPC routes, bosses, moving platforms, homing objects, and other game types.
