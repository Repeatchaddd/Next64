// Generated room metadata
// Room 0: Maze Room / level Maze / EXPLICIT player Object 0 at 16,88
// AUTO EDGE ENTRY rule for rooms without an explicit start:
// DOWN -> y=top, keep prior x; UP -> y=bottom, keep prior x;
// RIGHT -> x=left, keep prior y; LEFT -> x=right, keep prior y.
roomId: .byte 0
roomPlayerStartMode: .byte 1
roomPlayerObject: .byte 0
roomPlayerSprite: .byte 0
roomPlayerStartXLo: .byte 16
roomPlayerStartXHi: .byte 0
roomPlayerStartY: .byte 88
