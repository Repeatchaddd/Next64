// Generated visual event/action code
compareOtherTemp: .byte 0
events_slot_000: // template 0, instance 255
    ldx #0
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda keyMatrixCurrent+1
    and #$02
    bne !skip_0_0+
    ldx #0
    lda #0
    sta objectP1,x
!skip_0_0:
    lda keyMatrixCurrent+2
    and #$04
    bne !skip_0_1+
    ldx #0
    lda #1
    sta objectP1,x
!skip_0_1:
    lda keyMatrixCurrent+5
    and #$02
    bne !skip_0_2+
    ldx #0
    lda #2
    sta objectP1,x
!skip_0_2:
    lda keyMatrixCurrent+2
    and #$02
    bne !skip_0_3+
    ldx #0
    lda #3
    sta objectP1,x
!skip_0_3:
    ldx #0
    lda #0
    jsr CheckObjectTileAligned
    bcc !skip_0_4+
    ldx #0
    lda objectP1,x
    and #$03
    jsr CheckQueuedGridDirectionBlocked
    bcs !queued_blocked_0_4_0+
    ldx #0
    lda objectP1,x
    sta objectP0,x
!queued_blocked_0_4_0:
!skip_0_4:
    ldx #0
    lda objectP0,x
    ldy #2
    jsr MoveObjectInDirection
!skip_0_5:
    ldx #0
    lda #1
    jsr CheckObjectTileCollision
    bcc !skip_0_6+
    ldx #0
    lda objectLastXLo,x
    sta objectXLo,x
    lda objectLastXHi,x
    sta objectXHi,x
    lda objectLastY,x
    sta objectY,x
!skip_0_6:
    lda #0
    sta tilePropertyIndex
    lda #1
    sta tilePropertyWanted
    ldx #0
    jsr CheckObjectCenterTileProperty
    bcc !skip_0_7+
    ldx #0
    lda #0
    jsr SetTileUnderObject
    lda var_score
    clc
    adc #1
    sta var_score
!skip_0_7:
    rts

events_slot_001: // template 1, instance 1
    ldx #1
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    ldx #1
    lda #0
    jsr CheckObjectTileAligned
    bcc !skip_1_0+
    ldx #1
    lda #0
    sta directionPropertyIndex
    lda #1
    sta directionAvoidReverse
    jsr ChooseObjectAvailableDirection
!skip_1_0:
    ldx #1
    lda objectP0,x
    ldy #1
    jsr MoveObjectInDirection
!skip_1_1:
    ldx #1
    lda #1
    jsr CheckObjectTileCollision
    bcc !skip_1_2+
    ldx #1
    lda objectLastXLo,x
    sta objectXLo,x
    lda objectLastXHi,x
    sta objectXHi,x
    lda objectLastY,x
    sta objectY,x
    ldx #1
    lda #0
    sta directionPropertyIndex
    lda #0
    sta directionAvoidReverse
    jsr ChooseObjectAvailableDirection
!skip_1_2:
    ldx #1
    lda #0
    jsr CheckCollisionWithTemplate
    bcc !skip_1_3+
    ldx #0
    lda #16
    sta objectXLo,x
    lda #0
    sta objectXHi,x
    ldx #0
    lda #88
    sta objectY,x
!skip_1_3:
    rts

events_slot_002: // template 1, instance 2
    ldx #2
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    ldx #2
    lda #0
    jsr CheckObjectTileAligned
    bcc !skip_2_0+
    ldx #2
    lda #0
    sta directionPropertyIndex
    lda #1
    sta directionAvoidReverse
    jsr ChooseObjectAvailableDirection
!skip_2_0:
    ldx #2
    lda objectP0,x
    ldy #1
    jsr MoveObjectInDirection
!skip_2_1:
    ldx #2
    lda #1
    jsr CheckObjectTileCollision
    bcc !skip_2_2+
    ldx #2
    lda objectLastXLo,x
    sta objectXLo,x
    lda objectLastXHi,x
    sta objectXHi,x
    lda objectLastY,x
    sta objectY,x
    ldx #2
    lda #0
    sta directionPropertyIndex
    lda #0
    sta directionAvoidReverse
    jsr ChooseObjectAvailableDirection
!skip_2_2:
    ldx #2
    lda #0
    jsr CheckCollisionWithTemplate
    bcc !skip_2_3+
    ldx #0
    lda #16
    sta objectXLo,x
    lda #0
    sta objectXHi,x
    ldx #0
    lda #88
    sta objectY,x
!skip_2_3:
    rts
