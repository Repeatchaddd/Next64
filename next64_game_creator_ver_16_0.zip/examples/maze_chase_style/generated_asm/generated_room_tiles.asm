// Next64 room tile resources, renderer metadata, and collision data
// Level Maze: Maze Tiles
.const TILESET_Maze_COUNT = 3
.const TILESET_Maze_WIDTH = 8
.const TILESET_Maze_HEIGHT = 8
.const TILESET_Maze_WIDTH_BYTES = 1
.const TILESET_Maze_MODE = 0
tiles_Maze_data: .import binary "tiles_Maze.bin"
tileCollision_Maze: .import binary "tile_collision_Maze.bin"
tileProp0_Maze: .import binary "tile_prop0_Maze.bin"
tileProp1_Maze: .import binary "tile_prop1_Maze.bin"
tileProp2_Maze: .import binary "tile_prop2_Maze.bin"
tileProp3_Maze: .import binary "tile_prop3_Maze.bin"
tilePtrLo_Maze: .byte <(tiles_Maze_data+0),<(tiles_Maze_data+8),<(tiles_Maze_data+16)
tilePtrHi_Maze: .byte >(tiles_Maze_data+0),>(tiles_Maze_data+8),>(tiles_Maze_data+16)
tileXCell_Maze: .byte 0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,6,6,6,6,6,6,6,6,7,7,7,7,7,7,7,7,8,8,8,8,8,8,8,8,9,9,9,9,9,9,9,9,10,10,10,10,10,10,10,10,11,11,11,11,11,11,11,11,12,12,12,12,12,12,12,12,13,13,13,13,13,13,13,13,14,14,14,14,14,14,14,14,15,15,15,15,15,15,15,15,16,16,16,16,16,16,16,16,17,17,17,17,17,17,17,17,18,18,18,18,18,18,18,18,19,19,19,19,19,19,19,19,20,20,20,20,20,20,20,20,21,21,21,21,21,21,21,21,22,22,22,22,22,22,22,22,23,23,23,23,23,23,23,23,24,24,24,24,24,24,24,24,25,25,25,25,25,25,25,25,26,26,26,26,26,26,26,26,27,27,27,27,27,27,27,27,28,28,28,28,28,28,28,28,29,29,29,29,29,29,29,29,30,30,30,30,30,30,30,30,31,31,31,31,31,31,31,31,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,34,34,34,34,34,34,34,34,35,35,35,35,35,35,35,35,36,36,36,36,36,36,36,36,37,37,37,37,37,37,37,37,38,38,38,38,38,38,38,38,39,39,39,39,39,39,39,39
tileYCell_Maze: .byte 0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,6,6,6,6,6,6,6,6,7,7,7,7,7,7,7,7,8,8,8,8,8,8,8,8,9,9,9,9,9,9,9,9,10,10,10,10,10,10,10,10,11,11,11,11,11,11,11,11,12,12,12,12,12,12,12,12,13,13,13,13,13,13,13,13,14,14,14,14,14,14,14,14,15,15,15,15,15,15,15,15,16,16,16,16,16,16,16,16,17,17,17,17,17,17,17,17,18,18,18,18,18,18,18,18,19,19,19,19,19,19,19,19,20,20,20,20,20,20,20,20,21,21,21,21,21,21,21,21,22,22,22,22,22,22,22,22,23,23,23,23,23,23,23,23,24,24,24,24,24,24,24,24
tileYOffLo_Maze: .byte 0,0,0,0,0,0,0,0,40,40,40,40,40,40,40,40,80,80,80,80,80,80,80,80,120,120,120,120,120,120,120,120,160,160,160,160,160,160,160,160,200,200,200,200,200,200,200,200,240,240,240,240,240,240,240,240,24,24,24,24,24,24,24,24,64,64,64,64,64,64,64,64,104,104,104,104,104,104,104,104,144,144,144,144,144,144,144,144,184,184,184,184,184,184,184,184,224,224,224,224,224,224,224,224,8,8,8,8,8,8,8,8,48,48,48,48,48,48,48,48,88,88,88,88,88,88,88,88,128,128,128,128,128,128,128,128,168,168,168,168,168,168,168,168,208,208,208,208,208,208,208,208,248,248,248,248,248,248,248,248,32,32,32,32,32,32,32,32,72,72,72,72,72,72,72,72,112,112,112,112,112,112,112,112,152,152,152,152,152,152,152,152,192,192,192,192,192,192,192,192
tileYOffHi_Maze: .byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3

// Room 0 [Maze] 40x25 cells, 8x8px
room_000_tilemap: .import binary "room_000_tilemap.bin"

.const ROOM_TILE_META_COUNT = 1
roomTileId: .byte 0
roomTileMapLo: .byte <room_000_tilemap
roomTileMapHi: .byte >room_000_tilemap
roomTileCols: .byte 40
roomTileRows: .byte 25
roomTileWidthBytes: .byte 1
roomTileHeight: .byte 8
roomTilePtrLoLo: .byte <tilePtrLo_Maze
roomTilePtrLoHi: .byte >tilePtrLo_Maze
roomTilePtrHiLo: .byte <tilePtrHi_Maze
roomTilePtrHiHi: .byte >tilePtrHi_Maze
roomTileCollisionLo: .byte <tileCollision_Maze
roomTileCollisionHi: .byte >tileCollision_Maze
roomTileProp0Lo: .byte <tileProp0_Maze
roomTileProp0Hi: .byte >tileProp0_Maze
roomTileProp1Lo: .byte <tileProp1_Maze
roomTileProp1Hi: .byte >tileProp1_Maze
roomTileProp2Lo: .byte <tileProp2_Maze
roomTileProp2Hi: .byte >tileProp2_Maze
roomTileProp3Lo: .byte <tileProp3_Maze
roomTileProp3Hi: .byte >tileProp3_Maze
roomTileXCellLo: .byte <tileXCell_Maze
roomTileXCellHi: .byte >tileXCell_Maze
roomTileYCellLo: .byte <tileYCell_Maze
roomTileYCellHi: .byte >tileYCell_Maze
roomTileYOffLoLo: .byte <tileYOffLo_Maze
roomTileYOffLoHi: .byte >tileYOffLo_Maze
roomTileYOffHiLo: .byte <tileYOffHi_Maze
roomTileYOffHiHi: .byte >tileYOffHi_Maze
