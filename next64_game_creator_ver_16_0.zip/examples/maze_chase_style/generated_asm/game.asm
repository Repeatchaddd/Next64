// Next64 Studios C64 Game Creator generated game
// Project: Maze Chase Logic Example
// Hybrid renderer: software bitmap sprites + VIC-II raster-multiplexed hardware sprites

.import source "generated_defs.asm"

BasicUpstart2(start)

* = $8000 "Main"

frameCounter: .byte 0
lastKey: .byte 0

start:
    sei
    // $36: BASIC ROM out, KERNAL ROM + I/O remain visible.
    // Main engine/data can safely use $8000-$CFFF without the bitmap banks.
    lda #$36
    sta $01
    jsr InitSoftwareDisplay
    cli
    jsr SelectBackBuffer
    jsr DrawAllObjects
    jsr SaveCurrentObjectState
    jsr WaitFrame
    jsr UpdateVICSprites
    jsr SwapDisplayBuffer

mainLoop:
    jsr SelectBackBuffer
    jsr ErasePreviousObjects
    jsr EraseCurrentObjectRects
    jsr SaveLogicPositions
    inc frameCounter
    jsr ReadLastKey
    jsr ScanKeyboardMatrix
    jsr events_slot_000
    jsr events_slot_001
    jsr events_slot_002
    jsr CommitKeyboardMatrix
    jsr UpdatePaths
    jsr UpdateAnimations
    jsr DrawAllObjects
    jsr SaveCurrentObjectState
    jsr WaitFrame
    jsr UpdateVICSprites
    jsr SwapDisplayBuffer
    jmp mainLoop

ReadLastKey:
    jsr $ffe4
    sta lastKey
    rts

WaitFrame:
WaitFrame1:
    lda $d012
    cmp #$fc
    bne WaitFrame1
WaitFrame2:
    lda $d012
    cmp #$fc
    beq WaitFrame2
    rts

.import source "generated_room_tiles.asm"
.import source "generated_paths.asm"
.import source "generated_runtime.asm"
.import source "generated_rooms.asm"
.import source "generated_instances.asm"
.import source "generated_variables.asm"
.import source "generated_objects.asm"
.import source "generated_events.asm"
.import source "generated_sprites.asm"


.import source "generated_vic_sprites.asm"
