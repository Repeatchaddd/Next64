// Generated sprite resources
// Contiguous with Main; no fixed origin here.
.const SPR_Maze_000_MODE = 0
.const SPR_Maze_000_WIDTH = 8
.const SPR_Maze_000_HEIGHT = 8
.const SPR_Maze_000_FRAMES = 1
.const SPR_Maze_000_FRAME_SIZE = 16
.const SPR_Maze_000_IMAGE_BYTES = 8
sprite_Maze_000_data: .import binary "sprite_Maze_000.bin"

.const SPR_Maze_001_MODE = 0
.const SPR_Maze_001_WIDTH = 8
.const SPR_Maze_001_HEIGHT = 8
.const SPR_Maze_001_FRAMES = 1
.const SPR_Maze_001_FRAME_SIZE = 16
.const SPR_Maze_001_IMAGE_BYTES = 8
sprite_Maze_001_data: .import binary "sprite_Maze_001.bin"
