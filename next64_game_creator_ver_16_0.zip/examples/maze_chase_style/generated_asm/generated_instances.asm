// Reusable room object instances
.const ROOM_INSTANCE_COUNT = 2
instanceRuntimeSlot: .byte 1,2
instanceTemplate: .byte 1,1
instanceRoom: .byte 0,0
instanceXLo: .byte 152,160
instanceXHi: .byte 0,0
instanceY: .byte 24,168
instanceActive: .byte 1,1
