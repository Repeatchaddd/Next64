Next64 Maze-Chase Style Logic Demo - VER 09.12

This is an editable example project built with general Next64 tools. There is no Pac-Man-specific runtime code.

Controls:
  W A S D - request a direction

The player uses two ordinary per-instance properties:
  P0 = current movement direction
  P1 = queued/requested direction

Keyboard Held events update P1 immediately. At tile alignment, the generic Apply Queued Direction action checks the requested direction and copies it to P0 only if the tile ahead is not Solid. Move In Direction Property then moves using P0.

This demonstrates grid movement, queued turns, solid tile collision, collectible tile properties, score variables, and maze-enemy direction selection.
