// Generated 8-bit globals
var_waste_rank: .byte 11
var_stock_pos: .byte 0
var_score: .byte 0
var_draw_request: .byte 0
