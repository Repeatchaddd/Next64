// Reusable room object instances
.const ROOM_INSTANCE_COUNT = 10
instanceRuntimeSlot: .byte 1,2,3,4,5,6,7,8,9,10
instanceTemplate: .byte 1,2,3,4,5,6,7,8,9,10
instanceRoom: .byte 0,0,0,0,0,0,0,0,0,0
instanceXLo: .byte 32,72,112,152,192,232,16,152,139,120
instanceXHi: .byte 0,0,0,0,0,0,1,0,0,0
instanceY: .byte 66,66,66,66,66,66,66,158,18,164
instanceActive: .byte 1,1,1,1,1,1,1,1,0,1
