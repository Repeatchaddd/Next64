// Generated named object paths
pathStart: .byte 0
pathCount: .byte 0
pathSpeed: .byte 1
pathMode: .byte 0
pathPointXLo: .byte 0
pathPointXHi: .byte 0
pathPointY: .byte 0
