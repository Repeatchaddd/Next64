// Generated visual event/action code
compareOtherTemp: .byte 0
events_slot_000: // template 0, instance 255
    ldx #0
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda keyMatrixCurrent+2
    and #$02
    bne !skip_0_0+
    ldx #0
    lda objectXHi,x
    bne !prop_gt_0_0+
    lda objectXLo,x
    cmp #8
    bcc !skip_0_0+
    beq !skip_0_0+
!prop_gt_0_0:
    ldx #0
    lda objectXLo,x
    clc
    adc #248
    sta objectXLo,x
    bcs !mx_done+
    dec objectXHi,x
!mx_done:
!skip_0_0:
    lda keyMatrixCurrent+2
    and #$04
    bne !skip_0_1+
    ldx #0
    lda objectXHi,x
    cmp #1
    bcc !prop_lt_0_1+
    bne !skip_0_1+
    lda objectXLo,x
    cmp #44
    bcs !skip_0_1+
!prop_lt_0_1:
    ldx #0
    lda objectXLo,x
    clc
    adc #8
    sta objectXLo,x
    bcc !mx_done+
    inc objectXHi,x
!mx_done:
!skip_0_1:
    lda keyMatrixCurrent+1
    and #$02
    bne !skip_0_2+
    ldx #0
    lda objectY,x
    cmp #18
    bcc !skip_0_2+
    beq !skip_0_2+
    ldx #0
    lda objectY,x
    clc
    adc #248
    sta objectY,x
!skip_0_2:
    lda keyMatrixCurrent+5
    and #$02
    bne !skip_0_3+
    ldx #0
    lda objectY,x
    cmp #126
    bcs !skip_0_3+
    ldx #0
    lda objectY,x
    clc
    adc #8
    sta objectY,x
!skip_0_3:
    ldx #0
    lda var_waste_rank
    sta objectP0,x
!skip_0_4:
    lda keyMatrixCurrent+7
    and #$10
    bne !skip_0_5+
    lda keyMatrixPrevious+7
    and #$10
    beq !skip_0_5+
    ldx #0
    lda #1
    jsr CheckCollisionWithTemplate
    bcs !skip_0_5+
    ldx #0
    lda #2
    jsr CheckCollisionWithTemplate
    bcs !skip_0_5+
    ldx #0
    lda #3
    jsr CheckCollisionWithTemplate
    bcs !skip_0_5+
    ldx #0
    lda #4
    jsr CheckCollisionWithTemplate
    bcs !skip_0_5+
    ldx #0
    lda #5
    jsr CheckCollisionWithTemplate
    bcs !skip_0_5+
    ldx #0
    lda #6
    jsr CheckCollisionWithTemplate
    bcs !skip_0_5+
    ldx #0
    lda #7
    jsr CheckCollisionWithTemplate
    bcs !skip_0_5+
    lda #1
    sta var_draw_request
!skip_0_5:
    lda keyMatrixCurrent+7
    and #$10
    bne !skip_0_6+
    lda keyMatrixPrevious+7
    and #$10
    beq !skip_0_6+
    ldx #0
    jsr CheckCollisionTopmost
    bcc !skip_0_6+
    ldx collisionOtherIndex
    cpx #$ff
    beq !skip_0_6+
    lda objectP0,x
    sta compareOtherTemp
    ldx #0
    lda objectP0,x
    cmp compareOtherTemp
    sec
    sbc #$01
    cmp compareOtherTemp
    bne !skip_0_6+
    ldx collisionOtherIndex
    cpx #$ff
    beq !skip_0_6+
    lda objectP0,x
    sta var_waste_rank
    ldx collisionOtherIndex
    cpx #$ff
    beq !skip_0_6+
    lda objectP1,x
    clc
    adc #1
    sta objectP1,x
    lda var_score
    clc
    adc #1
    sta var_score
    ldx #0
    lda #12
    sta objectXLo,x
    lda #0
    sta objectXHi,x
    lda #20
    sta objectY,x
!skip_0_6:
    lda keyMatrixCurrent+7
    and #$10
    bne !skip_0_7+
    lda keyMatrixPrevious+7
    and #$10
    beq !skip_0_7+
    ldx #0
    jsr CheckCollisionTopmost
    bcc !skip_0_7+
    ldx collisionOtherIndex
    cpx #$ff
    beq !skip_0_7+
    lda objectP0,x
    sta compareOtherTemp
    ldx #0
    lda objectP0,x
    cmp compareOtherTemp
    clc
    adc #$01
    cmp compareOtherTemp
    bne !skip_0_7+
    ldx collisionOtherIndex
    cpx #$ff
    beq !skip_0_7+
    lda objectP0,x
    sta var_waste_rank
    ldx collisionOtherIndex
    cpx #$ff
    beq !skip_0_7+
    lda objectP1,x
    clc
    adc #1
    sta objectP1,x
    lda var_score
    clc
    adc #1
    sta var_score
    ldx #0
    lda #12
    sta objectXLo,x
    lda #0
    sta objectXHi,x
    lda #20
    sta objectY,x
!skip_0_7:
    lda var_score
    cmp #35
    bne !skip_0_8+
    ldx #9
    lda #1
    sta objectActive,x
!skip_0_8:
    rts

events_slot_001: // template 1, instance 1
    ldx #1
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda frameCounter
    cmp #1
    bne !skip_1_0+
    ldx #1
    lda objectP0,x
    sta objectFrame,x
!skip_1_0:
    ldx #1
    lda objectP1,x
    cmp #1
    bne !skip_1_1+
    ldx #1
    lda #4
    sta objectP0,x
    ldx #1
    lda objectP0,x
    sta objectFrame,x
!skip_1_1:
    ldx #1
    lda objectP1,x
    cmp #2
    bne !skip_1_2+
    ldx #1
    lda #12
    sta objectP0,x
    ldx #1
    lda objectP0,x
    sta objectFrame,x
!skip_1_2:
    ldx #1
    lda objectP1,x
    cmp #3
    bne !skip_1_3+
    ldx #1
    lda #11
    sta objectP0,x
    ldx #1
    lda objectP0,x
    sta objectFrame,x
!skip_1_3:
    ldx #1
    lda objectP1,x
    cmp #4
    bne !skip_1_4+
    ldx #1
    lda #10
    sta objectP0,x
    ldx #1
    lda objectP0,x
    sta objectFrame,x
!skip_1_4:
    ldx #1
    lda objectP1,x
    cmp #5
    bne !skip_1_5+
    ldx #1
    lda #0
    sta objectActive,x
!skip_1_5:
    rts

events_slot_002: // template 2, instance 2
    ldx #2
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda frameCounter
    cmp #1
    bne !skip_2_0+
    ldx #2
    lda objectP0,x
    sta objectFrame,x
!skip_2_0:
    ldx #2
    lda objectP1,x
    cmp #1
    bne !skip_2_1+
    ldx #2
    lda #2
    sta objectP0,x
    ldx #2
    lda objectP0,x
    sta objectFrame,x
!skip_2_1:
    ldx #2
    lda objectP1,x
    cmp #2
    bne !skip_2_2+
    ldx #2
    lda #10
    sta objectP0,x
    ldx #2
    lda objectP0,x
    sta objectFrame,x
!skip_2_2:
    ldx #2
    lda objectP1,x
    cmp #3
    bne !skip_2_3+
    ldx #2
    lda #1
    sta objectP0,x
    ldx #2
    lda objectP0,x
    sta objectFrame,x
!skip_2_3:
    ldx #2
    lda objectP1,x
    cmp #4
    bne !skip_2_4+
    ldx #2
    lda #13
    sta objectP0,x
    ldx #2
    lda objectP0,x
    sta objectFrame,x
!skip_2_4:
    ldx #2
    lda objectP1,x
    cmp #5
    bne !skip_2_5+
    ldx #2
    lda #0
    sta objectActive,x
!skip_2_5:
    rts

events_slot_003: // template 3, instance 3
    ldx #3
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda frameCounter
    cmp #1
    bne !skip_3_0+
    ldx #3
    lda objectP0,x
    sta objectFrame,x
!skip_3_0:
    ldx #3
    lda objectP1,x
    cmp #1
    bne !skip_3_1+
    ldx #3
    lda #1
    sta objectP0,x
    ldx #3
    lda objectP0,x
    sta objectFrame,x
!skip_3_1:
    ldx #3
    lda objectP1,x
    cmp #2
    bne !skip_3_2+
    ldx #3
    lda #2
    sta objectP0,x
    ldx #3
    lda objectP0,x
    sta objectFrame,x
!skip_3_2:
    ldx #3
    lda objectP1,x
    cmp #3
    bne !skip_3_3+
    ldx #3
    lda #9
    sta objectP0,x
    ldx #3
    lda objectP0,x
    sta objectFrame,x
!skip_3_3:
    ldx #3
    lda objectP1,x
    cmp #4
    bne !skip_3_4+
    ldx #3
    lda #6
    sta objectP0,x
    ldx #3
    lda objectP0,x
    sta objectFrame,x
!skip_3_4:
    ldx #3
    lda objectP1,x
    cmp #5
    bne !skip_3_5+
    ldx #3
    lda #0
    sta objectActive,x
!skip_3_5:
    rts

events_slot_004: // template 4, instance 4
    ldx #4
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda frameCounter
    cmp #1
    bne !skip_4_0+
    ldx #4
    lda objectP0,x
    sta objectFrame,x
!skip_4_0:
    ldx #4
    lda objectP1,x
    cmp #1
    bne !skip_4_1+
    ldx #4
    lda #13
    sta objectP0,x
    ldx #4
    lda objectP0,x
    sta objectFrame,x
!skip_4_1:
    ldx #4
    lda objectP1,x
    cmp #2
    bne !skip_4_2+
    ldx #4
    lda #8
    sta objectP0,x
    ldx #4
    lda objectP0,x
    sta objectFrame,x
!skip_4_2:
    ldx #4
    lda objectP1,x
    cmp #3
    bne !skip_4_3+
    ldx #4
    lda #9
    sta objectP0,x
    ldx #4
    lda objectP0,x
    sta objectFrame,x
!skip_4_3:
    ldx #4
    lda objectP1,x
    cmp #4
    bne !skip_4_4+
    ldx #4
    lda #12
    sta objectP0,x
    ldx #4
    lda objectP0,x
    sta objectFrame,x
!skip_4_4:
    ldx #4
    lda objectP1,x
    cmp #5
    bne !skip_4_5+
    ldx #4
    lda #0
    sta objectActive,x
!skip_4_5:
    rts

events_slot_005: // template 5, instance 5
    ldx #5
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda frameCounter
    cmp #1
    bne !skip_5_0+
    ldx #5
    lda objectP0,x
    sta objectFrame,x
!skip_5_0:
    ldx #5
    lda objectP1,x
    cmp #1
    bne !skip_5_1+
    ldx #5
    lda #3
    sta objectP0,x
    ldx #5
    lda objectP0,x
    sta objectFrame,x
!skip_5_1:
    ldx #5
    lda objectP1,x
    cmp #2
    bne !skip_5_2+
    ldx #5
    lda #11
    sta objectP0,x
    ldx #5
    lda objectP0,x
    sta objectFrame,x
!skip_5_2:
    ldx #5
    lda objectP1,x
    cmp #3
    bne !skip_5_3+
    ldx #5
    lda #5
    sta objectP0,x
    ldx #5
    lda objectP0,x
    sta objectFrame,x
!skip_5_3:
    ldx #5
    lda objectP1,x
    cmp #4
    bne !skip_5_4+
    ldx #5
    lda #4
    sta objectP0,x
    ldx #5
    lda objectP0,x
    sta objectFrame,x
!skip_5_4:
    ldx #5
    lda objectP1,x
    cmp #5
    bne !skip_5_5+
    ldx #5
    lda #0
    sta objectActive,x
!skip_5_5:
    rts

events_slot_006: // template 6, instance 6
    ldx #6
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda frameCounter
    cmp #1
    bne !skip_6_0+
    ldx #6
    lda objectP0,x
    sta objectFrame,x
!skip_6_0:
    ldx #6
    lda objectP1,x
    cmp #1
    bne !skip_6_1+
    ldx #6
    lda #6
    sta objectP0,x
    ldx #6
    lda objectP0,x
    sta objectFrame,x
!skip_6_1:
    ldx #6
    lda objectP1,x
    cmp #2
    bne !skip_6_2+
    ldx #6
    lda #7
    sta objectP0,x
    ldx #6
    lda objectP0,x
    sta objectFrame,x
!skip_6_2:
    ldx #6
    lda objectP1,x
    cmp #3
    bne !skip_6_3+
    ldx #6
    lda #13
    sta objectP0,x
    ldx #6
    lda objectP0,x
    sta objectFrame,x
!skip_6_3:
    ldx #6
    lda objectP1,x
    cmp #4
    bne !skip_6_4+
    ldx #6
    lda #6
    sta objectP0,x
    ldx #6
    lda objectP0,x
    sta objectFrame,x
!skip_6_4:
    ldx #6
    lda objectP1,x
    cmp #5
    bne !skip_6_5+
    ldx #6
    lda #0
    sta objectActive,x
!skip_6_5:
    rts

events_slot_007: // template 7, instance 7
    ldx #7
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    lda frameCounter
    cmp #1
    bne !skip_7_0+
    ldx #7
    lda objectP0,x
    sta objectFrame,x
!skip_7_0:
    ldx #7
    lda objectP1,x
    cmp #1
    bne !skip_7_1+
    ldx #7
    lda #11
    sta objectP0,x
    ldx #7
    lda objectP0,x
    sta objectFrame,x
!skip_7_1:
    ldx #7
    lda objectP1,x
    cmp #2
    bne !skip_7_2+
    ldx #7
    lda #3
    sta objectP0,x
    ldx #7
    lda objectP0,x
    sta objectFrame,x
!skip_7_2:
    ldx #7
    lda objectP1,x
    cmp #3
    bne !skip_7_3+
    ldx #7
    lda #12
    sta objectP0,x
    ldx #7
    lda objectP0,x
    sta objectFrame,x
!skip_7_3:
    ldx #7
    lda objectP1,x
    cmp #4
    bne !skip_7_4+
    ldx #7
    lda #2
    sta objectP0,x
    ldx #7
    lda objectP0,x
    sta objectFrame,x
!skip_7_4:
    ldx #7
    lda objectP1,x
    cmp #5
    bne !skip_7_5+
    ldx #7
    lda #0
    sta objectActive,x
!skip_7_5:
    rts

events_slot_008: // template 8, instance 8
    ldx #8
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    ldx #8
    lda var_waste_rank
    sta objectP0,x
    ldx #8
    lda objectP0,x
    sta objectFrame,x
!skip_8_0:
    lda var_stock_pos
    cmp #15
    bne !skip_8_1+
    lda var_draw_request
    cmp #1
    bne !skip_8_1+
    lda #7
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_1:
    lda var_stock_pos
    cmp #14
    bne !skip_8_2+
    lda var_draw_request
    cmp #1
    bne !skip_8_2+
    lda #13
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_2:
    lda var_stock_pos
    cmp #13
    bne !skip_8_3+
    lda var_draw_request
    cmp #1
    bne !skip_8_3+
    lda #7
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_3:
    lda var_stock_pos
    cmp #12
    bne !skip_8_4+
    lda var_draw_request
    cmp #1
    bne !skip_8_4+
    lda #1
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_4:
    lda var_stock_pos
    cmp #11
    bne !skip_8_5+
    lda var_draw_request
    cmp #1
    bne !skip_8_5+
    lda #5
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_5:
    lda var_stock_pos
    cmp #10
    bne !skip_8_6+
    lda var_draw_request
    cmp #1
    bne !skip_8_6+
    lda #9
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_6:
    lda var_stock_pos
    cmp #9
    bne !skip_8_7+
    lda var_draw_request
    cmp #1
    bne !skip_8_7+
    lda #8
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_7:
    lda var_stock_pos
    cmp #8
    bne !skip_8_8+
    lda var_draw_request
    cmp #1
    bne !skip_8_8+
    lda #7
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_8:
    lda var_stock_pos
    cmp #7
    bne !skip_8_9+
    lda var_draw_request
    cmp #1
    bne !skip_8_9+
    lda #5
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_9:
    lda var_stock_pos
    cmp #6
    bne !skip_8_10+
    lda var_draw_request
    cmp #1
    bne !skip_8_10+
    lda #8
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_10:
    lda var_stock_pos
    cmp #5
    bne !skip_8_11+
    lda var_draw_request
    cmp #1
    bne !skip_8_11+
    lda #6
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_11:
    lda var_stock_pos
    cmp #4
    bne !skip_8_12+
    lda var_draw_request
    cmp #1
    bne !skip_8_12+
    lda #10
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_12:
    lda var_stock_pos
    cmp #3
    bne !skip_8_13+
    lda var_draw_request
    cmp #1
    bne !skip_8_13+
    lda #4
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_13:
    lda var_stock_pos
    cmp #2
    bne !skip_8_14+
    lda var_draw_request
    cmp #1
    bne !skip_8_14+
    lda #12
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_14:
    lda var_stock_pos
    cmp #1
    bne !skip_8_15+
    lda var_draw_request
    cmp #1
    bne !skip_8_15+
    lda #3
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_15:
    lda var_stock_pos
    cmp #0
    bne !skip_8_16+
    lda var_draw_request
    cmp #1
    bne !skip_8_16+
    lda #5
    sta var_waste_rank
    lda var_stock_pos
    clc
    adc #1
    sta var_stock_pos
    lda #0
    sta var_draw_request
!skip_8_16:
    rts

events_slot_009: // template 9, instance 9
    ldx #9
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    rts

events_slot_010: // template 10, instance 10
    ldx #10
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    rts
