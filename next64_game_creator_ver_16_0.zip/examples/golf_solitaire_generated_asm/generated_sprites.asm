// Generated sprite resources
// Contiguous with Main; no fixed origin here.
.const SPR_Golf_Solitaire_000_MODE = 1
.const SPR_Golf_Solitaire_000_WIDTH = 12
.const SPR_Golf_Solitaire_000_HEIGHT = 21
.const SPR_Golf_Solitaire_000_FRAMES = 1
.const SPR_Golf_Solitaire_000_FRAME_SIZE = 105
.const SPR_Golf_Solitaire_000_IMAGE_BYTES = 63
sprite_Golf_Solitaire_000_data: .import binary "sprite_Golf_Solitaire_000.bin"

.const SPR_Golf_Solitaire_001_MODE = 1
.const SPR_Golf_Solitaire_001_WIDTH = 12
.const SPR_Golf_Solitaire_001_HEIGHT = 21
.const SPR_Golf_Solitaire_001_FRAMES = 14
.const SPR_Golf_Solitaire_001_FRAME_SIZE = 105
.const SPR_Golf_Solitaire_001_IMAGE_BYTES = 63
sprite_Golf_Solitaire_001_data: .import binary "sprite_Golf_Solitaire_001.bin"

.const SPR_Golf_Solitaire_002_MODE = 1
.const SPR_Golf_Solitaire_002_WIDTH = 20
.const SPR_Golf_Solitaire_002_HEIGHT = 8
.const SPR_Golf_Solitaire_002_FRAMES = 1
.const SPR_Golf_Solitaire_002_FRAME_SIZE = 64
.const SPR_Golf_Solitaire_002_IMAGE_BYTES = 40
sprite_Golf_Solitaire_002_data: .import binary "sprite_Golf_Solitaire_002.bin"

.const SPR_Golf_Solitaire_003_MODE = 1
.const SPR_Golf_Solitaire_003_WIDTH = 16
.const SPR_Golf_Solitaire_003_HEIGHT = 12
.const SPR_Golf_Solitaire_003_FRAMES = 1
.const SPR_Golf_Solitaire_003_FRAME_SIZE = 72
.const SPR_Golf_Solitaire_003_IMAGE_BYTES = 48
sprite_Golf_Solitaire_003_data: .import binary "sprite_Golf_Solitaire_003.bin"
