Next64 Game Creator VER 09.0 - Pathing Example
================================================

Open:
  examples/pathing_demo.n64game

The Player/Patrol Object is assigned to the named path "Rectangle Patrol".
Open the Paths tab to inspect or change its waypoints, speed, and movement mode.
Open the Objects tab to assign or disable a path on an object.

Path modes
----------
loop    Last waypoint returns to the first waypoint.
patrol  Reverses direction at each end of the path.
once    Stops path movement at the final waypoint.

Waypoints use absolute C64 screen coordinates:
  X = 0-319
  Y = 0-199

Speed is pixels moved per C64 frame, from 1 through 16.
The generated runtime supports up to 255 total path waypoints across all named paths.
