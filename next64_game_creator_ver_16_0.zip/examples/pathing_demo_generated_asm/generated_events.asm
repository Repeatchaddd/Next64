// Generated visual event/action code
compareOtherTemp: .byte 0
events_slot_000: // template 0, instance 255
    ldx #0
    lda objectActive,x
    bne !slot_active+
    rts
!slot_active:
    lda objectRoom,x
    cmp currentRoom
    beq !slot_room+
    rts
!slot_room:
    rts
