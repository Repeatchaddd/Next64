// Generated room metadata
// Room 0: Room 0 / level Starter / EXPLICIT player Object 0 at 144,92
// AUTO EDGE ENTRY rule for rooms without an explicit start:
// DOWN -> y=top, keep prior x; UP -> y=bottom, keep prior x;
// RIGHT -> x=left, keep prior y; LEFT -> x=right, keep prior y.
roomId: .byte 0
roomPlayerStartMode: .byte 1
roomPlayerObject: .byte 0
roomPlayerSprite: .byte 0
roomPlayerStartXLo: .byte 144
roomPlayerStartXHi: .byte 0
roomPlayerStartY: .byte 92
