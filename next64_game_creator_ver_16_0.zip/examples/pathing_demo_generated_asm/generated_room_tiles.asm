// Next64 room tile resources, renderer metadata, and collision data
// Room 0 [Starter] 40x25 cells, 8x8px
room_000_tilemap: .import binary "room_000_tilemap.bin"

.const ROOM_TILE_META_COUNT = 1
roomTileId: .byte 0
roomTileMapLo: .byte <room_000_tilemap
roomTileMapHi: .byte >room_000_tilemap
roomTileCols: .byte 40
roomTileRows: .byte 25
roomTileWidthBytes: .byte 1
roomTileHeight: .byte 8
roomTilePtrLoLo: .byte 0
roomTilePtrLoHi: .byte 0
roomTilePtrHiLo: .byte 0
roomTilePtrHiHi: .byte 0
roomTileCollisionLo: .byte 0
roomTileCollisionHi: .byte 0
roomTileProp0Lo: .byte 0
roomTileProp0Hi: .byte 0
roomTileProp1Lo: .byte 0
roomTileProp1Hi: .byte 0
roomTileProp2Lo: .byte 0
roomTileProp2Hi: .byte 0
roomTileProp3Lo: .byte 0
roomTileProp3Hi: .byte 0
roomTileXCellLo: .byte 0
roomTileXCellHi: .byte 0
roomTileYCellLo: .byte 0
roomTileYCellHi: .byte 0
roomTileYOffLoLo: .byte 0
roomTileYOffLoHi: .byte 0
roomTileYOffHiLo: .byte 0
roomTileYOffHiHi: .byte 0
