// Reusable room object instances
.const ROOM_INSTANCE_COUNT = 0
