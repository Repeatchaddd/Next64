// Generated named object paths
pathStart: .byte 0
pathCount: .byte 4
pathSpeed: .byte 4
pathMode: .byte 1
pathPointXLo: .byte 40,4,4,40
pathPointXHi: .byte 0,1,1,0
pathPointY: .byte 40,40,150,150
