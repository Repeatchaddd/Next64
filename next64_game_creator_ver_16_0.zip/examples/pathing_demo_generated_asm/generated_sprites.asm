// Generated sprite resources
// Contiguous with Main; no fixed origin here.
.const SPR_Starter_000_MODE = 1
.const SPR_Starter_000_WIDTH = 8
.const SPR_Starter_000_HEIGHT = 8
.const SPR_Starter_000_FRAMES = 1
.const SPR_Starter_000_FRAME_SIZE = 24
.const SPR_Starter_000_IMAGE_BYTES = 16
sprite_Starter_000_data: .import binary "sprite_Starter_000.bin"
