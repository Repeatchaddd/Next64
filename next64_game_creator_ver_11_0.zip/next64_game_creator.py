#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, re, time
from pathlib import Path
import tkinter as tk
import webbrowser
from tkinter import ttk, filedialog, messagebox, simpledialog
from dataclasses import dataclass, field, asdict
try:
    from PIL import Image, ImageTk, ImageDraw
except Exception:
    Image = None
    ImageTk = None
    ImageDraw = None

APP_TITLE = "Next64 Studios - C64 Game Creator VER 11.0"
KICKASS_DOWNLOAD_URL = "https://theweb.dk/KickAssembler/"
SETTINGS_PATH = Path.home() / ".next64_game_creator_settings.json"

# PC preview palette tuned closer to common real-C64 / VICE-style output.
# Hardware/export color indices remain exactly 0..15.
C64_PALETTE = [
    # Editor recognition palette. These RGB values are intentionally chosen so
    # each named C64 color reads clearly in small swatches. Exported/generated
    # VIC-II color indices remain exactly 0..15.
    ("Black", "#000000"),
    ("White", "#FFFFFF"),
    ("Red", "#C73A32"),
    ("Cyan", "#52C8D6"),
    ("Purple", "#8E4BB3"),
    ("Green", "#4FAE4A"),
    ("Blue", "#3A50C9"),
    ("Yellow", "#E3D84A"),
    ("Orange", "#D97928"),
    ("Brown", "#7A4A22"),
    ("Light Red", "#F06A61"),
    ("Dark Gray", "#444444"),
    ("Gray", "#808080"),
    ("Light Green", "#8FD878"),
    ("Light Blue", "#7C8FF0"),
    ("Light Gray", "#BDBDBD"),
]

EVENT_TYPES = [
    "Create", "Every Frame", "Every N Frames",
    "Keyboard Held", "Keyboard Pressed", "Keyboard Pressed Over Object", "Keyboard Pressed Over Topmost Object",
    "Collision With Object", "Collision With Sprite", "Collision With Topmost Object", "Tile Collision", "Tile Property Equals",
    "Variable Equals", "Variable Greater Than", "Variable Less Than",
    "Object Leaves Screen", "Animation Finished", "Path Finished"
]
CONDITION_TYPES = [
    "None", "Variable Equals", "Variable Greater Than", "Variable Less Than",
    "Object Active", "Object Inactive",
    "Object X Greater Than", "Object X Less Than",
    "Object Y Greater Than", "Object Y Less Than",
    "Variable Not Equals", "Object In Room",
    "Self Property Equals", "Self Property Not Equals",
    "Self Property Greater Than", "Self Property Less Than",
    "Self Property Equals Variable", "Self Property Not Equals Variable",
    "Self Property Greater Than Variable", "Self Property Less Than Variable",
    "Self Property Equals Other Property", "Self Property Not Equals Other Property",
    "Self Property Greater Than Other Property", "Self Property Less Than Other Property",
    "Self Property One Greater Than Other Property", "Self Property One Less Than Other Property",
    "Other Property Equals", "Other Property Not Equals",
    "Other Property Greater Than", "Other Property Less Than",
    "Other Property Equals Variable", "Other Property Not Equals Variable",
    "Other Property Greater Than Variable", "Other Property Less Than Variable",
    "Self Touching Tile", "Self Tile Property Equals", "Self Center Tile Property Equals",
    "Self Tile Ahead Is", "Self Aligned To Tile",
    "Self Overlaps Topmost Object", "Self Does Not Overlap Object",
    "Inventory Contains Item", "Inventory Slot Equals", "Inventory Quantity At Least"
]
ACTION_TYPES = [
    "Move X", "Move Y", "Set Position",
    "Set Variable", "Add To Variable", "Set Frame",
    "Set Object Active", "Destroy Object", "Create Object", "Create Object At Object",
    "Change Scene", "Change Room", "Set Object Room",
    "Set Object X", "Set Object Y",
    "Destroy Colliding Object", "Destroy Collision Pair",
    "Set Colliding Object Active",
    "Set Self Property", "Add To Self Property",
    "Set Other Property", "Add To Other Property",
    "Set Variable From Self Property", "Set Variable From Other Property",
    "Set Self Property From Variable", "Set Other Property From Variable",
    "Add Variable To Self Property", "Subtract Variable From Self Property",
    "Add Variable To Other Property", "Subtract Variable From Other Property",
    "Set Frame From Self Property", "Set Frame From Other Property",
    "Set Other Property From Self Property", "Set Self Property From Other Property",
    "Toggle Self Property", "Toggle Other Property",
    "Bring Self To Front", "Bring Other To Front", "Send Self To Back", "Send Other To Back",
    "Set Variable Random",
    "Start Path", "Stop Path", "Restart Path", "Set Path", "Move Toward Object",
    "Set Direction", "Move In Direction Property", "Choose Available Direction", "Apply Queued Direction",
    "Snap Self To Tile", "Set Tile Under Self",
    "Add Inventory Item", "Remove Inventory Item", "Use Inventory Item",
    "Move Inventory Slot", "Set Selected Inventory Slot", "Render Inventory Tiles",
    "Restore Self Position",
    "Change Scene", "Custom ASM Call"
]


OBJECT_PROPERTIES = ["X","Y","Active","Room","Sprite","Frame","Object ID","Instance ID"] + [f"P{i}" for i in range(8)]
SETTABLE_OBJECT_PROPERTIES = ["X","Y","Active","Room","Frame"] + [f"P{i}" for i in range(8)]

BEHAVIOR_TEMPLATES = {
    "8-Way Keyboard Movement": [
        {"event":"Keyboard Held","event_arg1":"A","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Move X","action_arg1":"-2","action_arg2":""},
        {"event":"Keyboard Held","event_arg1":"D","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Move X","action_arg1":"2","action_arg2":""},
        {"event":"Keyboard Held","event_arg1":"W","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Move Y","action_arg1":"-2","action_arg2":""},
        {"event":"Keyboard Held","event_arg1":"S","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Move Y","action_arg1":"2","action_arg2":""},
    ],
    "Simple Horizontal Patrol": [
        {"event":"Every Frame","event_arg1":"","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Move X","action_arg1":"1","action_arg2":""},
    ],
    "Player Left/Right": [
        {"event":"Keyboard Held","event_arg1":"A","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Move X","action_arg1":"-2","action_arg2":""},
        {"event":"Keyboard Held","event_arg1":"D","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Move X","action_arg1":"2","action_arg2":""},
    ],
    "Player Fire (Object 20)": [
        {"event":"Keyboard Pressed","event_arg1":"SPACE","event_arg2":"","condition":"Object Inactive","condition_arg1":"20","condition_arg2":"","action":"Create Object At Object","action_arg1":"20","action_arg2":"0"},
    ],
    "Projectile Up + Cleanup": [
        {"event":"Every Frame","event_arg1":"","event_arg2":"","condition":"Object Active","condition_arg1":"","condition_arg2":"","action":"Move Y","action_arg1":"-4","action_arg2":""},
        {"event":"Object Leaves Screen","event_arg1":"","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Destroy Object","action_arg1":"","action_arg2":""},
    ],
    "Deactivate Below Screen": [
        {"event":"Every Frame","event_arg1":"","event_arg2":"","condition":"Object Y Greater Than","condition_arg1":"","condition_arg2":"199","action":"Destroy Object","action_arg1":"","action_arg2":""},
    ],
    "Projectile Hits Sprite 1": [
        {"event":"Collision With Sprite","event_arg1":"1","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Add To Variable","action_arg1":"score","action_arg2":"10"},
        {"event":"Collision With Sprite","event_arg1":"1","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Destroy Collision Pair","action_arg1":"","action_arg2":""},
    ],
    "Solid Tile Stop": [
        {"event":"Tile Collision","event_arg1":"Solid","event_arg2":"","condition":"None","condition_arg1":"","condition_arg2":"","action":"Restore Self Position","action_arg1":"","action_arg2":""},
    ],
    "Card / Stack Cursor Pickup": [
        {"event":"Keyboard Pressed","event_arg1":"SPACE","event_arg2":"","condition":"Self Overlaps Topmost Object","condition_arg1":"","condition_arg2":"","actions":[
            {"action":"Bring Other To Front","action_arg1":"","action_arg2":""},
            {"action":"Toggle Self Property","action_arg1":"P0","action_arg2":""}
        ]},
        {"event":"Collision With Topmost Object","event_arg1":"","event_arg2":"","condition":"Self Property Equals","condition_arg1":"P0","condition_arg2":"1","actions":[
            {"action":"Set Other Property From Self Property","action_arg1":"X","action_arg2":"X"},
            {"action":"Set Other Property From Self Property","action_arg1":"Y","action_arg2":"Y"}
        ]},
    ],
}

def blank_pixels(mode, width, height):
    return [[0 for _ in range(width)] for _ in range(height)]

# Hardware-oriented preview palette used only by Test Play. Editor swatches use
# C64_PALETTE above for easy recognition; generated games still export indices.
C64_RUNTIME_PALETTE = [
    ("Black", "#000000"), ("White", "#FFFFFF"), ("Red", "#8B3F36"),
    ("Cyan", "#6FB7C1"), ("Purple", "#7A4A91"), ("Green", "#5FA34E"),
    ("Blue", "#40358F"), ("Yellow", "#CED36A"), ("Orange", "#A96832"),
    ("Brown", "#6B5424"), ("Light Red", "#B96F64"), ("Dark Gray", "#444444"),
    ("Gray", "#707070"), ("Light Green", "#9BD58B"), ("Light Blue", "#7A70C4"),
    ("Light Gray", "#A6A6A6"),
]

@dataclass
class Frame:
    name: str = "Frame 1"
    duration: int = 6
    pixels: list = field(default_factory=list)

@dataclass
class Sprite:
    sprite_id: int = 0
    level_id: str = "Scene 1"
    name: str = "Sprite 0"
    mode: str = "hires"
    width: int = 8
    height: int = 8
    colors: dict = field(default_factory=lambda: {"hires":1,"mc1":5,"mc2":6,"local":1})
    storage: str = "auto"
    bank: int = 0
    base_address: str = ""
    loop: bool = True
    auto_animate: bool = True
    renderer: str = "software"   # software | vic
    source_format: str = ""
    frames: list = field(default_factory=list)

@dataclass
class PathDefinition:
    name: str = "Path 1"
    level_id: str = "Scene 1"
    speed: int = 1
    mode: str = "loop"   # loop | patrol | once
    points: list = field(default_factory=lambda: [[40,40],[200,40]])

@dataclass
class GameObject:
    object_id: int = 0
    name: str = "Object 0"
    sprite_id: int = 0
    sprite_level: str = "Scene 1"
    x: int = 80
    y: int = 80
    active: bool = True
    scene: str = "Scene 1"
    room_id: int = 0
    properties: list = field(default_factory=lambda: [0,0,0,0,0,0,0,0])
    path_name: str = ""
    path_enabled: bool = False
    events: list = field(default_factory=list)

@dataclass
class RoomInstance:
    instance_id: int = 0
    object_id: int = 1
    room_id: int = 0
    level_id: str = "Scene 1"
    x: int = 80
    y: int = 80
    active: bool = True
    properties: list = field(default_factory=lambda: [0,0,0,0,0,0,0,0])
    z_order: int = 0

@dataclass
class TileSet:
    name: str = ""
    source_format: str = ""
    tiles: list = field(default_factory=list)
    tile_local_colors: list = field(default_factory=list)
    tile_collision: list = field(default_factory=list)  # 0 none, 1 solid, 2 hazard
    tile_properties: list = field(default_factory=list)   # per tile: [P0,P1,P2,P3], bytes 0-255
    tile_width: int = 8
    tile_height: int = 8
    mode: str = "multicolor"

@dataclass
class Room:
    room_id: int = 0
    name: str = "Room 0"
    level_id: str = "Scene 1"
    width: int = 320
    height: int = 200
    tile_map: list = field(default_factory=lambda: [[-1 for _ in range(40)] for _ in range(25)])
    player_start_enabled: bool = False
    player_start_object_id: int = 0
    player_start_x: int = 156
    player_start_y: int = 180
    player_start_sprite_id: int = 0

@dataclass
class Scene:
    name: str = "Scene 1"
    background_color: int = 0
    display_mode: str = "hires"
    mc1: int = 5
    mc2: int = 6
    local: int = 7

@dataclass
class Variable:
    name: str = "score"
    initial: int = 0

@dataclass
class InventoryItem:
    item_id: int = 1
    name: str = "Item 1"
    tile_id: int = 0
    max_stack: int = 99

@dataclass
class InventoryConfig:
    enabled: bool = False
    slot_count: int = 8
    items: list = field(default_factory=list)
    initial_items: list = field(default_factory=lambda: [255]*8)
    initial_quantities: list = field(default_factory=lambda: [0]*8)
    selected_slot: int = 0
    display_room_id: int = 0
    display_x: int = 1
    display_y: int = 1
    display_columns: int = 4
    empty_tile_id: int = 0

@dataclass
class Project:
    title: str = "Untitled Next64 Game"
    expanded_memory: bool = False
    expanded_memory_kb: int = 512
    sprites: dict = field(default_factory=dict)
    objects: dict = field(default_factory=dict)
    instances: list = field(default_factory=list)
    scenes: list = field(default_factory=lambda: [Scene()])
    rooms: list = field(default_factory=lambda: [Room()])
    tilesets: dict = field(default_factory=dict)
    variables: list = field(default_factory=lambda: [Variable()])
    paths: list = field(default_factory=list)
    inventory: InventoryConfig = field(default_factory=InventoryConfig)
    start_scene: str = "Scene 1"
    start_room_id: int = 0

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1480x900")
        self.minsize(1180, 720)

        self.project = Project()
        self.project_path = None
        self.current_level = "Invaders"
        self.current_room_id = 0
        self.current_sprite_id = 0
        self.current_frame_index = 0
        self.current_object_id = 0
        self.current_event_index = None
        self.current_action_index = 0
        self.current_tool_value = 1
        self.dirty = False
        self._frame_syncing = False
        self.current_level = "Scene 1"
        self.current_room_id = 0
        self.room_drag_object_id = None
        self.current_tile_id = 0
        self.current_path_index = None
        self.current_path_point_index = None
        self.current_room_object_id = 0
        self.current_room_instance_id = None
        self.room_tool = "object"
        self.animation_preview_running = False
        self.animation_preview_after_id = None

        self._load_builtin_demo()
        self._build_menu()
        self._build_ui()
        self._refresh_all()
        # VER 09.3: informational first-run guidance. It never blocks editing.
        self.after(450, self._maybe_show_first_run_info)

    def _load_builtin_demo(self):
        """Load a small starter project built only from normal editor features."""
        level="Starter"
        self.project=Project(
            title="Next64 Editor-Native Starter",
            sprites={},
            objects={},
            instances=[],
            scenes=[Scene(
                name=level,
                background_color=6,
                display_mode="multicolor",
                mc1=1,
                mc2=7,
                local=5
            )],
            rooms=[Room(
                room_id=0,name="Room 0",level_id=level,
                player_start_enabled=True,player_start_object_id=0,
                player_start_x=144,player_start_y=92,player_start_sprite_id=0
            )],
            tilesets={},
            variables=[Variable(name="score",initial=0)],
            start_scene=level,
            start_room_id=0,
        )

        # Sprite 0 uses the same defaults available to any user.
        px=[
            [0,0,3,3,0,0,0,0],
            [0,3,2,2,3,0,0,0],
            [3,2,1,1,2,3,0,0],
            [3,2,1,1,2,3,0,0],
            [0,3,2,2,3,0,0,0],
            [0,0,3,3,0,0,0,0],
            [0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0],
        ]
        self.project.sprites[f"{level}:0"]=Sprite(
            sprite_id=0,level_id=level,name="Player",
            mode="multicolor",width=8,height=8,renderer="software",
            colors={"hires":1,"mc1":1,"mc2":7,"local":5},
            frames=[Frame(name="Player",duration=6,pixels=px)]
        )

        # Everything below is ordinary Visual Logic that a user can create.
        self.project.objects[0]=GameObject(
            object_id=0,name="Player",sprite_id=0,sprite_level=level,
            x=144,y=92,active=True,scene=level,room_id=0,
            events=[
                {"event":"Keyboard Held","event_arg1":"A","event_arg2":"",
                 "condition":"Self Property Greater Than","condition_arg1":"X","condition_arg2":"0",
                 "action":"Move X","action_arg1":"-2","action_arg2":""},
                {"event":"Keyboard Held","event_arg1":"D","event_arg2":"",
                 "condition":"Self Property Less Than","condition_arg1":"X","condition_arg2":"304",
                 "action":"Move X","action_arg1":"2","action_arg2":""},
                {"event":"Keyboard Held","event_arg1":"W","event_arg2":"",
                 "condition":"Self Property Greater Than","condition_arg1":"Y","condition_arg2":"0",
                 "action":"Move Y","action_arg1":"-2","action_arg2":""},
                {"event":"Keyboard Held","event_arg1":"S","event_arg2":"",
                 "condition":"Self Property Less Than","condition_arg1":"Y","condition_arg2":"184",
                 "action":"Move Y","action_arg1":"2","action_arg2":""},
                {"event":"Keyboard Pressed","event_arg1":"SPACE","event_arg2":"",
                 "condition":"None","condition_arg1":"","condition_arg2":"",
                 "action":"Add To Variable","action_arg1":"score","action_arg2":"1"},
            ]
        )

        self.current_level=level
        self.current_room_id=0
        self.current_sprite_id=0
        self.current_frame_index=0
        self.current_object_id=0
        self.current_event_index=None
        self.current_action_index=0
        self.dirty=False

    def _build_menu(self):
        m = tk.Menu(self)
        fm = tk.Menu(m, tearoff=0)
        fm.add_command(label="New Project", command=self.new_project)
        fm.add_command(label="Load Starter Demo", command=self.load_demo_project)
        fm.add_command(label="Open Project...", command=self.open_project)
        fm.add_command(label="Save", command=self.save_project)
        fm.add_command(label="Save As...", command=self.save_project_as)
        fm.add_separator()
        fm.add_command(label="Generate ASM...", command=self.generate_asm_dialog)
        fm.add_command(label="Build PRG...", command=self.build_prg_dialog)
        fm.add_separator()
        fm.add_command(label="Exit", command=self.destroy)
        m.add_cascade(label="File", menu=fm)
        hm = tk.Menu(m, tearoff=0)
        hm.add_command(label="Kick Assembler & Sprite Renderer Info...", command=self.show_first_run_info)
        hm.add_separator()
        hm.add_command(label="About", command=lambda: messagebox.showinfo(
            "About",
            "Next64 Studios C64 Game Creator VER 11.0\n"
            "Visual game authoring for Commodore 64 software and VIC-II sprites."
        ))
        m.add_cascade(label="Help", menu=hm)
        self.config(menu=m)

    def _load_app_settings(self):
        try:
            if SETTINGS_PATH.exists():
                data=json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
                return data if isinstance(data,dict) else {}
        except Exception:
            pass
        return {}

    def _save_app_settings(self, data):
        try:
            SETTINGS_PATH.write_text(json.dumps(data,indent=2),encoding="utf-8")
        except Exception:
            # Settings persistence should never prevent the editor from running.
            pass

    def _maybe_show_first_run_info(self):
        settings=self._load_app_settings()
        if not settings.get("hide_kickass_renderer_info",False):
            self.show_first_run_info()

    def show_first_run_info(self):
        # Only one copy of the information window at a time.
        try:
            if getattr(self,"_first_run_info_window",None) and self._first_run_info_window.winfo_exists():
                self._first_run_info_window.lift()
                self._first_run_info_window.focus_force()
                return
        except Exception:
            pass

        win=tk.Toplevel(self)
        self._first_run_info_window=win
        win.title("Before You Build - Kick Assembler & Sprite Renderers")
        win.resizable(False,False)
        win.transient(self)

        outer=ttk.Frame(win,padding=16)
        outer.pack(fill="both",expand=True)
        ttk.Label(outer,text="Before You Build",font=("TkDefaultFont",14,"bold")).pack(anchor="w")

        kick=ttk.LabelFrame(outer,text="Kick Assembler Required",padding=10)
        kick.pack(fill="x",pady=(10,8))
        ttk.Label(kick,text=(
            "Next64 creates Kick Assembler source and uses KickAss.jar to compile a Commodore 64 .prg file.\n"
            "You can design, edit, and test projects without it, but Build PRG requires Kick Assembler and Java."
        ),justify="left",wraplength=650).pack(anchor="w")
        ttk.Label(kick,text="Official site: theweb.dk/KickAssembler/",justify="left").pack(anchor="w",pady=(7,0))

        render=ttk.LabelFrame(outer,text="Choosing a Sprite Renderer",padding=10)
        render.pack(fill="x",pady=(0,8))
        ttk.Label(render,text=(
            "Prefer VIC-II hardware sprites when practical: they are fast because the VIC-II displays them in hardware. "
            "The C64 has 8 hardware sprite channels, and Next64 can multiplex/reuse those channels at different vertical "
            "positions when timing permits.\n\n"
            "Software sprites are drawn by the CPU. They can supplement VIC-II sprites when you need more independently "
            "positioned objects, but they cost CPU time and can reduce game speed as sprite count, size, overlap, and "
            "background restoration work increase.\n\n"
            "Mixing VIC-II and software sprites is supported. A good approach is to use VIC-II sprites for important or "
            "frequently moving objects and software sprites where the extra flexibility is worth the processing cost."
        ),justify="left",wraplength=650).pack(anchor="w")

        hide_var=tk.BooleanVar(value=bool(self._load_app_settings().get("hide_kickass_renderer_info",False)))
        ttk.Checkbutton(outer,text="Don't show this information automatically again",variable=hide_var).pack(anchor="w",pady=(2,10))

        btns=ttk.Frame(outer)
        btns.pack(fill="x")

        def open_download():
            try:
                webbrowser.open(KICKASS_DOWNLOAD_URL,new=2)
            except Exception as exc:
                messagebox.showerror("Open Download Page",f"Could not open the web browser:\n{exc}",parent=win)

        def select_jar():
            p=filedialog.askopenfilename(parent=win,title="Select KickAss.jar",filetypes=[("KickAss.jar","KickAss.jar"),("JAR files","*.jar"),("All files","*.*")])
            if p:
                self.kickass_var.set(p)

        def close_info():
            settings=self._load_app_settings()
            settings["hide_kickass_renderer_info"]=bool(hide_var.get())
            self._save_app_settings(settings)
            try:win.destroy()
            except Exception:pass

        ttk.Button(btns,text="Open Kick Assembler Download Page",command=open_download).pack(side="left")
        ttk.Button(btns,text="Select KickAss.jar...",command=select_jar).pack(side="left",padx=6)
        ttk.Button(btns,text="Close",command=close_info).pack(side="right")
        win.protocol("WM_DELETE_WINDOW",close_info)
        win.update_idletasks()
        try:
            x=self.winfo_rootx()+max(20,(self.winfo_width()-win.winfo_reqwidth())//2)
            y=self.winfo_rooty()+max(20,(self.winfo_height()-win.winfo_reqheight())//3)
            win.geometry(f"+{x}+{y}")
        except Exception:
            pass

    def _build_ui(self):
        top = ttk.Frame(self, padding=4)
        top.pack(fill="x")
        ttk.Label(top, text="Project").pack(side="left")
        self.project_title_var = tk.StringVar()
        ttk.Entry(top, textvariable=self.project_title_var, width=34).pack(side="left", padx=4)
        self.reu_var = tk.BooleanVar()
        ttk.Checkbutton(top, text="Expanded memory / REU", variable=self.reu_var,
                        command=self._project_meta_changed).pack(side="left", padx=(10,2))
        self.reu_kb_var = tk.IntVar(value=512)
        ttk.Combobox(top, textvariable=self.reu_kb_var, state="readonly", width=8,
                     values=[128,256,512,1024,2048,4096,8192,16384]).pack(side="left")
        ttk.Button(top, text="Generate ASM", command=self.generate_asm_dialog).pack(side="right", padx=3)
        ttk.Button(top, text="Build PRG", command=self.build_prg_dialog).pack(side="right", padx=3)

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=4, pady=4)
        self.sprite_tab = ttk.Frame(self.nb)
        self.object_tab = ttk.Frame(self.nb)
        self.logic_tab = ttk.Frame(self.nb)
        self.scene_tab = ttk.Frame(self.nb)
        self.room_tab = ttk.Frame(self.nb)
        self.tile_tab = ttk.Frame(self.nb)
        self.inventory_tab = ttk.Frame(self.nb)
        self.variable_tab = ttk.Frame(self.nb)
        self.path_tab = ttk.Frame(self.nb)
        self.build_tab = ttk.Frame(self.nb)
        self.nb.add(self.sprite_tab, text="Sprites")
        self.nb.add(self.object_tab, text="Objects")
        self.nb.add(self.logic_tab, text="Visual Logic")
        self.nb.add(self.scene_tab, text="Levels")
        self.nb.add(self.room_tab, text="Rooms")
        self.nb.add(self.tile_tab, text="Tiles")
        self.nb.add(self.inventory_tab, text="Inventory")
        self.nb.add(self.variable_tab, text="Variables")
        self.nb.add(self.path_tab, text="Paths")
        self.nb.add(self.build_tab, text="Build")

        self._build_sprite_tab()
        self._build_object_tab()
        self._build_logic_tab()
        self._build_scene_tab()
        self._build_room_tab()
        self._build_tile_tab()
        self._build_inventory_tab()
        self._build_variable_tab()
        self._build_path_tab()
        self._build_build_tab()

        self.status = tk.StringVar(value="Ready")
        ttk.Label(self, textvariable=self.status, relief="sunken", anchor="w").pack(fill="x", side="bottom")

        self.project_title_var.trace_add("write", lambda *_: self._project_meta_changed())
        self.reu_kb_var.trace_add("write", lambda *_: self._project_meta_changed())

    def _build_sprite_tab(self):
        root = self.sprite_tab
        left = ttk.Frame(root, padding=6); left.pack(side="left", fill="y")
        ttk.Label(left, text="Level Sprite Set", font=("",11,"bold")).pack(anchor="w")
        self.level_var=tk.StringVar()
        self.level_cb=ttk.Combobox(left,textvariable=self.level_var,state="readonly",width=26)
        self.level_cb.pack(fill="x",pady=(0,4))
        self.level_cb.bind("<<ComboboxSelected>>",self._on_level_select)

        self.level_tag_var=tk.StringVar(value="LEVEL: —")
        self.level_tag_label=tk.Label(left,textvariable=self.level_tag_var,anchor="w",relief="groove",padx=7,pady=4,font=("",10,"bold"))
        self.level_tag_label.pack(fill="x",pady=(0,7))

        ttk.Label(left, text="Sprites 0-255 (Software + VIC-II)", font=("",11,"bold")).pack(anchor="w")
        self.sprite_list = tk.Listbox(left, width=28, exportselection=False)
        self.sprite_list.pack(fill="y", expand=True)
        self.sprite_list.bind("<<ListboxSelect>>", self._on_sprite_select)
        b = ttk.Frame(left); b.pack(fill="x", pady=4)
        ttk.Button(b, text="+ Sprite", command=self.add_sprite).pack(side="left", fill="x", expand=True)
        ttk.Button(b, text="- Sprite", command=self.delete_sprite).pack(side="left", fill="x", expand=True)
        ttk.Button(left,text="Import Sky Strike VIC Sprite(s)...",command=self.import_skystrike_vic_sprites).pack(fill="x",pady=(2,6))

        center = ttk.Frame(root, padding=6); center.pack(side="left", fill="both", expand=True)
        bar = ttk.Frame(center); bar.pack(fill="x")
        ttk.Label(bar, text="Pixel Editor", font=("",11,"bold")).pack(side="left")
        ttk.Label(bar, text="Zoom").pack(side="right")
        self.zoom_var = tk.IntVar(value=24)
        ttk.Spinbox(bar, from_=8, to=64, increment=2, textvariable=self.zoom_var,
                    width=5, command=self._draw_sprite).pack(side="right", padx=4)

        holder = ttk.Frame(center); holder.pack(fill="both", expand=True)
        self.sprite_canvas = tk.Canvas(holder, bg="#222", highlightthickness=0)
        self.sprite_canvas.grid(row=0, column=0, sticky="nsew")
        sv = ttk.Scrollbar(holder, orient="vertical", command=self.sprite_canvas.yview)
        sh = ttk.Scrollbar(holder, orient="horizontal", command=self.sprite_canvas.xview)
        sv.grid(row=0,column=1,sticky="ns"); sh.grid(row=1,column=0,sticky="ew")
        holder.rowconfigure(0,weight=1); holder.columnconfigure(0,weight=1)
        self.sprite_canvas.configure(yscrollcommand=sv.set, xscrollcommand=sh.set)
        self.sprite_canvas.bind("<Button-1>", lambda e:self._paint_sprite(e,self.current_tool_value))
        self.sprite_canvas.bind("<B1-Motion>", lambda e:self._paint_sprite(e,self.current_tool_value))
        self.sprite_canvas.bind("<Button-3>", lambda e:self._paint_sprite(e,0))
        self.sprite_canvas.bind("<B3-Motion>", lambda e:self._paint_sprite(e,0))
        self.sprite_canvas.bind("<MouseWheel>",self._sprite_canvas_zoom_wheel)
        self.sprite_canvas.bind("<Button-4>",lambda e:self._sprite_canvas_zoom_wheel(e,1))
        self.sprite_canvas.bind("<Button-5>",lambda e:self._sprite_canvas_zoom_wheel(e,-1))

        self.paint_box = ttk.LabelFrame(center, text="Paint Value")
        self.paint_box.pack(fill="x", pady=(5,0))

        frames = ttk.LabelFrame(center, text="Animation Frames")
        frames.pack(fill="x", pady=(5,0))
        self.frame_list = tk.Listbox(frames, height=5, exportselection=False)
        self.frame_list.pack(side="left", fill="x", expand=True, padx=4, pady=4)
        self.frame_list.bind("<<ListboxSelect>>", self._on_frame_select)
        fb = ttk.Frame(frames); fb.pack(side="right", padx=4)
        self.animation_play_button = ttk.Button(fb, text="Play", command=self.toggle_animation_preview)
        self.animation_play_button.pack(fill="x", pady=(0,3))
        for label, cmd in [
            ("Previous", lambda:self._step_frame(-1)),
            ("Next", lambda:self._step_frame(1)),
            ("Add", self.add_frame),
            ("Duplicate", self.duplicate_frame),
            ("Delete", self.delete_frame),
        ]:
            ttk.Button(fb, text=label, command=cmd).pack(fill="x")

        right = ttk.Frame(root, padding=6); right.pack(side="right", fill="y")
        p = ttk.LabelFrame(right, text="Sprite Properties", padding=6); p.pack(fill="x")
        self.s_name=tk.StringVar(); self.s_mode=tk.StringVar(value="hires")
        self.s_width=tk.IntVar(value=8); self.s_height=tk.IntVar(value=8)
        self.s_storage=tk.StringVar(value="auto"); self.s_bank=tk.IntVar(value=0)
        self.s_renderer=tk.StringVar(value="software")
        self.s_auto_animate=tk.BooleanVar(value=True); self.s_loop=tk.BooleanVar(value=True)
        rows=[
            ("Name",ttk.Entry(p,textvariable=self.s_name,width=22)),
            ("Renderer",ttk.Combobox(p,textvariable=self.s_renderer,state="readonly",values=["software","vic"],width=18)),
            ("Mode",ttk.Combobox(p,textvariable=self.s_mode,state="readonly",values=["hires","multicolor"],width=18)),
            ("Width",ttk.Spinbox(p,from_=4,to=128,increment=4,textvariable=self.s_width,width=8)),
            ("Height",ttk.Spinbox(p,from_=4,to=128,increment=1,textvariable=self.s_height,width=8)),
            ("Storage",ttk.Combobox(p,textvariable=self.s_storage,state="readonly",values=["auto","standard_ram","expanded_memory"],width=18)),
            ("Bank",ttk.Spinbox(p,from_=0,to=255,textvariable=self.s_bank,width=8)),
        ]
        for r,(lab,w) in enumerate(rows):
            ttk.Label(p,text=lab).grid(row=r,column=0,sticky="w",pady=2)
            w.grid(row=r,column=1,sticky="ew",pady=2)
        self.s_renderer_cb=rows[1][1]; self.s_mode_cb = rows[2][1]; self.s_width_widget=rows[3][1]; self.s_height_widget=rows[4][1]
        anim_opts=ttk.Frame(p); anim_opts.grid(row=len(rows),column=0,columnspan=2,sticky="w",pady=(4,0))
        ttk.Checkbutton(anim_opts,text="Auto Animate",variable=self.s_auto_animate).pack(side="left")
        ttk.Checkbutton(anim_opts,text="Loop",variable=self.s_loop).pack(side="left",padx=(10,0))
        self.s_renderer_cb.bind("<<ComboboxSelected>>",self._sprite_renderer_changed)
        ttk.Button(p,text="Apply Sprite Properties",command=self.apply_sprite_props).grid(
            row=len(rows)+1,column=0,columnspan=2,sticky="ew",pady=(5,0))

        c = ttk.LabelFrame(right, text="C64 Colors", padding=6); c.pack(fill="x", pady=(6,0))
        self.s_hires=tk.IntVar(value=1); self.s_mc1=tk.IntVar(value=5)
        self.s_mc2=tk.IntVar(value=6); self.s_local=tk.IntVar(value=1)
        self.color_cbs=[]
        for r,(lab,var) in enumerate([("Hires",self.s_hires),("MC1",self.s_mc1),("MC2",self.s_mc2),("Local",self.s_local)]):
            ttk.Label(c,text=lab).grid(row=r,column=0,sticky="w")
            cb=ttk.Combobox(c,state="readonly",
                            values=[f"{i}: {n}" for i,(n,_) in enumerate(C64_PALETTE)],width=18)
            cb.grid(row=r,column=1,pady=2); cb.current(var.get())
            cb.bind("<<ComboboxSelected>>",lambda e,v=var,cbox=cb:(v.set(cbox.current()),self._sprite_colors_changed()))
            self.color_cbs.append(cb)

        f = ttk.LabelFrame(right, text="Current Frame", padding=6); f.pack(fill="x", pady=(6,0))
        self.f_name=tk.StringVar(); self.f_duration=tk.IntVar(value=6)
        ttk.Label(f,text="Name").grid(row=0,column=0,sticky="w")
        ttk.Entry(f,textvariable=self.f_name,width=20).grid(row=0,column=1)
        ttk.Label(f,text="Duration").grid(row=1,column=0,sticky="w")
        ttk.Spinbox(f,from_=1,to=255,textvariable=self.f_duration,width=8).grid(row=1,column=1,sticky="e")
        self.f_name.trace_add("write",lambda *_:self._frame_live_changed())
        self.f_duration.trace_add("write",lambda *_:self._frame_live_changed())

        self.sprite_info=tk.StringVar()
        ttk.Label(right,textvariable=self.sprite_info,justify="left").pack(anchor="w",pady=8)

    def _build_object_tab(self):
        root=self.object_tab
        left=ttk.Frame(root,padding=6); left.pack(side="left",fill="y")
        ttk.Label(left,text="Game Objects",font=("",11,"bold")).pack(anchor="w")
        self.object_list=tk.Listbox(left,width=30,exportselection=False)
        self.object_list.pack(fill="y",expand=True)
        self.object_list.bind("<<ListboxSelect>>",self._on_object_select)
        b=ttk.Frame(left); b.pack(fill="x",pady=4)
        ttk.Button(b,text="+ Object",command=self.add_object).pack(side="left",fill="x",expand=True)
        ttk.Button(b,text="- Object",command=self.delete_object).pack(side="left",fill="x",expand=True)

        right=ttk.Frame(root,padding=10); right.pack(fill="both",expand=True)
        box=ttk.LabelFrame(right,text="Object Properties",padding=10); box.pack(anchor="nw",fill="x")
        self.o_name=tk.StringVar(); self.o_sprite=tk.IntVar(value=0)
        self.o_x=tk.IntVar(value=80); self.o_y=tk.IntVar(value=80)
        self.o_scene=tk.StringVar(value="Scene 1"); self.o_room=tk.IntVar(value=0); self.o_active=tk.BooleanVar(value=True)
        ttk.Label(box,text="Name").grid(row=0,column=0,sticky="w")
        ttk.Entry(box,textvariable=self.o_name,width=28).grid(row=0,column=1)
        ttk.Label(box,text="Sprite ID").grid(row=1,column=0,sticky="w")
        ttk.Spinbox(box,from_=0,to=255,textvariable=self.o_sprite,width=10).grid(row=1,column=1,sticky="w")
        ttk.Label(box,text="Start X").grid(row=2,column=0,sticky="w")
        ttk.Spinbox(box,from_=0,to=319,textvariable=self.o_x,width=10).grid(row=2,column=1,sticky="w")
        ttk.Label(box,text="Start Y").grid(row=3,column=0,sticky="w")
        ttk.Spinbox(box,from_=0,to=199,textvariable=self.o_y,width=10).grid(row=3,column=1,sticky="w")
        ttk.Label(box,text="Level").grid(row=4,column=0,sticky="w")
        self.o_scene_cb=ttk.Combobox(box,textvariable=self.o_scene,state="readonly",width=24)
        self.o_scene_cb.grid(row=4,column=1)
        self.o_scene_cb.bind("<<ComboboxSelected>>",lambda e:(self._refresh_object_room_choices(),self._refresh_paths()))
        ttk.Label(box,text="Room").grid(row=5,column=0,sticky="w")
        self.o_room_cb=ttk.Combobox(box,state="readonly",width=24)
        self.o_room_cb.grid(row=5,column=1)
        ttk.Checkbutton(box,text="Active at start",variable=self.o_active).grid(row=6,column=0,columnspan=2,sticky="w")
        self.o_path=tk.StringVar(value="")
        self.o_path_enabled=tk.BooleanVar(value=False)
        ttk.Label(box,text="Follow Path").grid(row=7,column=0,sticky="w")
        self.o_path_cb=ttk.Combobox(box,textvariable=self.o_path,state="readonly",width=24)
        self.o_path_cb.grid(row=7,column=1,sticky="w")
        ttk.Checkbutton(box,text="Path enabled at start",variable=self.o_path_enabled).grid(row=8,column=0,columnspan=2,sticky="w")

        propbox=ttk.LabelFrame(box,text="Custom Byte Properties (P0-P7)",padding=6)
        propbox.grid(row=9,column=0,columnspan=2,sticky="ew",pady=(8,0))
        self.o_props=[tk.IntVar(value=0) for _ in range(8)]
        for i,v in enumerate(self.o_props):
            ttk.Label(propbox,text=f"P{i}").grid(row=i//4,column=(i%4)*2,sticky="e",padx=(3,1))
            ttk.Spinbox(propbox,from_=0,to=255,textvariable=v,width=5).grid(row=i//4,column=(i%4)*2+1,sticky="w",padx=(0,6))

        ttk.Button(box,text="Apply Object Properties",command=self.apply_object_props).grid(row=10,column=0,columnspan=2,sticky="ew",pady=(8,0))
        ttk.Label(right,text="Objects are runtime instances. Multiple objects may share one software sprite resource.",
                  wraplength=650,justify="left").pack(anchor="nw",pady=12)

    def _build_logic_tab(self):
        root=self.logic_tab
        left=ttk.Frame(root,padding=6); left.pack(side="left",fill="y")
        ttk.Label(left,text="Object",font=("",11,"bold")).pack(anchor="w")
        self.logic_object_cb=ttk.Combobox(left,state="readonly",width=28)
        self.logic_object_cb.pack(fill="x")
        self.logic_object_cb.bind("<<ComboboxSelected>>",self._logic_object_changed)
        ttk.Label(left,text="Visual Events",font=("",11,"bold")).pack(anchor="w",pady=(8,2))
        self.event_list=tk.Listbox(left,width=46,exportselection=False)
        self.event_list.pack(fill="y",expand=True)
        self.event_list.bind("<<ListboxSelect>>",self._on_event_select)
        b=ttk.Frame(left); b.pack(fill="x",pady=4)
        ttk.Button(b,text="+ Event",command=self.add_event).pack(side="left",fill="x",expand=True)
        ttk.Button(b,text="- Event",command=self.delete_event).pack(side="left",fill="x",expand=True)

        center=ttk.Frame(root,padding=8); center.pack(side="left",fill="both",expand=True)
        template=ttk.LabelFrame(center,text="Reusable Behavior",padding=6); template.pack(fill="x")
        self.behavior_var=tk.StringVar(value=list(BEHAVIOR_TEMPLATES)[0])
        ttk.Combobox(template,textvariable=self.behavior_var,state="readonly",
                     values=list(BEHAVIOR_TEMPLATES),width=30).pack(side="left")
        ttk.Button(template,text="Attach Behavior",command=self.attach_behavior).pack(side="left",padx=6)
        ttk.Label(template,text="Adds editable visual event blocks.").pack(side="left")

        editor=ttk.LabelFrame(center,text="Selected Visual Event Block",padding=10)
        editor.pack(fill="x",pady=(8,0))
        self.e_event=tk.StringVar(value=EVENT_TYPES[0]); self.e_event_a=tk.StringVar(); self.e_event_b=tk.StringVar()
        self.e_cond=tk.StringVar(value="None"); self.e_cond_a=tk.StringVar(); self.e_cond_b=tk.StringVar()
        self.e_action=tk.StringVar(value=ACTION_TYPES[0]); self.e_action_a=tk.StringVar(); self.e_action_b=tk.StringVar()

        ttk.Label(editor,text="WHEN",font=("",10,"bold")).grid(row=0,column=0,sticky="w")
        self.e_event_cb=ttk.Combobox(editor,textvariable=self.e_event,state="readonly",values=EVENT_TYPES,width=28)
        self.e_event_cb.grid(row=0,column=1)
        self.e_event_a_cb=ttk.Combobox(editor,textvariable=self.e_event_a,width=18)
        self.e_event_a_cb.grid(row=0,column=2,padx=4)
        self.e_event_b_cb=ttk.Combobox(editor,textvariable=self.e_event_b,width=18)
        self.e_event_b_cb.grid(row=0,column=3,padx=4)

        ttk.Label(editor,text="IF",font=("",10,"bold")).grid(row=1,column=0,sticky="w",pady=(6,0))
        self.e_cond_cb=ttk.Combobox(editor,textvariable=self.e_cond,state="readonly",values=CONDITION_TYPES,width=28)
        self.e_cond_cb.grid(row=1,column=1,pady=(6,0))
        self.e_cond_a_cb=ttk.Combobox(editor,textvariable=self.e_cond_a,width=18)
        self.e_cond_a_cb.grid(row=1,column=2,padx=4,pady=(6,0))
        self.e_cond_b_cb=ttk.Combobox(editor,textvariable=self.e_cond_b,width=18)
        self.e_cond_b_cb.grid(row=1,column=3,padx=4,pady=(6,0))

        ttk.Label(editor,text="DOs",font=("",10,"bold")).grid(row=2,column=0,sticky="nw",pady=(8,0))
        self.do_list=tk.Listbox(editor,height=5,exportselection=False)
        self.do_list.grid(row=2,column=1,columnspan=3,sticky="ew",pady=(8,0))
        self.do_list.bind("<<ListboxSelect>>",self._on_do_select)

        do_buttons=ttk.Frame(editor)
        do_buttons.grid(row=3,column=1,columnspan=3,sticky="ew",pady=(3,0))
        ttk.Button(do_buttons,text="+ Add DO",command=self.add_do).pack(side="left")
        ttk.Button(do_buttons,text="- Delete DO",command=self.delete_do).pack(side="left",padx=(4,0))
        ttk.Button(do_buttons,text="Move Up",command=lambda:self.move_do(-1)).pack(side="left",padx=(12,0))
        ttk.Button(do_buttons,text="Move Down",command=lambda:self.move_do(1)).pack(side="left",padx=(4,0))

        ttk.Label(editor,text="Edit DO",font=("",10,"bold")).grid(row=4,column=0,sticky="w",pady=(7,0))
        self.e_action_cb=ttk.Combobox(editor,textvariable=self.e_action,state="readonly",values=ACTION_TYPES,width=28)
        self.e_action_cb.grid(row=4,column=1,pady=(7,0))
        self.e_action_a_cb=ttk.Combobox(editor,textvariable=self.e_action_a,width=18)
        self.e_action_a_cb.grid(row=4,column=2,padx=4,pady=(7,0))
        self.e_action_b_cb=ttk.Combobox(editor,textvariable=self.e_action_b,width=18)
        self.e_action_b_cb.grid(row=4,column=3,padx=4,pady=(7,0))

        self.e_cond_cb.bind("<<ComboboxSelected>>",lambda e:self._update_logic_arg_choices())
        self.e_action_cb.bind("<<ComboboxSelected>>",lambda e:self._update_logic_arg_choices())
        self.e_event_cb.bind("<<ComboboxSelected>>",lambda e:self._update_logic_arg_choices())
        ttk.Button(editor,text="Apply Block / DO",command=self.apply_event).grid(row=5,column=0,columnspan=4,sticky="ew",pady=(10,0))

        props=ttk.LabelFrame(center,text="Built-in Object Properties",padding=8)
        props.pack(fill="x",pady=(10,0))
        prop_text=(
            "SELF = the exact object/instance currently running this logic.\n"
            "OTHER = the exact object/instance involved in the current collision.\n\n"
            "X: horizontal position (0-319)    Y: vertical position (0-199)\n"
            "Active: 0/1    Room: room ID    Sprite: sprite ID (read-only)    Frame: animation frame\n\n"
            "These are inherent object properties. You do NOT create variables named X or Y."
        )
        ttk.Label(props,text=prop_text,justify="left",wraplength=860).pack(anchor="w")

        txt=(
            "Examples:\n"
            "WHEN Every Frame -> IF Self Property Greater Than | X | 280 -> DO Move X | -2\n"
            "WHEN Collision With Sprite | 1 -> DO Set Other Property | Active | 0\n"
            "WHEN Collision With Sprite | 1 -> DO Add To Variable | score | 10\n\n"
            "Self always means this particular runtime instance. Other is valid during collision events.\n"
            "Normal project variables such as score/lives are separate from built-in object properties."
        )
        ttk.Label(center,text=txt,justify="left",wraplength=860).pack(anchor="nw",pady=12)

    def _build_scene_tab(self):
        root=self.scene_tab
        left=ttk.Frame(root,padding=6); left.pack(side="left",fill="y")
        ttk.Label(left,text="Levels",font=("",11,"bold")).pack(anchor="w")
        self.scene_list=tk.Listbox(left,width=30,exportselection=False)
        self.scene_list.pack(fill="y",expand=True)
        self.scene_list.bind("<<ListboxSelect>>",self._on_scene_select)
        b=ttk.Frame(left); b.pack(fill="x",pady=4)
        ttk.Button(b,text="+ Scene",command=self.add_scene).pack(side="left",fill="x",expand=True)
        ttk.Button(b,text="- Scene",command=self.delete_scene).pack(side="left",fill="x",expand=True)

        right=ttk.Frame(root,padding=10); right.pack(fill="both",expand=True)
        self.scene_name=tk.StringVar(); self.scene_mode=tk.StringVar(value="hires")
        box=ttk.LabelFrame(right,text="Level Properties",padding=10); box.pack(fill="x",anchor="nw")
        ttk.Label(box,text="Name").grid(row=0,column=0,sticky="w")
        ttk.Entry(box,textvariable=self.scene_name,width=28).grid(row=0,column=1)
        ttk.Label(box,text="Display mode").grid(row=1,column=0,sticky="w")
        self.scene_mode_cb=ttk.Combobox(box,textvariable=self.scene_mode,state="readonly",values=["hires","multicolor"],width=22)
        self.scene_mode_cb.grid(row=1,column=1)
        ttk.Label(box,text="Background color").grid(row=2,column=0,sticky="w")
        self.scene_color_cb=ttk.Combobox(box,state="readonly",values=[f"{i}: {n}" for i,(n,_) in enumerate(C64_PALETTE)],width=22)
        self.scene_color_cb.grid(row=2,column=1); self.scene_color_cb.current(0)
        self.scene_mc_cbs=[]
        for r,lab in enumerate(["MC1","MC2","Local"],start=3):
            ttk.Label(box,text=lab).grid(row=r,column=0,sticky="w")
            cb=ttk.Combobox(box,state="readonly",values=[f"{i}: {n}" for i,(n,_) in enumerate(C64_PALETTE)],width=22)
            cb.grid(row=r,column=1); self.scene_mc_cbs.append(cb)
        self.scene_mc_cbs[0].current(5); self.scene_mc_cbs[1].current(6); self.scene_mc_cbs[2].current(7)
        ttk.Label(box,text="Multicolor runtime maps pixel values 1/2/3 to this scene palette.",wraplength=340,justify="left").grid(row=6,column=0,columnspan=2,sticky="w",pady=(6,0))
        ttk.Button(box,text="Apply Scene Properties",command=self.apply_scene).grid(row=7,column=0,columnspan=2,sticky="ew",pady=(8,0))

    def _build_room_tab(self):
        host=self.room_tab

        # The Room editor is intentionally larger than many laptop displays.
        # Put the complete workspace inside a two-axis scroller instead of
        # letting the right-side tools disappear below/off the window.
        self.room_ui_scroll_canvas=tk.Canvas(host,highlightthickness=0)
        room_vscroll=ttk.Scrollbar(host,orient="vertical",command=self.room_ui_scroll_canvas.yview)
        room_hscroll=ttk.Scrollbar(host,orient="horizontal",command=self.room_ui_scroll_canvas.xview)
        self.room_ui_scroll_canvas.configure(yscrollcommand=room_vscroll.set,xscrollcommand=room_hscroll.set)
        self.room_ui_scroll_canvas.grid(row=0,column=0,sticky="nsew")
        room_vscroll.grid(row=0,column=1,sticky="ns")
        room_hscroll.grid(row=1,column=0,sticky="ew")
        host.rowconfigure(0,weight=1); host.columnconfigure(0,weight=1)

        root=ttk.Frame(self.room_ui_scroll_canvas)
        self.room_ui_scroll_window=self.room_ui_scroll_canvas.create_window((0,0),window=root,anchor="nw")
        root.bind("<Configure>",lambda e:self.room_ui_scroll_canvas.configure(scrollregion=self.room_ui_scroll_canvas.bbox("all")))

        def _room_wheel(event):
            if event.delta:
                self.room_ui_scroll_canvas.yview_scroll(int(-1*(event.delta/120)),"units")
            return "break"
        self.room_ui_scroll_canvas.bind("<Enter>",lambda e:self.room_ui_scroll_canvas.bind_all("<MouseWheel>",_room_wheel))
        self.room_ui_scroll_canvas.bind("<Leave>",lambda e:self.room_ui_scroll_canvas.unbind_all("<MouseWheel>"))

        left=ttk.Frame(root,padding=6); left.pack(side="left",fill="y")
        ttk.Label(left,text="Rooms",font=("",11,"bold")).pack(anchor="w")
        self.room_list=tk.Listbox(left,width=34,exportselection=False)
        self.room_list.pack(fill="y",expand=True)
        self.room_list.bind("<<ListboxSelect>>",self._on_room_select)
        b=ttk.Frame(left); b.pack(fill="x",pady=4)
        ttk.Button(b,text="+ Room",command=self.add_room).pack(side="left",fill="x",expand=True)
        ttk.Button(b,text="- Room",command=self.delete_room).pack(side="left",fill="x",expand=True)

        center=ttk.Frame(root,padding=6); center.pack(side="left",fill="both",expand=True)
        h=ttk.Frame(center); h.pack(fill="x")
        ttk.Label(h,text="C64 Room Layout - 320 x 200",font=("",11,"bold")).pack(side="left")
        ttk.Button(h,text="Test Play",command=self.test_play_current_room).pack(side="left",padx=(10,0))
        self.room_status_var=tk.StringVar(value="")
        ttk.Label(h,textvariable=self.room_status_var).pack(side="right")
        tools=ttk.Frame(center); tools.pack(fill="x",pady=(4,0))
        self.room_tool_var=tk.StringVar(value="object")
        ttk.Radiobutton(tools,text="Object Tool",variable=self.room_tool_var,value="object").pack(side="left")
        ttk.Radiobutton(tools,text="Place Object",variable=self.room_tool_var,value="place_object").pack(side="left",padx=(8,0))
        ttk.Radiobutton(tools,text="Player Start",variable=self.room_tool_var,value="player_start").pack(side="left",padx=(8,0))
        ttk.Radiobutton(tools,text="Tile Paint",variable=self.room_tool_var,value="tile").pack(side="left",padx=(8,0))
        ttk.Label(tools,text="   Click/drag uses selected tool").pack(side="left")

        self.room_canvas=tk.Canvas(center,width=640,height=400,bg="#000000",highlightthickness=1)
        self.room_canvas.pack(fill="both",expand=True,pady=(5,0))
        self.room_canvas.bind("<Configure>",lambda e:self.after_idle(self._draw_room))
        self.room_canvas.bind("<Button-1>",self._room_canvas_press)
        self.room_canvas.bind("<B1-Motion>",self._room_canvas_drag)
        self.room_canvas.bind("<ButtonRelease-1>",self._room_canvas_release)
        self.room_canvas.bind("<Button-3>",self._room_canvas_right)
        self.room_canvas.bind("<B3-Motion>",self._room_canvas_right)

        right=ttk.Frame(root,padding=8); right.pack(side="right",fill="y")
        props=ttk.LabelFrame(right,text="Room Properties",padding=8); props.pack(fill="x")
        self.room_name_var=tk.StringVar(); self.room_level_var=tk.StringVar(); self.room_id_var=tk.IntVar(value=0)
        ttk.Label(props,text="Room ID").grid(row=0,column=0,sticky="w",pady=2)
        ttk.Label(props,textvariable=self.room_id_var,width=8).grid(row=0,column=1,sticky="w")
        ttk.Label(props,text="Name").grid(row=1,column=0,sticky="w",pady=2)
        ttk.Entry(props,textvariable=self.room_name_var,width=24).grid(row=1,column=1,sticky="ew")
        ttk.Label(props,text="Level").grid(row=2,column=0,sticky="w",pady=2)
        self.room_level_cb=ttk.Combobox(props,textvariable=self.room_level_var,state="readonly",width=22)
        self.room_level_cb.grid(row=2,column=1,sticky="ew")
        ttk.Button(props,text="Apply Room Properties",command=self.apply_room).grid(row=3,column=0,columnspan=2,sticky="ew",pady=(6,0))
        ttk.Button(props,text="Set as Start Room",command=self.set_start_room).grid(row=4,column=0,columnspan=2,sticky="ew",pady=(4,0))

        inherited=ttk.LabelFrame(right,text="Inherited Level Display",padding=8); inherited.pack(fill="x",pady=(8,0))
        self.room_inherited_var=tk.StringVar()
        ttk.Label(inherited,textvariable=self.room_inherited_var,justify="left",wraplength=300).pack(anchor="w")

        spritebox=ttk.LabelFrame(right,text="Room Object Placement",padding=6); spritebox.pack(fill="x",pady=(8,0))
        self.room_object_place_info=tk.StringVar(value="No objects in this level.")
        ttk.Label(spritebox,textvariable=self.room_object_place_info,wraplength=285,justify="left").pack(anchor="w")
        self.room_object_place_list=tk.Listbox(spritebox,height=6,width=34,exportselection=False)
        self.room_object_place_list.pack(fill="x",pady=(4,0))
        self.room_object_place_list.bind("<<ListboxSelect>>",self._on_room_place_object_select)
        ttk.Button(spritebox,text="Place Selected at Room Center",command=self.place_selected_object_center).pack(fill="x",pady=(4,0))
        ttk.Label(spritebox,text="Selecting an object automatically chooses Place Object. Click the room to place it. Object 0 moves; Objects 1-255 create another instance.",
                  wraplength=285,justify="left").pack(anchor="w",pady=(4,0))
        ttk.Button(spritebox,text="Clear Player Start",command=self.clear_room_player_start).pack(fill="x",pady=(4,0))

        instbox=ttk.LabelFrame(right,text="Selected Instance Card / Object Values",padding=6); instbox.pack(fill="x",pady=(8,0))
        self.room_instance_z_var=tk.IntVar(value=0)
        zrow=ttk.Frame(instbox); zrow.pack(fill="x")
        ttk.Label(zrow,text="Z / stack order").pack(side="left")
        ttk.Spinbox(zrow,from_=0,to=255,textvariable=self.room_instance_z_var,width=6).pack(side="right")
        self.room_instance_prop_vars=[tk.IntVar(value=0) for _ in range(8)]
        pvgrid=ttk.Frame(instbox); pvgrid.pack(fill="x",pady=(4,0))
        for _pi,_pv in enumerate(self.room_instance_prop_vars):
            ttk.Label(pvgrid,text=f"P{_pi}").grid(row=_pi//4,column=(_pi%4)*2,sticky="w",padx=(1,1),pady=1)
            ttk.Spinbox(pvgrid,from_=0,to=255,textvariable=_pv,width=4).grid(row=_pi//4,column=(_pi%4)*2+1,sticky="w",padx=(0,5),pady=1)
        ttk.Button(instbox,text="Apply Instance Values",command=self.apply_room_instance_values).pack(fill="x",pady=(4,0))
        ttk.Label(instbox,text="Each placed instance can override P0-P7 and stack order. Useful for card rank, suit, color, pile, face-up state, links, inventory slots, etc.",wraplength=285,justify="left").pack(anchor="w",pady=(4,0))

        tiles=ttk.LabelFrame(right,text="Room Tileset",padding=6); tiles.pack(fill="x",pady=(8,0))
        ttk.Button(tiles,text="Import Sky Strike Tileset...",command=self.import_skystrike_tileset).pack(fill="x")
        ttk.Button(tiles,text="Import Image Tile Sheet...",command=self.import_image_tilesheet).pack(fill="x",pady=(3,0))
        ttk.Button(tiles,text="Remove Level Tileset",command=self.remove_level_tileset).pack(fill="x",pady=(3,0))
        self.room_tileset_info=tk.StringVar(value="No tileset loaded for this level.")
        ttk.Label(tiles,textvariable=self.room_tileset_info,wraplength=285,justify="left").pack(anchor="w",pady=(5,3))
        self.room_tile_list=tk.Listbox(tiles,height=7,width=34,exportselection=False)
        self.room_tile_list.pack(fill="x")
        self.room_tile_list.bind("<<ListboxSelect>>",self._on_room_tile_select)
        collision_row=ttk.Frame(tiles); collision_row.pack(fill="x",pady=(5,0))
        ttk.Label(collision_row,text="Selected tile collision").pack(side="left")
        self.room_tile_collision_var=tk.StringVar(value="None")
        self.room_tile_collision_cb=ttk.Combobox(
            collision_row,textvariable=self.room_tile_collision_var,state="readonly",
            values=["None","Solid","Hazard"],width=10)
        self.room_tile_collision_cb.pack(side="right")
        self.room_tile_collision_cb.bind("<<ComboboxSelected>>",self._apply_room_tile_collision)

        propbox=ttk.LabelFrame(tiles,text="Custom Tile Values (0-255)",padding=4)
        propbox.pack(fill="x",pady=(5,0))
        self.room_tile_prop_vars=[tk.IntVar(value=0) for _ in range(4)]
        for _pi,_pv in enumerate(self.room_tile_prop_vars):
            ttk.Label(propbox,text=f"P{_pi}").grid(row=_pi//2,column=(_pi%2)*2,sticky="w",padx=(2,1),pady=1)
            ttk.Spinbox(propbox,from_=0,to=255,textvariable=_pv,width=5).grid(
                row=_pi//2,column=(_pi%2)*2+1,sticky="w",padx=(0,6),pady=1)
        ttk.Button(propbox,text="Apply Tile Values",command=self._apply_room_tile_properties).grid(
            row=2,column=0,columnspan=4,sticky="ew",pady=(4,0))

        objs=ttk.LabelFrame(right,text="Objects in Room",padding=6); objs.pack(fill="both",expand=True,pady=(8,0))
        self.room_object_list=tk.Listbox(objs,width=34,exportselection=False)
        self.room_object_list.pack(fill="both",expand=True)
        self.room_object_list.bind("<<ListboxSelect>>",self._room_object_list_select)
        ttk.Button(objs,text="Delete Selected Instance",command=self.delete_room_instance).pack(fill="x",pady=(4,0))
        ttk.Label(objs,text="Drag placed instances directly in the room canvas. Object 0 remains unique.",
                  wraplength=285,justify="left").pack(anchor="w",pady=(6,0))

    def _build_tile_tab(self):
        """Integrated C64 tile pixel editor adapted from Sky Strike VER 11.2."""
        root=self.tile_tab
        left=ttk.Frame(root,padding=8); left.pack(side="left",fill="y")
        ttk.Label(left,text="Level Tileset",font=("",11,"bold")).pack(anchor="w")
        self.tile_level_var=tk.StringVar()
        self.tile_level_cb=ttk.Combobox(left,textvariable=self.tile_level_var,state="readonly",width=27)
        self.tile_level_cb.pack(fill="x",pady=(0,5))
        self.tile_level_cb.bind("<<ComboboxSelected>>",self._tile_level_changed)
        self.tile_editor_list=tk.Listbox(left,width=31,height=24,exportselection=False)
        self.tile_editor_list.pack(fill="both",expand=True)
        self.tile_editor_list.bind("<<ListboxSelect>>",self._tile_editor_select)
        buttons=ttk.Frame(left); buttons.pack(fill="x",pady=4)
        ttk.Button(buttons,text="+ Tile",command=self._tile_add).pack(side="left",fill="x",expand=True)
        ttk.Button(buttons,text="Duplicate",command=self._tile_duplicate).pack(side="left",fill="x",expand=True)
        ttk.Button(left,text="Delete Tile",command=self._tile_delete).pack(fill="x",pady=2)
        ttk.Button(left,text="Import Image Tile Sheet...",command=self.import_image_tilesheet).pack(fill="x",pady=(8,2))
        ttk.Button(left,text="Import Sky Strike Tileset...",command=self.import_skystrike_tileset).pack(fill="x",pady=2)

        center=ttk.Frame(root,padding=8); center.pack(side="left",fill="both",expand=True)
        bar=ttk.Frame(center); bar.pack(fill="x")
        ttk.Label(bar,text="C64 Tile Pixel Editor",font=("",11,"bold")).pack(side="left")
        self.tile_zoom_var=tk.IntVar(value=16)
        ttk.Label(bar,text="Zoom").pack(side="right")
        ttk.Spinbox(bar,from_=4,to=40,increment=2,textvariable=self.tile_zoom_var,width=5,command=self._draw_tile_editor).pack(side="right",padx=4)
        holder=ttk.Frame(center); holder.pack(fill="both",expand=True,pady=(5,0))
        self.tile_editor_canvas=tk.Canvas(holder,bg="#222222",highlightthickness=0)
        self.tile_editor_canvas.grid(row=0,column=0,sticky="nsew")
        tv=ttk.Scrollbar(holder,orient="vertical",command=self.tile_editor_canvas.yview)
        th=ttk.Scrollbar(holder,orient="horizontal",command=self.tile_editor_canvas.xview)
        tv.grid(row=0,column=1,sticky="ns"); th.grid(row=1,column=0,sticky="ew")
        holder.rowconfigure(0,weight=1); holder.columnconfigure(0,weight=1)
        self.tile_editor_canvas.configure(yscrollcommand=tv.set,xscrollcommand=th.set)
        self.tile_editor_canvas.bind("<Button-1>",self._tile_editor_paint)
        self.tile_editor_canvas.bind("<B1-Motion>",self._tile_editor_paint)
        self.tile_editor_canvas.bind("<Button-3>",lambda e:self._tile_editor_paint(e,0))
        self.tile_editor_canvas.bind("<B3-Motion>",lambda e:self._tile_editor_paint(e,0))

        right=ttk.Frame(root,padding=8); right.pack(side="right",fill="y")
        props=ttk.LabelFrame(right,text="Tileset Properties",padding=7); props.pack(fill="x")
        self.tile_edit_mode=tk.StringVar(value="multicolor")
        self.tile_edit_width=tk.IntVar(value=8); self.tile_edit_height=tk.IntVar(value=8)
        for row,(label,widget) in enumerate([
            ("Mode",ttk.Combobox(props,textvariable=self.tile_edit_mode,state="readonly",values=["hires","multicolor"],width=15)),
            ("Tile width",ttk.Spinbox(props,from_=8,to=64,increment=8,textvariable=self.tile_edit_width,width=8)),
            ("Tile height",ttk.Spinbox(props,from_=4,to=64,increment=4,textvariable=self.tile_edit_height,width=8)),
        ]):
            ttk.Label(props,text=label).grid(row=row,column=0,sticky="w",pady=2); widget.grid(row=row,column=1,sticky="ew",pady=2)
        ttk.Button(props,text="Create / Resize Tileset",command=self._tile_apply_geometry).grid(row=3,column=0,columnspan=2,sticky="ew",pady=(6,0))

        paint=ttk.LabelFrame(right,text="Paint Value",padding=7); paint.pack(fill="x",pady=(7,0))
        self.tile_brush=tk.IntVar(value=3)
        self.tile_brush_buttons=[]
        for value in range(4):
            rb=ttk.Radiobutton(paint,text=str(value),variable=self.tile_brush,value=value,command=self._draw_tile_editor)
            rb.pack(anchor="w"); self.tile_brush_buttons.append(rb)
        colors=ttk.LabelFrame(right,text="Tile Local Color",padding=7); colors.pack(fill="x",pady=(7,0))
        self.tile_local_color=tk.IntVar(value=7)
        self.tile_local_cb=ttk.Combobox(colors,state="readonly",values=[f"{i}: {n}" for i,(n,_) in enumerate(C64_PALETTE)],width=19)
        self.tile_local_cb.pack(fill="x"); self.tile_local_cb.current(7)
        self.tile_local_cb.bind("<<ComboboxSelected>>",lambda e:(self.tile_local_color.set(self.tile_local_cb.current()),self._tile_set_local_color()))
        ttk.Button(right,text="Clear Tile",command=self._tile_clear).pack(fill="x",pady=(9,2))
        ttk.Button(right,text="Load PNG Into Tile...",command=self._tile_load_png).pack(fill="x",pady=2)
        ttk.Button(right,text="Save Tile PNG...",command=self._tile_save_png).pack(fill="x",pady=2)
        self.tile_editor_info=tk.StringVar(value="Select a level and create or import a tileset.")
        ttk.Label(right,textvariable=self.tile_editor_info,justify="left",wraplength=250).pack(anchor="w",pady=(9,0))

    def _tile_level_changed(self,event=None):
        level=self.tile_level_var.get()
        if level:
            self.current_level=level
            rooms=self._rooms_for_level(level)
            if rooms:self.current_room_id=rooms[0].room_id
        self.current_tile_id=0
        self._refresh_tile_editor()

    def _tile_editor_tileset(self):
        return self.project.tilesets.get(self.tile_level_var.get() or self.current_level)

    def _refresh_tile_editor(self):
        if not hasattr(self,"tile_editor_list"):return
        levels=[s.name for s in self.project.scenes]
        self.tile_level_cb["values"]=levels
        if self.current_level in levels:self.tile_level_var.set(self.current_level)
        ts=self._tile_editor_tileset()
        self.tile_editor_list.delete(0,"end")
        if not ts:
            self.tile_editor_info.set("No tileset for this level. Use Create / Resize Tileset or import one.")
            self.tile_editor_canvas.delete("all"); return
        self.tile_edit_mode.set(getattr(ts,"mode","multicolor")); self.tile_edit_width.set(int(getattr(ts,"tile_width",8))); self.tile_edit_height.set(int(getattr(ts,"tile_height",8)))
        while len(ts.tile_local_colors)<len(ts.tiles):ts.tile_local_colors.append(7)
        while len(ts.tile_collision)<len(ts.tiles):ts.tile_collision.append(0)
        while len(ts.tile_properties)<len(ts.tiles):ts.tile_properties.append([0,0,0,0])
        for i in range(len(ts.tiles)):
            tag={1:" SOLID",2:" HAZARD"}.get(ts.tile_collision[i],"")
            self.tile_editor_list.insert("end",f"{i:03d}: Tile {i}{tag}")
        if ts.tiles:
            self.current_tile_id=max(0,min(self.current_tile_id,len(ts.tiles)-1))
            self.tile_editor_list.selection_set(self.current_tile_id); self.tile_editor_list.see(self.current_tile_id)
            self.tile_local_color.set(int(ts.tile_local_colors[self.current_tile_id])&15); self.tile_local_cb.current(self.tile_local_color.get())
        self._update_tile_brush_labels(); self._draw_tile_editor()

    def _tile_editor_select(self,event=None):
        sel=self.tile_editor_list.curselection()
        if not sel:return
        self.current_tile_id=int(sel[0]); ts=self._tile_editor_tileset()
        if ts and self.current_tile_id<len(ts.tile_local_colors):
            self.tile_local_color.set(int(ts.tile_local_colors[self.current_tile_id])&15); self.tile_local_cb.current(self.tile_local_color.get())
        self._draw_tile_editor()

    def _update_tile_brush_labels(self):
        if not hasattr(self,"tile_brush_buttons"):return
        scene=next((s for s in self.project.scenes if s.name==(self.tile_level_var.get() or self.current_level)),None)
        mode=self.tile_edit_mode.get()
        local=self.tile_local_color.get()
        indices=[scene.background_color if scene else 0,scene.mc1 if scene else 5,scene.mc2 if scene else 6,local]
        labels=["Background","MC1","MC2","Local"]
        for i,b in enumerate(self.tile_brush_buttons):
            if mode=="hires" and i>1:b.configure(state="disabled")
            else:b.configure(state="normal")
            idx=indices[i]&15; b.configure(text=f"{i}: {labels[i]} - {C64_PALETTE[idx][0]}")

    def _draw_tile_editor(self):
        if not hasattr(self,"tile_editor_canvas"):return
        c=self.tile_editor_canvas;c.delete("all");ts=self._tile_editor_tileset()
        if not ts or not (0<=self.current_tile_id<len(ts.tiles)):return
        tile=ts.tiles[self.current_tile_id]; z=max(2,int(self.tile_zoom_var.get())); mode=getattr(ts,"mode","multicolor")
        logical_w=max(1,int(ts.tile_width)//(2 if mode=="multicolor" else 1)); h=max(1,int(ts.tile_height))
        scene=next((s for s in self.project.scenes if s.name==(self.tile_level_var.get() or self.current_level)),None)
        local=(ts.tile_local_colors[self.current_tile_id] if self.current_tile_id<len(ts.tile_local_colors) else 7)&15
        inds=[scene.background_color if scene else 0,scene.mc1 if scene else 5,scene.mc2 if scene else 6,local]
        for y in range(h):
            row=tile[y] if y<len(tile) else []
            for x in range(logical_w):
                v=(int(row[x]) if x<len(row) else 0)&(1 if mode=="hires" else 3)
                c.create_rectangle(x*z,y*z,(x+1)*z,(y+1)*z,fill=C64_PALETTE[inds[v]&15][1],outline="#555555")
        c.configure(scrollregion=(0,0,logical_w*z,h*z))
        self.tile_editor_info.set(f"Tile {self.current_tile_id} - {ts.tile_width}x{ts.tile_height} {mode}\nLeft-drag paints; right-drag erases. Changes are stored directly in the project tileset.")

    def _tile_editor_paint(self,event,value=None):
        ts=self._tile_editor_tileset()
        if not ts or not (0<=self.current_tile_id<len(ts.tiles)):return
        z=max(2,int(self.tile_zoom_var.get())); x=int(self.tile_editor_canvas.canvasx(event.x)//z); y=int(self.tile_editor_canvas.canvasy(event.y)//z)
        mode=getattr(ts,"mode","multicolor"); lw=max(1,int(ts.tile_width)//(2 if mode=="multicolor" else 1)); h=int(ts.tile_height)
        if not (0<=x<lw and 0<=y<h):return
        v=self.tile_brush.get() if value is None else value
        if mode=="hires":v=1 if v else 0
        ts.tiles[self.current_tile_id][y][x]=int(v); self.dirty=True; self._draw_tile_editor(); self.after_idle(self._draw_room)

    def _tile_apply_geometry(self):
        level=self.tile_level_var.get() or self.current_level
        if not level:return
        mode=self.tile_edit_mode.get(); w=int(self.tile_edit_width.get()); h=int(self.tile_edit_height.get())
        if w<8 or w%8 or h<4 or h%4:return messagebox.showerror("Tile dimensions","Tile width must be divisible by 8 and height divisible by 4.")
        old=self.project.tilesets.get(level)
        if old and (old.tile_width!=w or old.tile_height!=h or old.mode!=mode):
            if not messagebox.askyesno("Resize Tileset","Resize every tile? Pixels outside the new bounds will be discarded, and room placement spacing will change."):return
        if not old:
            old=TileSet(name=f"{level} Tiles",source_format="Next64 integrated tile editor",mode=mode,tile_width=w,tile_height=h)
            self.project.tilesets[level]=old
        old.mode=mode; old.tile_width=w; old.tile_height=h
        lw=w//(2 if mode=="multicolor" else 1)
        if not old.tiles:old.tiles=[[[0 for _ in range(lw)] for _ in range(h)]]
        else:
            for i,tile in enumerate(old.tiles):
                new=[[0 for _ in range(lw)] for _ in range(h)]
                for y in range(min(h,len(tile))):
                    for x in range(min(lw,len(tile[y]))):new[y][x]=(1 if mode=="hires" and tile[y][x] else min(3,int(tile[y][x])))
                old.tiles[i]=new
        while len(old.tile_local_colors)<len(old.tiles):old.tile_local_colors.append(self.tile_local_color.get())
        while len(old.tile_collision)<len(old.tiles):old.tile_collision.append(0)
        while len(old.tile_properties)<len(old.tiles):old.tile_properties.append([0,0,0,0])
        self.dirty=True; self._refresh_all(); self.status.set(f"Tileset ready: {level}, {w}x{h} {mode}.")

    def _tile_add(self):
        ts=self._tile_editor_tileset()
        if not ts:
            self._tile_apply_geometry(); ts=self._tile_editor_tileset()
            if not ts:return
        if len(ts.tiles)>=256:return messagebox.showwarning("Tile limit","This tileset already has 256 tiles.")
        lw=ts.tile_width//(2 if ts.mode=="multicolor" else 1)
        ts.tiles.append([[0 for _ in range(lw)] for _ in range(ts.tile_height)]); ts.tile_local_colors.append(self.tile_local_color.get()); ts.tile_collision.append(0); ts.tile_properties.append([0,0,0,0])
        self.current_tile_id=len(ts.tiles)-1; self.dirty=True; self._refresh_all()

    def _tile_duplicate(self):
        ts=self._tile_editor_tileset()
        if not ts or not (0<=self.current_tile_id<len(ts.tiles)):return
        if len(ts.tiles)>=256:return messagebox.showwarning("Tile limit","This tileset already has 256 tiles.")
        import copy
        i=self.current_tile_id; ts.tiles.append(copy.deepcopy(ts.tiles[i])); ts.tile_local_colors.append(ts.tile_local_colors[i]); ts.tile_collision.append(ts.tile_collision[i]); ts.tile_properties.append(list(ts.tile_properties[i]))
        self.current_tile_id=len(ts.tiles)-1; self.dirty=True; self._refresh_all()

    def _tile_delete(self):
        ts=self._tile_editor_tileset()
        if not ts or not (0<=self.current_tile_id<len(ts.tiles)):return
        if len(ts.tiles)==1:return messagebox.showwarning("Tile required","A tileset must retain at least one tile.")
        i=self.current_tile_id
        if not messagebox.askyesno("Delete Tile",f"Delete tile {i}? Higher tile IDs will shift down and room maps will be updated."):return
        for room in self._rooms_for_level(self.tile_level_var.get() or self.current_level):
            for row in room.tile_map:
                for x,v in enumerate(row):
                    if v==i:row[x]=-1
                    elif v>i:row[x]=v-1
        for seq in (ts.tiles,ts.tile_local_colors,ts.tile_collision,ts.tile_properties):del seq[i]
        self.current_tile_id=min(i,len(ts.tiles)-1); self.dirty=True; self._refresh_all()

    def _tile_clear(self):
        ts=self._tile_editor_tileset()
        if not ts or not (0<=self.current_tile_id<len(ts.tiles)):return
        if not messagebox.askyesno("Clear Tile",f"Clear all pixels in tile {self.current_tile_id}?"):return
        lw=ts.tile_width//(2 if ts.mode=="multicolor" else 1); ts.tiles[self.current_tile_id]=[[0 for _ in range(lw)] for _ in range(ts.tile_height)]
        self.dirty=True; self._draw_tile_editor(); self.after_idle(self._draw_room)

    def _tile_set_local_color(self):
        ts=self._tile_editor_tileset()
        if ts and 0<=self.current_tile_id<len(ts.tiles):
            while len(ts.tile_local_colors)<len(ts.tiles):ts.tile_local_colors.append(7)
            ts.tile_local_colors[self.current_tile_id]=self.tile_local_color.get()&15; self.dirty=True
        self._update_tile_brush_labels(); self._draw_tile_editor(); self.after_idle(self._draw_room)

    def _tile_image(self):
        if Image is None:return None
        ts=self._tile_editor_tileset()
        if not ts or not (0<=self.current_tile_id<len(ts.tiles)):return None
        scene=next((s for s in self.project.scenes if s.name==(self.tile_level_var.get() or self.current_level)),None); local=ts.tile_local_colors[self.current_tile_id]&15
        inds=[scene.background_color if scene else 0,scene.mc1 if scene else 5,scene.mc2 if scene else 6,local]
        img=Image.new("RGB",(ts.tile_width,ts.tile_height),C64_PALETTE[inds[0]][1]); px=img.load(); mult=2 if ts.mode=="multicolor" else 1
        for y,row in enumerate(ts.tiles[self.current_tile_id]):
            for x,v in enumerate(row):
                color=C64_PALETTE[inds[int(v)&(3 if mult==2 else 1)]][1]
                for q in range(mult):px[x*mult+q,y]=color
        return img

    def _tile_save_png(self):
        if Image is None:return messagebox.showerror("Pillow required","Install Pillow to save PNG tiles.")
        img=self._tile_image()
        if img is None:return
        path=filedialog.asksaveasfilename(title="Save Tile PNG",defaultextension=".png",initialfile=f"tile_{self.current_tile_id:02x}.png",filetypes=[("PNG image","*.png")])
        if path:img.save(path); self.status.set(f"Saved tile PNG: {path}")

    def _tile_load_png(self):
        if Image is None:return messagebox.showerror("Pillow required","Install Pillow to load PNG tiles.")
        ts=self._tile_editor_tileset()
        if not ts or not (0<=self.current_tile_id<len(ts.tiles)):return
        path=filedialog.askopenfilename(title="Load PNG Into Tile",filetypes=[("PNG image","*.png"),("All files","*.*")])
        if not path:return
        img=Image.open(path).convert("RGB").resize((ts.tile_width,ts.tile_height),Image.Resampling.NEAREST)
        scene=next((s for s in self.project.scenes if s.name==(self.tile_level_var.get() or self.current_level)),None); local=ts.tile_local_colors[self.current_tile_id]&15
        inds=[scene.background_color if scene else 0,scene.mc1 if scene else 5,scene.mc2 if scene else 6,local]; rgbs=[tuple(int(C64_PALETTE[i][1][j:j+2],16) for j in (1,3,5)) for i in inds]
        mult=2 if ts.mode=="multicolor" else 1; lw=ts.tile_width//mult; out=[]
        for y in range(ts.tile_height):
            row=[]
            for x in range(lw):
                rgb=img.getpixel((x*mult,y)); allowed=range(4) if mult==2 else range(2)
                row.append(min(allowed,key=lambda k:sum((rgb[n]-rgbs[k][n])**2 for n in range(3))))
            out.append(row)
        ts.tiles[self.current_tile_id]=out; self.dirty=True; self._draw_tile_editor(); self.after_idle(self._draw_room)

    def _build_inventory_tab(self):
        root=self.inventory_tab
        left=ttk.Frame(root,padding=8); left.pack(side="left",fill="y")
        ttk.Label(left,text="Item Definitions",font=("",11,"bold")).pack(anchor="w")
        self.inventory_item_list=tk.Listbox(left,width=34,height=24,exportselection=False)
        self.inventory_item_list.pack(fill="both",expand=True)
        self.inventory_item_list.bind("<<ListboxSelect>>",self._inventory_item_selected)
        row=ttk.Frame(left); row.pack(fill="x",pady=4)
        ttk.Button(row,text="+ Item",command=self._inventory_add_item).pack(side="left",fill="x",expand=True)
        ttk.Button(row,text="- Item",command=self._inventory_delete_item).pack(side="left",fill="x",expand=True)

        center=ttk.Frame(root,padding=8); center.pack(side="left",fill="both",expand=True)
        general=ttk.LabelFrame(center,text="Inventory Storage",padding=8); general.pack(fill="x")
        self.inventory_enabled=tk.BooleanVar(value=False); self.inventory_slots=tk.IntVar(value=8)
        ttk.Checkbutton(general,text="Enable persistent inventory",variable=self.inventory_enabled).grid(row=0,column=0,columnspan=2,sticky="w")
        ttk.Label(general,text="Slot count (1-32)").grid(row=1,column=0,sticky="w")
        ttk.Spinbox(general,from_=1,to=32,textvariable=self.inventory_slots,width=7).grid(row=1,column=1,sticky="w")
        ttk.Button(general,text="Apply Inventory Size",command=self._inventory_apply_config).grid(row=2,column=0,columnspan=2,sticky="ew",pady=(6,0))

        item=ttk.LabelFrame(center,text="Selected Item",padding=8); item.pack(fill="x",pady=(8,0))
        self.inventory_item_id=tk.IntVar(value=1); self.inventory_item_name=tk.StringVar(value="Item 1")
        self.inventory_item_tile=tk.IntVar(value=0); self.inventory_item_stack=tk.IntVar(value=99)
        for r,(lab,var,to) in enumerate([("Item ID",self.inventory_item_id,254),("Name",self.inventory_item_name,None),("Icon tile ID",self.inventory_item_tile,255),("Maximum stack",self.inventory_item_stack,255)]):
            ttk.Label(item,text=lab).grid(row=r,column=0,sticky="w",pady=2)
            w=ttk.Entry(item,textvariable=var,width=24) if to is None else ttk.Spinbox(item,from_=1 if r in (0,3) else 0,to=to,textvariable=var,width=9)
            w.grid(row=r,column=1,sticky="ew",pady=2)
        ttk.Button(item,text="Apply Item Definition",command=self._inventory_apply_item).grid(row=4,column=0,columnspan=2,sticky="ew",pady=(6,0))

        slots=ttk.LabelFrame(center,text="Initial Slot Contents",padding=8); slots.pack(fill="both",expand=True,pady=(8,0))
        self.inventory_slot_list=tk.Listbox(slots,height=10,exportselection=False); self.inventory_slot_list.pack(side="left",fill="both",expand=True)
        self.inventory_slot_list.bind("<<ListboxSelect>>",self._inventory_slot_selected)
        sc=ttk.Frame(slots); sc.pack(side="right",fill="y",padx=(8,0))
        self.inventory_slot_item=tk.IntVar(value=255); self.inventory_slot_qty=tk.IntVar(value=0)
        ttk.Label(sc,text="Item ID (255=empty)").pack(anchor="w"); ttk.Spinbox(sc,from_=0,to=255,textvariable=self.inventory_slot_item,width=9).pack(anchor="w")
        ttk.Label(sc,text="Quantity").pack(anchor="w",pady=(5,0)); ttk.Spinbox(sc,from_=0,to=255,textvariable=self.inventory_slot_qty,width=9).pack(anchor="w")
        ttk.Button(sc,text="Apply Slot",command=self._inventory_apply_slot).pack(fill="x",pady=(7,2))
        ttk.Button(sc,text="Clear Slot",command=self._inventory_clear_slot).pack(fill="x")

        right=ttk.Frame(root,padding=8); right.pack(side="right",fill="y")
        display=ttk.LabelFrame(right,text="Tile Grid Display",padding=8); display.pack(fill="x")
        self.inventory_display_room=tk.IntVar(value=0); self.inventory_display_x=tk.IntVar(value=1); self.inventory_display_y=tk.IntVar(value=1)
        self.inventory_display_cols=tk.IntVar(value=4); self.inventory_empty_tile=tk.IntVar(value=0); self.inventory_selected=tk.IntVar(value=0)
        for r,(lab,var,hi) in enumerate([("Inventory room ID",self.inventory_display_room,255),("Start tile X",self.inventory_display_x,39),("Start tile Y",self.inventory_display_y,24),("Columns",self.inventory_display_cols,32),("Empty-slot tile",self.inventory_empty_tile,255),("Initially selected slot",self.inventory_selected,31)]):
            ttk.Label(display,text=lab).grid(row=r,column=0,sticky="w",pady=2)
            ttk.Spinbox(display,from_=0 if lab!="Columns" else 1,to=hi,textvariable=var,width=8).grid(row=r,column=1,sticky="e",pady=2)
        ttk.Button(display,text="Apply Display Settings",command=self._inventory_apply_config).grid(row=6,column=0,columnspan=2,sticky="ew",pady=(7,0))
        ttk.Label(right,text=("Item tile IDs are drawn into the configured room grid by the Render Inventory Tiles action.\n\n"
                              "Inventory arrays persist when rooms change. Quantities stack up to each item's maximum.\n\n"
                              "Visual Logic supplies add, remove, use, move, select, render, contains, slot, and quantity operations."),wraplength=280,justify="left").pack(anchor="w",pady=(10,0))

    def _inventory_normalize(self):
        inv=self.project.inventory
        inv.slot_count=max(1,min(32,int(inv.slot_count)))
        inv.initial_items=(list(inv.initial_items)+[255]*inv.slot_count)[:inv.slot_count]
        inv.initial_quantities=(list(inv.initial_quantities)+[0]*inv.slot_count)[:inv.slot_count]
        maxima={int(x.item_id)&255:max(1,min(255,int(x.max_stack))) for x in inv.items}
        for i in range(inv.slot_count):
            inv.initial_items[i]=int(inv.initial_items[i])&255
            inv.initial_quantities[i]=int(inv.initial_quantities[i])&255
            if inv.initial_items[i]==255:inv.initial_quantities[i]=0
            elif inv.initial_items[i] in maxima:inv.initial_quantities[i]=max(1,min(maxima[inv.initial_items[i]],inv.initial_quantities[i]))
        inv.selected_slot=max(0,min(inv.slot_count-1,int(inv.selected_slot)))
        inv.display_columns=max(1,min(inv.slot_count,int(inv.display_columns)))

    def _refresh_inventory(self):
        if not hasattr(self,"inventory_item_list"):return
        self._inventory_normalize(); inv=self.project.inventory
        self.inventory_enabled.set(bool(inv.enabled)); self.inventory_slots.set(inv.slot_count)
        self.inventory_display_room.set(inv.display_room_id); self.inventory_display_x.set(inv.display_x); self.inventory_display_y.set(inv.display_y)
        self.inventory_display_cols.set(inv.display_columns); self.inventory_empty_tile.set(inv.empty_tile_id); self.inventory_selected.set(inv.selected_slot)
        self.inventory_item_list.delete(0,"end")
        for item in sorted(inv.items,key=lambda x:x.item_id):self.inventory_item_list.insert("end",f"{item.item_id:03d}: {item.name}  [tile {item.tile_id}, max {item.max_stack}]")
        self.inventory_slot_list.delete(0,"end"); names={i.item_id:i.name for i in inv.items}
        for i,(iid,qty) in enumerate(zip(inv.initial_items,inv.initial_quantities)):
            label="Empty" if iid==255 else names.get(iid,f"Item {iid}")
            self.inventory_slot_list.insert("end",f"Slot {i:02d}: {label}  x{qty if iid!=255 else 0}")
        if inv.items and not self.inventory_item_list.curselection():self.inventory_item_list.selection_set(0);self._inventory_item_selected()
        if inv.slot_count and not self.inventory_slot_list.curselection():self.inventory_slot_list.selection_set(0);self._inventory_slot_selected()

    def _inventory_item_selected(self,event=None):
        sel=self.inventory_item_list.curselection(); items=sorted(self.project.inventory.items,key=lambda x:x.item_id)
        if not sel or sel[0]>=len(items):return
        item=items[sel[0]]; self.inventory_item_id.set(item.item_id);self.inventory_item_name.set(item.name);self.inventory_item_tile.set(item.tile_id);self.inventory_item_stack.set(item.max_stack)

    def _inventory_add_item(self):
        used={i.item_id for i in self.project.inventory.items}; iid=next((i for i in range(1,255) if i not in used),None)
        if iid is None:return messagebox.showwarning("Item limit","All item IDs 1-254 are used.")
        self.project.inventory.items.append(InventoryItem(item_id=iid,name=f"Item {iid}"));self.dirty=True;self._refresh_inventory()
        items=sorted(self.project.inventory.items,key=lambda x:x.item_id);idx=next(i for i,x in enumerate(items) if x.item_id==iid);self.inventory_item_list.selection_clear(0,"end");self.inventory_item_list.selection_set(idx);self._inventory_item_selected()

    def _inventory_delete_item(self):
        iid=int(self.inventory_item_id.get())&255
        item=next((x for x in self.project.inventory.items if x.item_id==iid),None)
        if not item:return
        if not messagebox.askyesno("Delete Item",f"Delete item {iid}: {item.name}? Initial slots containing it will be cleared."):return
        self.project.inventory.items.remove(item);inv=self.project.inventory
        for i,v in enumerate(inv.initial_items):
            if v==iid:inv.initial_items[i]=255;inv.initial_quantities[i]=0
        self.dirty=True;self._refresh_inventory()

    def _inventory_apply_item(self):
        iid=max(1,min(254,int(self.inventory_item_id.get())));inv=self.project.inventory
        selected=self.inventory_item_list.curselection();ordered=sorted(inv.items,key=lambda x:x.item_id)
        item=ordered[selected[0]] if selected and selected[0]<len(ordered) else None
        if item is None:item=next((x for x in inv.items if x.item_id==iid),None)
        if item is None:item=InventoryItem(item_id=iid);inv.items.append(item)
        elif item.item_id!=iid:
            if any(x is not item and x.item_id==iid for x in inv.items):return messagebox.showerror("Item ID","That item ID is already used.")
            old_id=item.item_id;item.item_id=iid
            for n,v in enumerate(inv.initial_items):
                if v==old_id:inv.initial_items[n]=iid
        item.name=self.inventory_item_name.get().strip() or f"Item {iid}";item.tile_id=max(0,min(255,int(self.inventory_item_tile.get())));item.max_stack=max(1,min(255,int(self.inventory_item_stack.get())))
        self.dirty=True;self._refresh_inventory();self.status.set(f"Inventory item {iid} updated.")

    def _inventory_slot_selected(self,event=None):
        sel=self.inventory_slot_list.curselection();inv=self.project.inventory
        if not sel or sel[0]>=inv.slot_count:return
        self.inventory_slot_item.set(inv.initial_items[sel[0]]);self.inventory_slot_qty.set(inv.initial_quantities[sel[0]])

    def _inventory_apply_slot(self):
        sel=self.inventory_slot_list.curselection();inv=self.project.inventory
        if not sel:return
        i=sel[0];iid=int(self.inventory_slot_item.get())&255;qty=int(self.inventory_slot_qty.get())&255
        if iid!=255 and not any(x.item_id==iid for x in inv.items):return messagebox.showerror("Unknown item",f"Define inventory item {iid} first.")
        inv.initial_items[i]=iid;inv.initial_quantities[i]=0 if iid==255 else max(1,qty);self.dirty=True;self._refresh_inventory();self.inventory_slot_list.selection_set(i)

    def _inventory_clear_slot(self):
        self.inventory_slot_item.set(255);self.inventory_slot_qty.set(0);self._inventory_apply_slot()

    def _inventory_apply_config(self):
        inv=self.project.inventory;old=inv.slot_count
        inv.enabled=bool(self.inventory_enabled.get());inv.slot_count=max(1,min(32,int(self.inventory_slots.get())))
        inv.display_room_id=int(self.inventory_display_room.get())&255;inv.display_x=max(0,min(39,int(self.inventory_display_x.get())));inv.display_y=max(0,min(24,int(self.inventory_display_y.get())))
        inv.display_columns=max(1,min(inv.slot_count,int(self.inventory_display_cols.get())));inv.empty_tile_id=int(self.inventory_empty_tile.get())&255;inv.selected_slot=max(0,min(inv.slot_count-1,int(self.inventory_selected.get())))
        rows=(inv.slot_count+inv.display_columns-1)//inv.display_columns
        if inv.display_x+inv.display_columns>40 or inv.display_y+rows>25:
            return messagebox.showerror("Inventory grid","The inventory tile grid must fit inside the room's 40x25 tile-map storage.")
        self._inventory_normalize();self.dirty=True;self._refresh_inventory();self.status.set(f"Inventory configured with {inv.slot_count} persistent slots.")

    def _build_variable_tab(self):
        root=self.variable_tab
        left=ttk.Frame(root,padding=6); left.pack(side="left",fill="y")
        ttk.Label(left,text="Global 8-bit Variables",font=("",11,"bold")).pack(anchor="w")
        self.var_list=tk.Listbox(left,width=32,exportselection=False)
        self.var_list.pack(fill="y",expand=True)
        self.var_list.bind("<<ListboxSelect>>",self._on_var_select)
        b=ttk.Frame(left); b.pack(fill="x",pady=4)
        ttk.Button(b,text="+ Variable",command=self.add_variable).pack(side="left",fill="x",expand=True)
        ttk.Button(b,text="- Variable",command=self.delete_variable).pack(side="left",fill="x",expand=True)

        right=ttk.Frame(root,padding=10); right.pack(fill="both",expand=True)
        box=ttk.LabelFrame(right,text="Variable Properties",padding=10); box.pack(fill="x",anchor="nw")
        self.var_name=tk.StringVar(); self.var_initial=tk.IntVar(value=0)
        ttk.Label(box,text="Name").grid(row=0,column=0,sticky="w")
        ttk.Entry(box,textvariable=self.var_name,width=28).grid(row=0,column=1)
        ttk.Label(box,text="Initial value 0-255").grid(row=1,column=0,sticky="w")
        ttk.Spinbox(box,from_=0,to=255,textvariable=self.var_initial,width=10).grid(row=1,column=1,sticky="w")
        ttk.Button(box,text="Apply Variable",command=self.apply_variable).grid(row=2,column=0,columnspan=2,sticky="ew",pady=(8,0))

    def _build_path_tab(self):
        root=self.path_tab
        left=ttk.Frame(root,padding=6); left.pack(side="left",fill="y")
        ttk.Label(left,text="Named Object Paths",font=("",11,"bold")).pack(anchor="w")
        self.path_list=tk.Listbox(left,width=32,exportselection=False)
        self.path_list.pack(fill="y",expand=True)
        self.path_list.bind("<<ListboxSelect>>",self._on_path_select)
        b=ttk.Frame(left); b.pack(fill="x",pady=4)
        ttk.Button(b,text="+ Path",command=self.add_path).pack(side="left",fill="x",expand=True)
        ttk.Button(b,text="- Path",command=self.delete_path).pack(side="left",fill="x",expand=True)

        center=ttk.Frame(root,padding=10); center.pack(side="left",fill="both",expand=True)
        box=ttk.LabelFrame(center,text="Path Properties",padding=10); box.pack(fill="x")
        self.path_name=tk.StringVar(); self.path_level=tk.StringVar(); self.path_mode=tk.StringVar(value="loop"); self.path_speed=tk.IntVar(value=1)
        ttk.Label(box,text="Name").grid(row=0,column=0,sticky="w")
        ttk.Entry(box,textvariable=self.path_name,width=30).grid(row=0,column=1,sticky="w")
        ttk.Label(box,text="Level").grid(row=1,column=0,sticky="w")
        self.path_level_cb=ttk.Combobox(box,textvariable=self.path_level,state="readonly",width=27)
        self.path_level_cb.grid(row=1,column=1,sticky="w")
        ttk.Label(box,text="Mode").grid(row=2,column=0,sticky="w")
        ttk.Combobox(box,textvariable=self.path_mode,state="readonly",values=["loop","patrol","once"],width=14).grid(row=2,column=1,sticky="w")
        ttk.Label(box,text="Speed (pixels/frame)").grid(row=3,column=0,sticky="w")
        ttk.Spinbox(box,from_=1,to=16,textvariable=self.path_speed,width=8).grid(row=3,column=1,sticky="w")
        ttk.Button(box,text="Apply Path Properties",command=self.apply_path).grid(row=4,column=0,columnspan=2,sticky="ew",pady=(8,0))

        pts=ttk.LabelFrame(center,text="Waypoints (absolute C64 coordinates)",padding=10); pts.pack(fill="both",expand=True,pady=(8,0))
        self.path_point_list=tk.Listbox(pts,height=12,exportselection=False)
        self.path_point_list.pack(side="left",fill="both",expand=True)
        self.path_point_list.bind("<<ListboxSelect>>",self._on_path_point_select)
        controls=ttk.Frame(pts); controls.pack(side="right",fill="y",padx=(8,0))
        self.path_point_x=tk.IntVar(value=40); self.path_point_y=tk.IntVar(value=40)
        ttk.Label(controls,text="X 0-319").pack(anchor="w")
        ttk.Spinbox(controls,from_=0,to=319,textvariable=self.path_point_x,width=8).pack(anchor="w")
        ttk.Label(controls,text="Y 0-199").pack(anchor="w",pady=(5,0))
        ttk.Spinbox(controls,from_=0,to=199,textvariable=self.path_point_y,width=8).pack(anchor="w")
        ttk.Button(controls,text="Add Point",command=self.add_path_point).pack(fill="x",pady=(8,2))
        ttk.Button(controls,text="Update Point",command=self.update_path_point).pack(fill="x",pady=2)
        ttk.Button(controls,text="Delete Point",command=self.delete_path_point).pack(fill="x",pady=2)
        ttk.Button(controls,text="Move Up",command=lambda:self.move_path_point(-1)).pack(fill="x",pady=(8,2))
        ttk.Button(controls,text="Move Down",command=lambda:self.move_path_point(1)).pack(fill="x",pady=2)
        ttk.Label(center,text="Assign a named path in the Objects tab. Loop repeats from the first waypoint; Patrol reverses at each end; Once stops at the last waypoint.",wraplength=800,justify="left").pack(anchor="w",pady=(8,0))

    def _build_build_tab(self):
        root=self.build_tab
        box=ttk.LabelFrame(root,text="Kick Assembler Build",padding=12); box.pack(fill="x",padx=10,pady=10)
        self.kickass_var=tk.StringVar()
        ttk.Label(box,text="KickAss.jar").grid(row=0,column=0,sticky="w")
        ttk.Entry(box,textvariable=self.kickass_var,width=70).grid(row=0,column=1,sticky="ew",padx=5)
        ttk.Button(box,text="Browse...",command=self.browse_kickass).grid(row=0,column=2)
        ttk.Button(box,text="Generate ASM Folder",command=self.generate_asm_dialog).grid(row=1,column=1,sticky="ew",pady=(8,0))
        ttk.Button(box,text="Build PRG",command=self.build_prg_dialog).grid(row=2,column=1,sticky="ew",pady=(4,0))
        ttk.Button(box,text="Test Play Current Room",command=self.test_play_current_room).grid(row=3,column=1,sticky="ew",pady=(8,0))
        box.columnconfigure(1,weight=1)
        ttk.Label(root,text=(
            "The editor generates readable Kick Assembler source, object state, variables, visual logic, sprite data, "
            "and the integrated double-buffered hires/multicolor software-sprite runtime."
        ),justify="left",wraplength=900).pack(anchor="nw",padx=16,pady=8)
        self.build_log=tk.Text(root,height=20)
        self.build_log.pack(fill="both",expand=True,padx=10,pady=10)

    # ---------------- model helpers ----------------
    def _sprite_key(self, level, sid):
        return f"{level}:{int(sid)}"

    def _level_sprites(self, level=None):
        level = level or self.current_level
        return {s.sprite_id:s for s in self.project.sprites.values() if getattr(s,"level_id",self.project.start_scene)==level}

    def _ensure_sprite(self,sid,level=None):
        level=level or self.current_level or self.project.start_scene
        key=self._sprite_key(level,sid)
        if key not in self.project.sprites:
            masters=self._level_sprites(level)
            if 0 in masters and sid != 0:
                m=masters[0]
                mode=m.mode
                colors=dict(m.colors)
                width=8
                height=8 if mode=="hires" else 4
            else:
                scene=next((x for x in self.project.scenes if x.name==level),None)
                # New level master defaults requested for Next64:
                # software renderer + multicolor, blue/white shared colors.
                mode="multicolor"
                colors={"hires":1,
                        "mc1":(scene.mc1 if scene else 6),
                        "mc2":(scene.mc2 if scene else 1),
                        "local":(scene.local if scene else 7)}
                width=8
                height=4
                if scene:
                    scene.display_mode="multicolor"
                    scene.mc1=colors["mc1"]; scene.mc2=colors["mc2"]
            s=Sprite(sprite_id=sid,level_id=level,name=f"Sprite {sid}",mode=mode,width=width,height=height,
                     colors=colors,renderer="software")
            s.frames=[Frame(name="Frame 1",pixels=blank_pixels(mode,width,height))]
            self.project.sprites[key]=s

    def _ensure_object(self,oid):
        if oid not in self.project.objects:
            room=self.current_room()
            level=room.level_id if room else (self.current_level or self.project.start_scene)
            rid=room.room_id if room else self.project.start_room_id
            self.project.objects[oid]=GameObject(object_id=oid,name=f"Object {oid}",sprite_id=0,
                sprite_level=level,scene=level,room_id=rid)

    def current_sprite(self):
        return self._level_sprites().get(self.current_sprite_id)

    def current_frame(self):
        s=self.current_sprite()
        if not s or not s.frames:return None
        self.current_frame_index=max(0,min(self.current_frame_index,len(s.frames)-1))
        return s.frames[self.current_frame_index]

    def current_object(self): return self.project.objects.get(self.current_object_id)

    def _on_level_select(self,e=None):
        self.stop_animation_preview()
        level=self.level_var.get()
        if not level:return
        self.current_level=level
        ids=sorted(self._level_sprites(level))
        self.current_sprite_id=ids[0] if ids else None
        self.current_frame_index=0
        self._refresh_sprite_list()
        self._refresh_sprite_fields()
        self.status.set(f"Sprite set: {level}")

    def _rooms_for_level(self,level=None):
        level=level or self.current_level
        return [r for r in self.project.rooms if r.level_id==level]

    def current_room(self):
        for r in self.project.rooms:
            if r.room_id==self.current_room_id:
                return r
        return None

    def _room_by_id(self,room_id):
        for r in self.project.rooms:
            if r.room_id==room_id:
                return r
        return None

    def _refresh_object_room_choices(self):
        if not hasattr(self,"o_room_cb"): return
        level=self.o_scene.get()
        rooms=self._rooms_for_level(level)
        vals=[f"{r.room_id:03d}: {r.name}" for r in rooms]
        self.o_room_cb["values"]=vals
        current=self.current_object()
        preferred=current.room_id if current and current.scene==level else (rooms[0].room_id if rooms else None)
        if preferred is not None:
            for i,r in enumerate(rooms):
                if r.room_id==preferred:
                    self.o_room_cb.current(i)
                    return
        self.o_room_cb.set("")

    @staticmethod
    def _asm_number(token):
        token=token.strip()
        try:
            if token.startswith("$"): return int(token[1:],16)
            if token.lower().startswith("0x"): return int(token,16)
            if token.startswith("%"): return int(token[1:],2)
            return int(token,10)
        except Exception:
            return None

    def import_skystrike_vic_sprites(self):
        level_id=self.current_level
        if not level_id:
            return messagebox.showwarning("No level","Create or select a level first.")
        path=filedialog.askopenfilename(
            title="Import Sky Strike VIC-II Sprite ASM",
            filetypes=[("Sky Strike / Kick Assembler","*.asm"),("Text files","*.txt"),("All files","*.*")]
        )
        if not path:return
        try:
            groups,constants=self._parse_skystrike_vic_sprite_groups(path)
        except Exception as e:
            return messagebox.showerror("VIC sprite import failed",str(e))
        if not groups:
            return messagebox.showerror("VIC sprite import failed","No 63-byte VIC-II sprite data blocks were found.")

        level=next((s for s in self.project.scenes if s.name==level_id),None)
        master=self._level_sprites(level_id).get(0)
        mode=(master.mode if master else (level.display_mode if level else "multicolor"))
        if mode not in ("hires","multicolor"):mode="multicolor"

        # Use Sky Strike constants when present, otherwise keep the current
        # Next64 level's established shared palette.
        def cget(*names,default):
            for n in names:
                if n in constants:return constants[n]&15
            return default
        mc1=cget("SPRITE_MC1","LEVEL_MC1","MC1",default=(master.colors.get("mc1",5) if master else (level.mc1 if level else 5)))
        mc2=cget("SPRITE_MC2","LEVEL_MC2","MC2",default=(master.colors.get("mc2",6) if master else (level.mc2 if level else 6)))
        local_default=cget("SPRITE_COLOR","SPRITE_LOCAL","LEVEL_LOCAL","LOCAL",default=(level.local if level else 1))
        hires_default=cget("SPRITE_HIRES","HIRES_COLOR",default=local_default)

        used=set(self._level_sprites(level_id))
        free=[i for i in range(256) if i not in used]
        if len(free)<len(groups):
            return messagebox.showerror("Sprite IDs","Not enough free sprite IDs in this level.")

        created=[]
        for gi,(name,frames63) in enumerate(groups):
            sid=free[gi]
            frames=[]
            for fi,data in enumerate(frames63):
                pixels=[]
                for y in range(21):
                    rowbytes=data[y*3:y*3+3]
                    row=[]
                    if mode=="hires":
                        for b in rowbytes:
                            row.extend(1 if (b&(1<<(7-bit))) else 0 for bit in range(8))
                    else:
                        for b in rowbytes:
                            row.extend([(b>>6)&3,(b>>4)&3,(b>>2)&3,b&3])
                    pixels.append(row)
                frames.append(Frame(
                    name=(f"{name} {fi+1}" if len(frames63)>1 else name),
                    duration=6,pixels=pixels
                ))
            s=Sprite(
                sprite_id=sid,level_id=level_id,name=name or f"VIC Sprite {sid}",
                mode=mode,width=(24 if mode=="hires" else 12),height=21,
                colors={"hires":hires_default,"mc1":mc1,"mc2":mc2,"local":local_default},
                renderer="vic",source_format="Sky Strike VIC-II 63-byte sprite ASM",
                storage="standard_ram",frames=frames
            )
            self.project.sprites[self._sprite_key(level_id,sid)]=s
            created.append(sid)

        # Preserve the existing level-wide sprite color/mode convention.
        new_master=self._level_sprites(level_id).get(0)
        if new_master:
            if 0 in created:
                if level:
                    level.display_mode=new_master.mode
                    level.mc1=new_master.colors["mc1"];level.mc2=new_master.colors["mc2"]
                    level.local=new_master.colors["local"]
            else:
                for sid in created:
                    s=self._level_sprites(level_id)[sid]
                    s.mode=new_master.mode
                    s.width=24 if s.mode=="hires" else 12
                    s.colors["mc1"]=new_master.colors.get("mc1",s.colors["mc1"])
                    s.colors["mc2"]=new_master.colors.get("mc2",s.colors["mc2"])

        self.current_sprite_id=created[0]
        self.current_frame_index=0
        self.dirty=True
        self._refresh_all()
        self.status.set(f"Imported {len(created)} Sky Strike VIC-II sprite definition(s): "+", ".join(map(str,created)))

    def _parse_skystrike_vic_sprite_groups(self,path):
        raw=Path(path).read_text(encoding="utf-8",errors="replace")
        lines=[]
        constants={}
        for line in raw.splitlines():
            line=re.split(r"//|;",line,1)[0].strip()
            if not line:continue
            lines.append(line)
            m=re.search(r"\.const\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([%$]?[0-9A-Fa-fxX]+)",line,re.I)
            if m:
                n=self._asm_number(m.group(2))
                if n is not None:constants[m.group(1).upper()]=n

        labels=[]
        for i,line in enumerate(lines):
            m=re.match(r"^([A-Za-z_][A-Za-z0-9_]*):",line)
            if m:labels.append((i,m.group(1)))

        def bytes_in(a,b):
            vals=[]
            for line in lines[a:b]:
                if ".byte" not in line.lower():continue
                rhs=re.split(r"\.byte",line,flags=re.I,maxsplit=1)[1]
                for tok in rhs.split(","):
                    m=re.match(r"\s*([%$]?[0-9A-Fa-fxX]+)",tok)
                    if m:
                        n=self._asm_number(m.group(1))
                        if n is not None:vals.append(n&255)
            return vals

        groups=[]
        for pos,(start,name) in enumerate(labels):
            lname=name.lower()
            if "color" in lname or "pointer" in lname or "table" in lname:continue
            end=labels[pos+1][0] if pos+1<len(labels) else len(lines)
            vals=bytes_in(start,end)
            # A hardware sprite is exactly 63 meaningful bytes. A 64-byte
            # block may include the normal padding byte.
            frames=[]
            at=0
            while len(vals)-at>=63:
                frames.append(vals[at:at+63])
                at += 64 if len(vals)-at>=64 and ((len(vals)-at)%64==0 or vals[at+63]==0) else 63
            if frames and ("sprite" in lname or "data" in lname or len(vals) in (63,64)):
                clean=re.sub(r"[_]+"," ",name).strip()
                groups.append((clean,frames))

        if not groups:
            vals=bytes_in(0,len(lines))
            frames=[]
            at=0
            while len(vals)-at>=63:
                frames.append(vals[at:at+63])
                at += 64 if len(vals)-at>=64 and ((len(vals)-at)%64==0 or vals[at+63]==0) else 63
            # Without labels, treat each hardware block as a separate sprite;
            # users can combine frames in the editor afterward.
            groups=[(f"{Path(path).stem} {i+1}",[fr]) for i,fr in enumerate(frames)]
        return groups,constants

    def _parse_skystrike_tileset(self,path):
        raw=Path(path).read_text(encoding="utf-8",errors="replace")
        # Remove // and ; comments but keep labels/directives.
        lines=[]
        for line in raw.splitlines():
            line=re.split(r"//|;",line,1)[0].strip()
            if line: lines.append(line)

        constants={}
        for line in lines:
            m=re.search(r"\.const\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([%$]?[0-9A-Fa-fxX]+)",line,re.I)
            if m:
                n=self._asm_number(m.group(2))
                if n is not None: constants[m.group(1).upper()]=n

        labels=[]
        for idx,line in enumerate(lines):
            m=re.match(r"^([A-Za-z_][A-Za-z0-9_]*):",line)
            if m: labels.append((idx,m.group(1)))

        def bytes_between(start,end):
            vals=[]
            for line in lines[start:end]:
                if ".byte" not in line.lower(): continue
                rhs=re.split(r"\.byte",line,flags=re.I,maxsplit=1)[1]
                for tok in rhs.split(","):
                    tok=tok.strip()
                    m=re.match(r"([%$]?[0-9A-Fa-fxX]+)",tok)
                    if m:
                        n=self._asm_number(m.group(1))
                        if n is not None: vals.append(n&255)
            return vals

        # Prefer explicit tile-data/charset labels.
        candidates=[]
        for pos,(idx,name) in enumerate(labels):
            lname=name.lower()
            score=0
            if "tile" in lname: score+=4
            if "data" in lname: score+=3
            if "char" in lname or "charset" in lname: score+=2
            if "color" in lname or "map" in lname: score-=6
            if score>0:
                end=labels[pos+1][0] if pos+1<len(labels) else len(lines)
                vals=bytes_between(idx,end)
                candidates.append((score,len(vals),name,vals))
        candidates.sort(reverse=True)

        tile_count=constants.get("LEVEL_TILE_COUNT")
        tile_bytes=[]
        source_label=""
        for score,length,name,vals in candidates:
            if length>=8:
                if tile_count and length>=tile_count*8:
                    tile_bytes=vals[:tile_count*8]; source_label=name; break
                if not tile_count and length%8==0:
                    tile_bytes=vals; source_label=name; break

        # Fallback: all .byte data, taking LEVEL_TILE_COUNT * 8 when known.
        if not tile_bytes:
            all_vals=bytes_between(0,len(lines))
            if tile_count and len(all_vals)>=tile_count*8:
                tile_bytes=all_vals[:tile_count*8]
                source_label="fallback .byte stream"
            elif len(all_vals)>=8:
                tile_bytes=all_vals[:(len(all_vals)//8)*8]
                source_label="fallback .byte stream"

        if not tile_bytes or len(tile_bytes)<8:
            raise ValueError("Could not find 8-byte VIC-II character tile data in this Sky Strike ASM file.")

        if tile_count is None:
            tile_count=len(tile_bytes)//8
        tile_count=min(tile_count,len(tile_bytes)//8,256)

        tiles=[]
        for t in range(tile_count):
            rows=[]
            for y in range(8):
                b=tile_bytes[t*8+y]
                rows.append([(b>>6)&3,(b>>4)&3,(b>>2)&3,b&3])
            tiles.append(rows)

        # Optional per-tile color table: retain it as metadata, but Next64's
        # level palette remains authoritative for display.
        local_colors=[]
        for pos,(idx,name) in enumerate(labels):
            lname=name.lower()
            if "tile" in lname and "color" in lname:
                end=labels[pos+1][0] if pos+1<len(labels) else len(lines)
                vals=bytes_between(idx,end)
                if vals:
                    local_colors=[v&15 for v in vals[:tile_count]]
                    break

        return TileSet(
            name=Path(path).stem,
            source_format=f"Sky Strike VIC-II multicolor ASM ({source_label})",
            tiles=tiles,
            tile_local_colors=local_colors,
            tile_collision=[0 for _ in tiles],
            tile_properties=[[0,0,0,0] for _ in tiles],
            tile_width=8,
            tile_height=8,
            mode="multicolor"
        )

    def import_image_tilesheet(self):
        room=self.current_room()
        if not room:
            return messagebox.showwarning("No room","Create or select a room first.")
        if Image is None:
            return messagebox.showerror(
                "Pillow required",
                "Image tile-sheet import requires Pillow. Install it with: pip install pillow"
            )

        path=filedialog.askopenfilename(
            title="Import Image Tile Sheet",
            filetypes=[
                ("Image files","*.png *.bmp *.gif *.jpg *.jpeg"),
                ("PNG","*.png"),("Bitmap","*.bmp"),("All files","*.*")
            ]
        )
        if not path:return

        try:
            with Image.open(path) as probe:
                sheet_w,sheet_h=probe.size
        except Exception as e:
            return messagebox.showerror("Tile sheet import failed",f"Could not open image:\n{e}")

        tile_w=simpledialog.askinteger(
            "Tile Width",
            f"Tile sheet size: {sheet_w} x {sheet_h}\n\nEnter the width of each tile in pixels:",
            parent=self,minvalue=1,maxvalue=320,initialvalue=8
        )
        if tile_w is None:return
        tile_h=simpledialog.askinteger(
            "Tile Height",
            f"Tile sheet size: {sheet_w} x {sheet_h}\n\nEnter the height of each tile in pixels:",
            parent=self,minvalue=1,maxvalue=200,initialvalue=8
        )
        if tile_h is None:return

        if sheet_w%tile_w or sheet_h%tile_h:
            return messagebox.showerror(
                "Tile dimensions do not divide sheet",
                f"The {sheet_w}x{sheet_h} image is not evenly divisible by {tile_w}x{tile_h} tiles."
            )

        level=next((s for s in self.project.scenes if s.name==room.level_id),None)
        if level is None:
            return messagebox.showerror("Level","The room's level could not be found.")

        mode=level.display_mode
        if tile_w%8:
            return messagebox.showerror(
                "C64 tile width",
                "For Next64/C64 export, tile width must be divisible by 8 pixels "
                "(for example 8, 16, 24, or 32)."
            )

        # Convert source colors to the level's actual shared C64 palette roles.
        role_indices=[
            level.background_color & 15,
            level.mc1 & 15,
            level.mc2 & 15,
            level.local & 15,
        ]
        role_rgb=[]
        for ci in role_indices:
            hx=C64_PALETTE[ci][1].lstrip("#")
            role_rgb.append(tuple(int(hx[n:n+2],16) for n in (0,2,4)))

        def nearest_role(rgb,allowed=(0,1,2,3)):
            best=allowed[0]; bestd=None
            for role in allowed:
                pr=role_rgb[role]
                d=(rgb[0]-pr[0])**2+(rgb[1]-pr[1])**2+(rgb[2]-pr[2])**2
                if bestd is None or d<bestd:
                    bestd=d; best=role
            return best

        try:
            img=Image.open(path).convert("RGB")
            tiles=[]
            cols=sheet_w//tile_w
            rows=sheet_h//tile_h
            for gy in range(rows):
                for gx in range(cols):
                    crop=img.crop((gx*tile_w,gy*tile_h,(gx+1)*tile_w,(gy+1)*tile_h))
                    encoded=[]
                    if mode=="multicolor":
                        # C64 multicolor pixels are two physical pixels wide.
                        for y in range(tile_h):
                            outrow=[]
                            for x in range(0,tile_w,2):
                                a=crop.getpixel((x,y))
                                b=crop.getpixel((min(x+1,tile_w-1),y))
                                avg=((a[0]+b[0])//2,(a[1]+b[1])//2,(a[2]+b[2])//2)
                                outrow.append(nearest_role(avg))
                            encoded.append(outrow)
                    else:
                        # Hires room tiles use background or local/foreground.
                        for y in range(tile_h):
                            outrow=[]
                            for x in range(tile_w):
                                rgb=crop.getpixel((x,y))
                                outrow.append(3 if nearest_role(rgb,(0,3))==3 else 0)
                            encoded.append(outrow)
                    tiles.append(encoded)
            img.close()
        except Exception as e:
            return messagebox.showerror("Tile sheet import failed",str(e))

        self.project.tilesets[room.level_id]=TileSet(
            name=Path(path).stem,
            source_format=f"Image tile sheet {sheet_w}x{sheet_h}; source tile {tile_w}x{tile_h}",
            tiles=tiles,
            tile_local_colors=[],
            tile_collision=[0 for _ in tiles],
            tile_properties=[[0,0,0,0] for _ in tiles],
            tile_width=tile_w,
            tile_height=tile_h,
            mode=mode
        )
        # A different tile size changes the logical room grid; clear old map IDs.
        for r in self._rooms_for_level(room.level_id):
            r.tile_map=[[-1 for _ in range(40)] for _ in range(25)]
        self.current_tile_id=0
        self.dirty=True
        self._refresh_rooms()
        self.status.set(
            f"Imported {len(tiles)} image tiles ({tile_w}x{tile_h}) into level {room.level_id}."
        )

    def import_skystrike_tileset(self):
        room=self.current_room()
        if not room:
            return messagebox.showwarning("No room","Create or select a room first.")
        path=filedialog.askopenfilename(
            title="Import Sky Strike Tileset",
            filetypes=[("Sky Strike / Kick Assembler","*.asm"),("Text files","*.txt"),("All files","*.*")]
        )
        if not path:return
        try:
            ts=self._parse_skystrike_tileset(path)
        except Exception as e:
            return messagebox.showerror("Tileset import failed",str(e))
        self.project.tilesets[room.level_id]=ts
        self.current_tile_id=0
        self.dirty=True
        self._refresh_rooms()
        self.status.set(f"Imported {len(ts.tiles)} Sky Strike tiles into level {room.level_id}.")

    def remove_level_tileset(self):
        room=self.current_room()
        if not room or room.level_id not in self.project.tilesets:return
        if not messagebox.askyesno("Remove Tileset",f"Remove the imported tileset from level {room.level_id}? Room tile IDs will be cleared."):
            return
        del self.project.tilesets[room.level_id]
        for r in self._rooms_for_level(room.level_id):
            r.tile_map=[[-1 for _ in range(40)] for _ in range(25)]
        self.current_tile_id=0
        self.dirty=True
        self._refresh_rooms()

    def _on_room_tile_select(self,e=None):
        sel=self.room_tile_list.curselection()
        if not sel:return
        try:self.current_tile_id=int(self.room_tile_list.get(sel[0]).split(":",1)[0])
        except:return
        room=self.current_room()
        ts=self.project.tilesets.get(room.level_id) if room else None
        if ts:
            while len(ts.tile_collision)<len(ts.tiles):ts.tile_collision.append(0)
            while len(ts.tile_properties)<len(ts.tiles):ts.tile_properties.append([0,0,0,0])
            code=ts.tile_collision[self.current_tile_id] if self.current_tile_id<len(ts.tile_collision) else 0
            self.room_tile_collision_var.set({0:"None",1:"Solid",2:"Hazard"}.get(code,"None"))
            vals=(list(ts.tile_properties[self.current_tile_id])+[0,0,0,0])[:4]
            for i,v in enumerate(vals):self.room_tile_prop_vars[i].set(int(v)&255)
        self.room_tool_var.set("tile")
        self._draw_room()

    def _apply_room_tile_collision(self,e=None):
        room=self.current_room()
        ts=self.project.tilesets.get(room.level_id) if room else None
        if not ts or not (0<=self.current_tile_id<len(ts.tiles)):return
        while len(ts.tile_collision)<len(ts.tiles):ts.tile_collision.append(0)
        code={"None":0,"Solid":1,"Hazard":2}.get(self.room_tile_collision_var.get(),0)
        ts.tile_collision[self.current_tile_id]=code
        self.dirty=True
        self._refresh_rooms()

    def _apply_room_tile_properties(self):
        room=self.current_room()
        ts=self.project.tilesets.get(room.level_id) if room else None
        if not ts or not (0<=self.current_tile_id<len(ts.tiles)):return
        while len(ts.tile_properties)<len(ts.tiles):ts.tile_properties.append([0,0,0,0])
        vals=[]
        for v in self.room_tile_prop_vars:
            try:n=int(v.get())
            except:n=0
            vals.append(max(0,min(255,n)))
        ts.tile_properties[self.current_tile_id]=vals
        self.dirty=True
        self._refresh_rooms()
        self.status.set(
            f"Tile {self.current_tile_id} custom values: "
            + ", ".join(f"P{i}={v}" for i,v in enumerate(vals))
        )

    def _room_tile_cell_from_event(self,event):
        if not hasattr(self,"_room_canvas_transform"):return None
        scale,ox,oy=self._room_canvas_transform
        rx=(event.x-ox)/scale; ry=(event.y-oy)/scale
        if rx<0 or ry<0 or rx>=320 or ry>=200:return None
        room=self.current_room()
        ts=self.project.tilesets.get(room.level_id) if room else None
        tile_w=max(1,int(getattr(ts,"tile_width",8))) if ts else 8
        tile_h=max(1,int(getattr(ts,"tile_height",8))) if ts else 8
        cx=int(rx//tile_w); cy=int(ry//tile_h)
        if cx>=40 or cy>=25:return None
        return cx,cy

    def _paint_room_tile(self,event,tile_id=None):
        room=self.current_room()
        if not room:return
        cell=self._room_tile_cell_from_event(event)
        if not cell:return
        cx,cy=cell
        # Normalize old/project-loaded maps.
        if len(room.tile_map)!=25 or any(len(row)!=40 for row in room.tile_map):
            fixed=[[-1 for _ in range(40)] for _ in range(25)]
            for y,row in enumerate(room.tile_map[:25]):
                for x,val in enumerate(row[:40]):fixed[y][x]=int(val)
            room.tile_map=fixed
        room.tile_map[cy][cx]=self.current_tile_id if tile_id is None else tile_id
        self.dirty=True
        self._draw_room()

    def _level_objects(self,level=None):
        level=level or self.current_level
        return {oid:o for oid,o in self.project.objects.items() if o.scene==level}

    def _on_room_place_object_select(self,e=None):
        sel=self.room_object_place_list.curselection()
        if not sel:return
        try:self.current_room_object_id=int(self.room_object_place_list.get(sel[0]).split(":",1)[0])
        except:return
        self.room_tool_var.set("place_object")
        o=self.project.objects.get(self.current_room_object_id)
        if o:self.status.set(f"Place Object ready: {self.current_room_object_id} - {o.name}. Click inside the room.")
        self._draw_room()

    def place_selected_object_center(self):
        room=self.current_room()
        if not room:return
        class _CenterEvent:pass
        ev=_CenterEvent()
        # Convert room center to current canvas coordinates using a fresh transform.
        scale,ox,oy=self._get_room_canvas_transform()
        ev.x=int(ox+160*scale); ev.y=int(oy+100*scale)
        self.room_tool_var.set("place_object")
        self._place_object_in_room(ev)

    def _get_room_canvas_transform(self):
        c=self.room_canvas
        # winfo_width/height are 1 until Tk has completed geometry. update_idletasks
        # makes placement reliable even on the first interaction with the Rooms tab.
        try:self.update_idletasks()
        except Exception:pass
        cw=max(2,int(c.winfo_width())); ch=max(2,int(c.winfo_height()))
        if cw<=2: cw=max(2,int(c.winfo_reqwidth()))
        if ch<=2: ch=max(2,int(c.winfo_reqheight()))
        scale=max(0.01,min(cw/320.0,ch/200.0))
        ox=(cw-320*scale)/2; oy=(ch-200*scale)/2
        self._room_canvas_transform=(scale,ox,oy)
        return self._room_canvas_transform

    def _room_point_from_event(self,event):
        scale,ox,oy=self._get_room_canvas_transform()
        x=int(round((event.x-ox)/scale))
        y=int(round((event.y-oy)/scale))
        if x<0 or y<0 or x>=320 or y>=200:return None
        return x,y

    def _next_instance_id(self):
        used={i.instance_id for i in self.project.instances}
        for n in range(65536):
            if n not in used:return n
        raise ValueError("Instance limit reached.")

    def _place_object_in_room(self,event):
        room=self.current_room()
        if not room:return
        oid=self.current_room_object_id
        o=self.project.objects.get(oid)
        if not o or o.scene!=room.level_id:
            return messagebox.showwarning("No object","Select an existing object from this level first.")
        point=self._room_point_from_event(event)
        if not point:return
        sp=self.project.sprites.get(self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id))
        physical_w=sp.width*2 if sp and sp.mode=="multicolor" else (sp.width if sp else 8)
        h=sp.height if sp else 8
        x=max(0,min(320-physical_w,point[0])); y=max(0,min(200-h,point[1]))
        if oid==0:
            o.room_id=room.room_id; o.sprite_level=room.level_id; o.scene=room.level_id
            o.x=x; o.y=y
            self.current_object_id=0
            self.current_room_instance_id=None
            self.status.set(f"Moved unique Object 0 to {room.name} at {x},{y}.")
        else:
            iid=self._next_instance_id()
            next_z=max([int(getattr(i,"z_order",0)) for i in self.project.instances if i.room_id==room.room_id and i.level_id==room.level_id]+[-1])+1
            self.project.instances.append(RoomInstance(
                instance_id=iid,object_id=oid,room_id=room.room_id,
                level_id=room.level_id,x=x,y=y,active=o.active,
                properties=(list(getattr(o,"properties",[0]*8))+[0]*8)[:8],z_order=next_z&255
            ))
            self.current_object_id=oid
            self.current_room_instance_id=iid
            self.status.set(f"Placed Object {oid} instance {iid} in {room.name} at {x},{y}.")
        self.dirty=True
        self._ensure_at_least_one_player_start()
        self._refresh_all()

    def _set_room_player_start(self,event):
        room=self.current_room()
        if not room:return
        oid=self.current_room_object_id
        o=self.project.objects.get(oid)
        if not o or o.scene!=room.level_id:
            return messagebox.showwarning("No player object","Select the player object from this level first.")
        point=self._room_point_from_event(event)
        if not point:return
        sp=self.project.sprites.get(self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id))
        physical_w=sp.width*2 if sp and sp.mode=="multicolor" else (sp.width if sp else 8)
        h=sp.height if sp else 8
        room.player_start_enabled=True
        room.player_start_object_id=oid
        room.player_start_sprite_id=o.sprite_id
        room.player_start_x=max(0,min(320-physical_w,point[0]))
        room.player_start_y=max(0,min(200-h,point[1]))
        self.dirty=True
        self._draw_room()
        self._refresh_rooms()
        self.status.set(
            f"Explicit player start for {room.name}: Object {oid} at "
            f"{room.player_start_x},{room.player_start_y}"
        )

    def clear_room_player_start(self):
        room=self.current_room()
        if not room or not room.player_start_enabled:return
        room.player_start_enabled=False
        self.dirty=True
        self._ensure_at_least_one_player_start()
        self._refresh_rooms()

    def _ensure_at_least_one_player_start(self):
        if any(r.player_start_enabled for r in self.project.rooms):
            return
        # Object 0 is the default player convention. Once it exists, ensure
        # the project always has at least one explicit start, preferring Room 0.
        player=self.project.objects.get(0)
        if not player:
            return
        room=next((r for r in self.project.rooms if r.room_id==0),None)
        if room is None and self.project.rooms:
            room=sorted(self.project.rooms,key=lambda r:r.room_id)[0]
        if not room:
            return
        room.player_start_enabled=True
        room.player_start_object_id=0
        room.player_start_sprite_id=player.sprite_id
        if player.room_id==room.room_id and player.scene==room.level_id:
            room.player_start_x=player.x
            room.player_start_y=player.y
        else:
            room.player_start_x=156
            room.player_start_y=180

    def _automatic_entry_description(self,room):
        if room.player_start_enabled:
            return f"Explicit: Object {room.player_start_object_id} at {room.player_start_x},{room.player_start_y}"
        return (
            "Automatic edge entry: DOWN -> top, keep prior X; UP -> bottom, keep prior X; "
            "RIGHT -> left, keep prior Y; LEFT -> right, keep prior Y."
        )

    def _room_preview_color(self,idx):
        try:return C64_PALETTE[int(idx)&15][1]
        except:return "#000000"

    def _draw_room_entity(self,c,room,oid,x,y,scale,ox,oy,label,selected=False):
        o=self.project.objects.get(oid)
        if not o:return
        sp=self.project.sprites.get(self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id))
        w=(sp.width*2 if sp and sp.mode=="multicolor" else (sp.width if sp else 8)); h=(sp.height if sp else 8)
        x0=ox+x*scale; y0=oy+y*scale; x1=x0+w*scale; y1=y0+h*scale
        if sp and sp.frames:
            fr=sp.frames[0]
            for py,row in enumerate(fr.pixels):
                for px,val in enumerate(row):
                    if not val:continue
                    if sp.mode=="hires":col=self._room_preview_color(sp.colors.get("hires",1)); pw=1
                    else:
                        col=self._room_preview_color(sp.colors.get("mc1",5) if val==1 else sp.colors.get("mc2",6) if val==2 else sp.colors.get("local",7)); pw=2
                    c.create_rectangle(ox+(x+px*pw)*scale,oy+(y+py)*scale,
                                       ox+(x+(px+1)*pw)*scale,oy+(y+py+1)*scale,
                                       fill=col,outline="")
        c.create_rectangle(x0,y0,x1,y1,outline="#ffcc00" if selected else "#aaaaaa",width=2)
        c.create_text(x0+2,y0-2,text=label,anchor="sw",fill="#ffffff",font=("",8))

    def _draw_room(self):
        if not hasattr(self,"room_canvas"):return
        c=self.room_canvas; c.delete("all")
        room=self.current_room()
        if not room:
            c.configure(bg="#222222"); self.room_status_var.set("No room selected"); return
        level=next((s for s in self.project.scenes if s.name==room.level_id),None)
        c.configure(bg=self._room_preview_color(level.background_color if level else 0))
        scale,ox,oy=self._get_room_canvas_transform()

        # Draw level tileset / room tile layer first. Imported Sky Strike
        # tiles use 4 logical multicolor pixels x 8 rows => 8x8 physical.
        ts=self.project.tilesets.get(room.level_id)
        if ts and ts.tiles:
            if len(room.tile_map)!=25 or any(len(row)!=40 for row in room.tile_map):
                fixed=[[-1 for _ in range(40)] for _ in range(25)]
                for yy,row in enumerate(room.tile_map[:25]):
                    for xx,val in enumerate(row[:40]):fixed[yy][xx]=int(val)
                room.tile_map=fixed
            tile_w=max(1,int(getattr(ts,"tile_width",8)))
            tile_h=max(1,int(getattr(ts,"tile_height",8)))
            ts_mode=getattr(ts,"mode","multicolor")
            map_cols=min(40,(320+tile_w-1)//tile_w)
            map_rows=min(25,(200+tile_h-1)//tile_h)
            pxw=2 if ts_mode=="multicolor" else 1
            for ty in range(map_rows):
                for tx in range(map_cols):
                    tid=room.tile_map[ty][tx]
                    if tid<0 or tid>=len(ts.tiles):continue
                    tile=ts.tiles[tid]
                    for py,row in enumerate(tile):
                        for px,val in enumerate(row):
                            if val==0: col=self._room_preview_color(level.background_color if level else 0)
                            elif val==1: col=self._room_preview_color(level.mc1 if level else 5)
                            elif val==2: col=self._room_preview_color(level.mc2 if level else 6)
                            else: col=self._room_preview_color(level.local if level else 7)
                            x0=tx*tile_w+px*pxw
                            y0=ty*tile_h+py
                            if x0>=320 or y0>=200:continue
                            c.create_rectangle(
                                ox+x0*scale, oy+y0*scale,
                                ox+min(320,x0+pxw)*scale, oy+min(200,y0+1)*scale,
                                fill=col, outline=""
                            )

        # Explicit Player Start marker. Rooms without one use automatic
        # edge-entry based on the direction of travel from the prior room.
        psprites=self._level_sprites(room.level_id)
        pobj=self.project.objects.get(room.player_start_object_id) if room.player_start_enabled else None
        psp=psprites.get(pobj.sprite_id if pobj else room.player_start_sprite_id) if room.player_start_enabled else None
        if room.player_start_enabled and psp and psp.frames:
            fr=psp.frames[0]
            for py,row in enumerate(fr.pixels):
                for px,val in enumerate(row):
                    if not val:continue
                    if psp.mode=="hires":
                        col=self._room_preview_color(psp.colors.get("hires",1)); pw=1
                    else:
                        col=self._room_preview_color(
                            psp.colors.get("mc1",5) if val==1 else
                            psp.colors.get("mc2",6) if val==2 else
                            psp.colors.get("local",7)
                        ); pw=2
                    c.create_rectangle(
                        ox+(room.player_start_x+px*pw)*scale,
                        oy+(room.player_start_y+py)*scale,
                        ox+(room.player_start_x+(px+1)*pw)*scale,
                        oy+(room.player_start_y+py+1)*scale,
                        fill=col,outline=""
                    )
            pwid=psp.width*2 if psp.mode=="multicolor" else psp.width
            x0=ox+room.player_start_x*scale; y0=oy+room.player_start_y*scale
            x1=x0+pwid*scale; y1=y0+psp.height*scale
            c.create_rectangle(x0,y0,x1,y1,outline="#00ffff",width=2,dash=(4,2))
            c.create_line(x0,y0,x1,y1,fill="#00ffff")
            c.create_line(x1,y0,x0,y1,fill="#00ffff")
            c.create_text(x0,y0-3,text="PLAYER START",anchor="sw",fill="#00ffff",font=("",8,"bold"))
        elif not room.player_start_enabled:
            c.create_text(
                ox+4,oy+4,
                text="AUTO ENTRY: position inherited from prior room edge",
                anchor="nw",fill="#00ffff",font=("",8,"bold")
            )

        for x in range(0,321,8):
            px=ox+x*scale; c.create_line(px,oy,px,oy+200*scale,fill="#333333")
        for y in range(0,201,8):
            py=oy+y*scale; c.create_line(ox,py,ox+320*scale,py,fill="#333333")
        # Object 0 is unique. Objects 1-255 use reusable room instances.
        o0=self.project.objects.get(0)
        if o0 and o0.room_id==room.room_id and o0.scene==room.level_id:
            self._draw_room_entity(c,room,0,o0.x,o0.y,scale,ox,oy,"0",self.current_room_instance_id is None and self.room_drag_object_id==0)
        for inst in sorted(self.project.instances,key=lambda i:(int(getattr(i,"z_order",0)),i.instance_id)):
            if inst.room_id!=room.room_id or inst.level_id!=room.level_id:continue
            self._draw_room_entity(c,room,inst.object_id,inst.x,inst.y,scale,ox,oy,
                                   f"{inst.object_id}#{inst.instance_id}",
                                   inst.instance_id==self.current_room_instance_id)
        self.room_status_var.set(f"{room.level_id} / {room.name}")

    def _room_object_at_canvas(self,event):
        room=self.current_room()
        if not room or not hasattr(self,"_room_canvas_transform"):return None
        scale,ox,oy=self._room_canvas_transform
        rx=(event.x-ox)/scale; ry=(event.y-oy)/scale
        hits=[]
        o0=self.project.objects.get(0)
        if o0 and o0.room_id==room.room_id and o0.scene==room.level_id:
            sp=self.project.sprites.get(self._sprite_key(getattr(o0,"sprite_level",o0.scene),o0.sprite_id))
            w=(sp.width*2 if sp and sp.mode=="multicolor" else (sp.width if sp else 8)); h=sp.height if sp else 8
            if o0.x<=rx<o0.x+w and o0.y<=ry<o0.y+h:hits.append(("object",0))
        for inst in sorted(self.project.instances,key=lambda i:(int(getattr(i,"z_order",0)),i.instance_id)):
            if inst.room_id!=room.room_id or inst.level_id!=room.level_id:continue
            o=self.project.objects.get(inst.object_id)
            if not o:continue
            sp=self.project.sprites.get(self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id))
            w=(sp.width*2 if sp and sp.mode=="multicolor" else (sp.width if sp else 8)); h=sp.height if sp else 8
            if inst.x<=rx<inst.x+w and inst.y<=ry<inst.y+h:hits.append(("instance",inst.instance_id))
        return hits[-1] if hits else None

    def _room_canvas_press(self,event):
        tool=self.room_tool_var.get()
        if tool=="tile":
            ts=self.project.tilesets.get(self.current_room().level_id) if self.current_room() else None
            if not ts or not ts.tiles:
                return messagebox.showwarning("No tileset","Import a Sky Strike tileset for this level first.")
            self._paint_room_tile(event)
            return
        if tool=="place_object":
            self._place_object_in_room(event)
            return
        if tool=="player_start":
            self._set_room_player_start(event)
            return
        hit=self._room_object_at_canvas(event)
        self.room_drag_object_id=None; self.current_room_instance_id=None
        if hit:
            kind,hid=hit
            if kind=="object":
                self.room_drag_object_id=0; self.current_object_id=0
            else:
                self.current_room_instance_id=hid
                inst=next((i for i in self.project.instances if i.instance_id==hid),None)
                if inst:
                    self.current_object_id=inst.object_id
                    if hasattr(self,"room_instance_z_var"):
                        self.room_instance_z_var.set(int(getattr(inst,"z_order",0)))
                        vals=(list(getattr(inst,"properties",[0]*8))+[0]*8)[:8]
                        for pv,val in zip(self.room_instance_prop_vars,vals):pv.set(int(val)&255)
            self._refresh_object_list(); self._refresh_object_fields()
        self._draw_room()

    def _room_canvas_drag(self,event):
        tool=self.room_tool_var.get()
        if tool=="tile":
            self._paint_room_tile(event)
            return
        if tool=="player_start":
            self._set_room_player_start(event)
            return
        if tool=="place_object":
            return
        if not hasattr(self,"_room_canvas_transform"):return
        scale,ox,oy=self._room_canvas_transform
        if self.current_room_instance_id is not None:
            inst=next((i for i in self.project.instances if i.instance_id==self.current_room_instance_id),None)
            if not inst:return
            o=self.project.objects.get(inst.object_id)
            if not o:return
            sp=self.project.sprites.get(self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id))
            w=(sp.width*2 if sp and sp.mode=="multicolor" else (sp.width if sp else 8)); h=(sp.height if sp else 8)
            inst.x=max(0,min(320-w,int(round((event.x-ox)/scale))))
            inst.y=max(0,min(200-h,int(round((event.y-oy)/scale))))
        else:
            if self.room_drag_object_id is None:return
            o=self.project.objects.get(self.room_drag_object_id)
            if not o:return
            sp=self.project.sprites.get(self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id))
            w=(sp.width*2 if sp and sp.mode=="multicolor" else (sp.width if sp else 8)); h=(sp.height if sp else 8)
            o.x=max(0,min(320-w,int(round((event.x-ox)/scale))))
            o.y=max(0,min(200-h,int(round((event.y-oy)/scale))))
        self.dirty=True; self._draw_room(); self._refresh_object_fields()

    def _room_canvas_right(self,event):
        if self.room_tool_var.get()=="tile":
            self._paint_room_tile(event,-1)

    def _room_canvas_release(self,event):
        self.room_drag_object_id=None
        self._draw_room()

    def _room_object_list_select(self,event=None):
        sel=self.room_object_list.curselection()
        if not sel:return
        raw=self.room_object_list.get(sel[0]).split(":",1)[0]
        self.room_drag_object_id=None; self.current_room_instance_id=None
        try:
            if "#" in raw:
                oid_s,iid_s=raw.split("#",1)
                self.current_object_id=int(oid_s); self.current_room_instance_id=int(iid_s)
                inst=next((i for i in self.project.instances if i.instance_id==self.current_room_instance_id),None)
                if inst and hasattr(self,"room_instance_z_var"):
                    self.room_instance_z_var.set(int(getattr(inst,"z_order",0)))
                    vals=(list(getattr(inst,"properties",[0]*8))+[0]*8)[:8]
                    for pv,val in zip(self.room_instance_prop_vars,vals):pv.set(int(val)&255)
            else:
                self.current_object_id=int(raw); self.room_drag_object_id=self.current_object_id
        except:return
        self._refresh_object_list(); self._refresh_object_fields(); self._draw_room()

    def apply_room_instance_values(self):
        if self.current_room_instance_id is None:
            return messagebox.showinfo("Instance values","Select a reusable placed instance (Object 1-255) in the room first.")
        inst=next((i for i in self.project.instances if i.instance_id==self.current_room_instance_id),None)
        if not inst:return
        try:
            inst.z_order=max(0,min(255,int(self.room_instance_z_var.get())))
            inst.properties=[max(0,min(255,int(v.get()))) for v in self.room_instance_prop_vars]
        except Exception as exc:
            return messagebox.showerror("Instance values",str(exc))
        self.dirty=True; self._refresh_rooms(); self._draw_room()
        self.status.set(f"Updated instance {inst.instance_id} values and stack order.")

    def delete_room_instance(self):
        if self.current_room_instance_id is None:
            if self.current_object_id==0:
                return messagebox.showwarning("Unique object","Object 0 is unique. Move it instead of deleting a room instance.")
            return
        iid=self.current_room_instance_id
        self.project.instances=[i for i in self.project.instances if i.instance_id!=iid]
        self.current_room_instance_id=None
        self.dirty=True
        self._refresh_rooms()
        self.status.set(f"Deleted room instance {iid}.")

    # ---------------- paths ----------------
    def _refresh_paths(self):
        if not hasattr(self,"path_list"):return
        self.path_list.delete(0,"end")
        for i,p in enumerate(self.project.paths):
            self.path_list.insert("end",f"{i:02d}: {p.name} [{p.mode}, {p.speed}px/f] ({len(p.points)} pts)")
        self.path_level_cb["values"]=[s.name for s in self.project.scenes]
        if self.current_path_index is not None and 0<=self.current_path_index<len(self.project.paths):
            self.path_list.selection_set(self.current_path_index)
            self._load_path_fields()
        else:
            self.path_name.set(""); self.path_level.set(self.current_level or self.project.start_scene); self.path_mode.set("loop"); self.path_speed.set(1)
            self.path_point_list.delete(0,"end")
        if hasattr(self,"o_path_cb"):
            level=self.o_scene.get() if hasattr(self,"o_scene") else self.current_level
            self.o_path_cb["values"]=[""]+[p.name for p in self.project.paths if p.level_id==level]

    def _load_path_fields(self):
        if self.current_path_index is None or not (0<=self.current_path_index<len(self.project.paths)):return
        p=self.project.paths[self.current_path_index]
        self.path_name.set(p.name); self.path_level.set(p.level_id); self.path_mode.set(p.mode); self.path_speed.set(p.speed)
        self.path_point_list.delete(0,"end")
        for i,(x,y) in enumerate(p.points):self.path_point_list.insert("end",f"{i:03d}: X={x:3d}  Y={y:3d}")
        if self.current_path_point_index is not None and 0<=self.current_path_point_index<len(p.points):
            self.path_point_list.selection_set(self.current_path_point_index)
            x,y=p.points[self.current_path_point_index]; self.path_point_x.set(x); self.path_point_y.set(y)

    def _on_path_select(self,e=None):
        sel=self.path_list.curselection()
        if not sel:return
        self.current_path_index=sel[0]; self.current_path_point_index=None; self._load_path_fields()

    def add_path(self):
        base="Path"; used={p.name for p in self.project.paths}; n=1
        while f"{base} {n}" in used:n+=1
        level=self.current_level or self.project.start_scene
        self.project.paths.append(PathDefinition(name=f"{base} {n}",level_id=level,speed=1,mode="loop",points=[[40,40],[200,40]]))
        self.current_path_index=len(self.project.paths)-1; self.current_path_point_index=0; self.dirty=True; self._refresh_paths()

    def delete_path(self):
        if self.current_path_index is None or not (0<=self.current_path_index<len(self.project.paths)):return
        doomed=self.project.paths[self.current_path_index].name
        if not messagebox.askyesno("Delete Path",f"Delete path '{doomed}'?"):return
        del self.project.paths[self.current_path_index]
        for o in self.project.objects.values():
            if getattr(o,"path_name","")==doomed:o.path_name="";o.path_enabled=False
        self.current_path_index=None; self.current_path_point_index=None; self.dirty=True; self._refresh_all()

    def apply_path(self):
        if self.current_path_index is None or not (0<=self.current_path_index<len(self.project.paths)):return
        p=self.project.paths[self.current_path_index]; old=p.name
        name=self.path_name.get().strip() or old
        if any(i!=self.current_path_index and q.name==name for i,q in enumerate(self.project.paths)):
            return messagebox.showerror("Path name","Path names must be unique.")
        p.name=name; p.level_id=self.path_level.get() or self.project.start_scene; p.mode=self.path_mode.get() if self.path_mode.get() in ("loop","patrol","once") else "loop"; p.speed=max(1,min(16,int(self.path_speed.get())))
        if old!=name:
            for o in self.project.objects.values():
                if getattr(o,"path_name","")==old:o.path_name=name
        self.dirty=True; self._refresh_all()

    def _on_path_point_select(self,e=None):
        if self.current_path_index is None:return
        sel=self.path_point_list.curselection()
        if not sel:return
        self.current_path_point_index=sel[0]; p=self.project.paths[self.current_path_index]
        x,y=p.points[self.current_path_point_index]; self.path_point_x.set(x); self.path_point_y.set(y)

    def add_path_point(self):
        if self.current_path_index is None:return messagebox.showwarning("No path","Create or select a path first.")
        p=self.project.paths[self.current_path_index]
        p.points.append([max(0,min(319,int(self.path_point_x.get()))),max(0,min(199,int(self.path_point_y.get())))])
        self.current_path_point_index=len(p.points)-1; self.dirty=True; self._refresh_paths()

    def update_path_point(self):
        if self.current_path_index is None or self.current_path_point_index is None:return
        p=self.project.paths[self.current_path_index]
        if not (0<=self.current_path_point_index<len(p.points)):return
        p.points[self.current_path_point_index]=[max(0,min(319,int(self.path_point_x.get()))),max(0,min(199,int(self.path_point_y.get())))]
        self.dirty=True; self._refresh_paths()

    def delete_path_point(self):
        if self.current_path_index is None or self.current_path_point_index is None:return
        p=self.project.paths[self.current_path_index]
        if not (0<=self.current_path_point_index<len(p.points)):return
        del p.points[self.current_path_point_index]
        self.current_path_point_index=min(self.current_path_point_index,len(p.points)-1) if p.points else None
        self.dirty=True; self._refresh_paths()

    def move_path_point(self,delta):
        if self.current_path_index is None or self.current_path_point_index is None:return
        p=self.project.paths[self.current_path_index]; i=self.current_path_point_index; j=i+delta
        if not (0<=j<len(p.points)):return
        p.points[i],p.points[j]=p.points[j],p.points[i]; self.current_path_point_index=j; self.dirty=True; self._refresh_paths()

    # ---------------- project ----------------
    def _project_meta_changed(self):
        if not hasattr(self,"project_title_var"):return
        self.project.title=self.project_title_var.get()
        self.project.expanded_memory=bool(self.reu_var.get())
        try:self.project.expanded_memory_kb=int(self.reu_kb_var.get())
        except:pass
        self.dirty=True

    def _project_dict(self):
        return {
            "format":"Next64 C64 Game Creator Project","version":7,
            "title":self.project.title,"expanded_memory":self.project.expanded_memory,
            "expanded_memory_kb":self.project.expanded_memory_kb,
            "start_scene":self.project.start_scene,
            "sprites":{str(k):asdict(v) for k,v in sorted(self.project.sprites.items())},
            "objects":{str(k):asdict(v) for k,v in sorted(self.project.objects.items())},
            "instances":[asdict(i) for i in self.project.instances],
            "scenes":[asdict(s) for s in self.project.scenes],
            "rooms":[asdict(r) for r in self.project.rooms],
            "tilesets":{str(k):asdict(v) for k,v in self.project.tilesets.items()},
            "variables":[asdict(v) for v in self.project.variables],
            "paths":[asdict(v) for v in self.project.paths],
            "inventory":asdict(self.project.inventory),
            "start_room_id":self.project.start_room_id,
        }

    def new_project(self):
        if self.dirty and not messagebox.askyesno("New Project","Discard unsaved changes?"):return
        self.stop_animation_preview()
        self.project_path=None
        self.project=Project(title="Untitled Next64 Game", expanded_memory=False, expanded_memory_kb=512,
            sprites={}, objects={}, instances=[], scenes=[Scene(name="Scene 1", background_color=0, display_mode="multicolor", mc1=6, mc2=1, local=7)],
            rooms=[Room(room_id=0,name="Room 0",level_id="Scene 1",player_start_enabled=False)],
            tilesets={},
            variables=[], paths=[], start_scene="Scene 1", start_room_id=0)
        self.current_level="Scene 1"
        self.current_room_id=0
        self.current_sprite_id=None; self.current_frame_index=0
        self.current_object_id=None; self.current_event_index=None
        self.current_path_index=None; self.current_path_point_index=None
        self.dirty=False
        self._refresh_all()
        self.status.set("Blank project created with Room 0. Create Sprite 0, then add/place objects.")

    def load_demo_project(self):
        if self.dirty and not messagebox.askyesno("Load Demo","Discard unsaved changes and load the editor-native starter demo?"):return
        self.stop_animation_preview()
        self.project_path=None
        self._load_builtin_demo()
        self.dirty=False
        self._refresh_all()

    def save_project(self):
        if not self.project_path:return self.save_project_as()
        self.project_path.write_text(json.dumps(self._project_dict(),indent=2),encoding="utf-8")
        self.dirty=False; self.status.set(f"Saved {self.project_path}")

    def save_project_as(self):
        p=filedialog.asksaveasfilename(defaultextension=".n64game",
            filetypes=[("Next64 Game Project","*.n64game"),("JSON","*.json")])
        if p:self.project_path=Path(p); self.save_project()

    def open_project(self):
        self.stop_animation_preview()
        p=filedialog.askopenfilename(filetypes=[("Next64 Game Project","*.n64game"),("JSON","*.json"),("All files","*.*")])
        if not p:return
        try:
            d=json.loads(Path(p).read_text(encoding="utf-8"))
            pr=Project(
                title=d.get("title","Untitled Next64 Game"),
                expanded_memory=bool(d.get("expanded_memory",False)),
                expanded_memory_kb=int(d.get("expanded_memory_kb",512)),
                sprites={},objects={},
                instances=[RoomInstance(instance_id=int(x.get("instance_id",i)),
                                        object_id=int(x.get("object_id",1)),
                                        room_id=int(x.get("room_id",0)),
                                        level_id=x.get("level_id",d.get("start_scene","Scene 1")),
                                        x=int(x.get("x",80)),y=int(x.get("y",80)),
                                        active=bool(x.get("active",True)),
                                        properties=(list(x.get("properties",[0]*8))+[0]*8)[:8],
                                        z_order=int(x.get("z_order",i))&255)
                           for i,x in enumerate(d.get("instances",[]))],
                scenes=[Scene(name=x.get("name","Scene 1"), background_color=int(x.get("background_color",0)),
                              display_mode=x.get("display_mode","hires"), mc1=int(x.get("mc1",5)),
                              mc2=int(x.get("mc2",6)), local=int(x.get("local",7)))
                        for x in d.get("scenes",[{"name":"Scene 1","background_color":0,"display_mode":"hires"}])],
                rooms=[Room(room_id=int(x.get("room_id",i)),name=x.get("name",f"Room {i}"),
                            level_id=x.get("level_id",d.get("start_scene","Scene 1")),
                            width=int(x.get("width",320)),height=int(x.get("height",200)),
                            tile_map=x.get("tile_map", [[-1 for _ in range(40)] for _ in range(25)]),
                            player_start_enabled=bool(x.get("player_start_enabled",
                                ("player_start_x" in x or "player_start_y" in x))),
                            player_start_object_id=int(x.get("player_start_object_id",0)),
                            player_start_x=int(x.get("player_start_x",156)),
                            player_start_y=int(x.get("player_start_y",180)),
                            player_start_sprite_id=int(x.get("player_start_sprite_id",0)))
                       for i,x in enumerate(d.get("rooms",[{"room_id":0,"name":"Room 0","level_id":d.get("start_scene","Scene 1")}]))],
                tilesets={str(k):TileSet(name=v.get("name",str(k)),source_format=v.get("source_format",""),
                                         tiles=v.get("tiles",[]),tile_local_colors=v.get("tile_local_colors",[]),
                                         tile_collision=v.get("tile_collision",[0 for _ in v.get("tiles",[])]),
                                         tile_properties=v.get("tile_properties",[[0,0,0,0] for _ in v.get("tiles",[])]),
                                         tile_width=int(v.get("tile_width",8)),tile_height=int(v.get("tile_height",8)),
                                         mode=v.get("mode","multicolor"))
                          for k,v in d.get("tilesets",{}).items()},
                variables=[Variable(**x) for x in d.get("variables",[{"name":"score","initial":0}])],
                paths=[PathDefinition(name=x.get("name",f"Path {i+1}"), level_id=x.get("level_id",d.get("start_scene","Scene 1")), speed=max(1,min(16,int(x.get("speed",1)))), mode=x.get("mode","loop") if x.get("mode","loop") in ("loop","patrol","once") else "loop", points=[[max(0,min(319,int(p[0]))),max(0,min(199,int(p[1])))] for p in x.get("points",[]) if isinstance(p,(list,tuple)) and len(p)>=2]) for i,x in enumerate(d.get("paths",[]))],
                inventory=InventoryConfig(
                    enabled=bool(d.get("inventory",{}).get("enabled",False)),
                    slot_count=max(1,min(32,int(d.get("inventory",{}).get("slot_count",8)))),
                    items=[InventoryItem(item_id=max(1,min(254,int(x.get("item_id",1)))),name=x.get("name","Item"),tile_id=int(x.get("tile_id",0))&255,max_stack=max(1,min(255,int(x.get("max_stack",99))))) for x in d.get("inventory",{}).get("items",[])],
                    initial_items=list(d.get("inventory",{}).get("initial_items",[255]*8)),
                    initial_quantities=list(d.get("inventory",{}).get("initial_quantities",[0]*8)),
                    selected_slot=int(d.get("inventory",{}).get("selected_slot",0)),
                    display_room_id=int(d.get("inventory",{}).get("display_room_id",0))&255,
                    display_x=int(d.get("inventory",{}).get("display_x",1)),display_y=int(d.get("inventory",{}).get("display_y",1)),
                    display_columns=max(1,int(d.get("inventory",{}).get("display_columns",4))),empty_tile_id=int(d.get("inventory",{}).get("empty_tile_id",0))&255),
                start_scene=d.get("start_scene","Scene 1"),
                start_room_id=int(d.get("start_room_id",0)))
            for sid,sd in d.get("sprites",{}).items():
                raw_sid=int(sd.get("sprite_id", str(sid).split(":")[-1] if ":" in str(sid) else sid))
                level_id=sd.get("level_id", d.get("start_scene","Scene 1"))
                s=Sprite(sprite_id=raw_sid,level_id=level_id,name=sd.get("name",f"Sprite {raw_sid}"),
                         mode=sd.get("mode","hires"),width=int(sd.get("width",8)),height=int(sd.get("height",8)),
                         colors=sd.get("colors",{"hires":1,"mc1":5,"mc2":6,"local":1}),
                         storage=sd.get("storage","auto"),bank=int(sd.get("bank",0)),
                         base_address=sd.get("base_address",""),loop=bool(sd.get("loop",True)),
                         auto_animate=bool(sd.get("auto_animate",True)),
                         renderer=sd.get("renderer","software"),source_format=sd.get("source_format",""),frames=[])
                for fd in sd.get("frames",[]):
                    s.frames.append(Frame(fd.get("name","Frame"),int(fd.get("duration",6)),
                                          fd.get("pixels",blank_pixels(s.mode,s.width,s.height))))
                if not s.frames:s.frames=[Frame(pixels=blank_pixels(s.mode,s.width,s.height))]
                pr.sprites[f"{s.level_id}:{s.sprite_id}"]=s
            for oid,od in d.get("objects",{}).items():
                o=GameObject(object_id=int(od.get("object_id",oid)),name=od.get("name",f"Object {oid}"),
                             sprite_id=int(od.get("sprite_id",0)),sprite_level=od.get("sprite_level",od.get("scene",pr.start_scene)),
                             x=int(od.get("x",80)),y=int(od.get("y",80)),
                             active=bool(od.get("active",True)),scene=od.get("scene",pr.start_scene),
                             room_id=int(od.get("room_id",pr.start_room_id)),
                             properties=(list(od.get("properties",[0]*8))+[0]*8)[:8],
                             path_name=str(od.get("path_name","")), path_enabled=bool(od.get("path_enabled",False)),
                             events=list(od.get("events",[])))
                pr.objects[o.object_id]=o
            # VER 04.4 migration: pre-instance projects stored each nonzero
            # object's room X/Y directly on its definition. Preserve that placement
            # as one reusable instance. Object 0 stays unique.
            if not pr.instances:
                for oid,o in sorted(pr.objects.items()):
                    if oid!=0:
                        pr.instances.append(RoomInstance(
                            instance_id=len(pr.instances),object_id=oid,room_id=o.room_id,
                            level_id=o.scene,x=o.x,y=o.y,active=o.active,
                            properties=(list(getattr(o,"properties",[0]*8))+[0]*8)[:8],z_order=len(pr.instances)
                        ))
            self.project=pr
            self.current_level=pr.start_scene
            self.current_room_id=pr.start_room_id if any(r.room_id==pr.start_room_id for r in pr.rooms) else (pr.rooms[0].room_id if pr.rooms else None)
            level_ids=sorted(self._level_sprites(self.current_level))
            self.current_sprite_id=level_ids[0] if level_ids else None
            self.current_object_id=sorted(pr.objects)[0] if pr.objects else None
            self.current_frame_index=0; self.current_event_index=None
            self.current_path_index=None; self.current_path_point_index=None
            self.project_path=Path(p); self.dirty=False; self._refresh_all()
        except Exception as e:
            messagebox.showerror("Open failed",str(e))

    # ---------------- refresh ----------------
    def _refresh_all(self):
        self.project_title_var.set(self.project.title); self.reu_var.set(self.project.expanded_memory); self.reu_kb_var.set(self.project.expanded_memory_kb)
        self.level_cb["values"]=[s.name for s in self.project.scenes]
        if self.current_level not in [s.name for s in self.project.scenes]:
            self.current_level=self.project.start_scene
        self.level_var.set(self.current_level)
        self._refresh_sprite_list(); self._refresh_sprite_fields()
        self._refresh_object_list(); self._refresh_object_fields()
        self._refresh_logic_objects(); self._refresh_event_list()
        self._refresh_scenes(); self._refresh_rooms(); self._refresh_variables(); self._refresh_paths(); self._refresh_tile_editor(); self._refresh_inventory()

    def _refresh_sprite_list(self):
        self.sprite_list.delete(0,"end")
        sprites=self._level_sprites()
        ids=sorted(sprites)
        for sid in ids:
            rtag="VIC" if getattr(sprites[sid],"renderer","software")=="vic" else "SW"
            self.sprite_list.insert("end",f"{sid:03d}: [{rtag}] {sprites[sid].name}")
        if self.current_sprite_id in ids:
            i=ids.index(self.current_sprite_id); self.sprite_list.selection_set(i); self.sprite_list.see(i)

    def _refresh_sprite_fields(self):
        self.level_tag_var.set(f"LEVEL: {self.current_level or '—'}")
        s=self.current_sprite()
        if not s:
            self._frame_syncing=True
            self.s_name.set("")
            self.s_mode.set("hires")
            self.s_width.set(8)
            self.s_height.set(8)
            self.s_storage.set("auto")
            self.s_bank.set(0)
            self.s_renderer.set("software")
            self.s_auto_animate.set(True); self.s_loop.set(True)
            self.f_name.set("")
            self.f_duration.set(6)
            self._frame_syncing=False
            self.frame_list.delete(0,"end")
            for w in self.paint_box.winfo_children():
                w.destroy()
            self.sprite_canvas.delete("all")
            self.sprite_info.set("No sprite selected. Click + Sprite to create the first sprite.")
            self.s_mode_cb.configure(state="readonly")
            for cb in self.color_cbs: cb.configure(state="readonly")
            return
        self.s_name.set(s.name); self.s_mode.set(s.mode); self.s_width.set(s.width); self.s_height.set(s.height)
        self.s_storage.set(s.storage); self.s_bank.set(s.bank); self.s_renderer.set(getattr(s,"renderer","software"))
        self.s_auto_animate.set(bool(getattr(s,"auto_animate",True))); self.s_loop.set(bool(getattr(s,"loop",True)))
        self.s_hires.set(s.colors.get("hires",1)); self.s_mc1.set(s.colors.get("mc1",5))
        self.s_mc2.set(s.colors.get("mc2",6)); self.s_local.set(s.colors.get("local",1))
        for cb,var in zip(self.color_cbs,[self.s_hires,self.s_mc1,self.s_mc2,self.s_local]):cb.current(var.get())

        self.s_renderer_cb.configure(state="readonly")
        if getattr(s,"renderer","software")=="vic":
            self.s_width_widget.configure(state="disabled")
            self.s_height_widget.configure(state="disabled")
        else:
            self.s_width_widget.configure(state="normal")
            self.s_height_widget.configure(state="normal")

        if s.sprite_id == 0:
            self.s_mode_cb.configure(state="readonly")
            for cb in self.color_cbs: cb.configure(state="readonly")
        else:
            master=self._level_sprites(s.level_id).get(0)
            if master:
                s.mode=master.mode
                s.colors["mc1"]=master.colors.get("mc1",s.colors.get("mc1",5))
                s.colors["mc2"]=master.colors.get("mc2",s.colors.get("mc2",6))
                self.s_mode.set(s.mode)
                self.s_mc1.set(s.colors["mc1"]); self.s_mc2.set(s.colors["mc2"])
                self.color_cbs[1].current(self.s_mc1.get()); self.color_cbs[2].current(self.s_mc2.get())
            self.s_mode_cb.configure(state="disabled")
            self.color_cbs[0].configure(state="readonly")
            self.color_cbs[1].configure(state="disabled")
            self.color_cbs[2].configure(state="disabled")
            self.color_cbs[3].configure(state="readonly")

        self._refresh_frames(); self._build_paint_buttons(); self._draw_sprite(); self._update_sprite_info()

    def _refresh_frames(self):
        s=self.current_sprite()
        self.frame_list.delete(0,"end")
        if not s:return
        for i,f in enumerate(s.frames):self.frame_list.insert("end",f"{i:03d}: {f.name}  [{f.duration}]")
        self.current_frame_index=min(self.current_frame_index,len(s.frames)-1)
        if s.frames:
            self.frame_list.selection_set(self.current_frame_index)
            self._frame_syncing=True
            f=s.frames[self.current_frame_index]
            self.f_name.set(f.name); self.f_duration.set(f.duration)
            self._frame_syncing=False

    def _refresh_object_list(self):
        self.object_list.delete(0,"end")
        ids=sorted(self.project.objects)
        for oid in ids:self.object_list.insert("end",f"{oid:03d}: {self.project.objects[oid].name}")
        if self.current_object_id in ids:
            i=ids.index(self.current_object_id); self.object_list.selection_set(i); self.object_list.see(i)

    def _refresh_object_fields(self):
        o=self.current_object()
        if not o:
            self.o_name.set("")
            self.o_sprite.set(0)
            self.o_x.set(80)
            self.o_y.set(80)
            self.o_scene.set(self.project.start_scene if self.project.scenes else "")
            self.o_active.set(True)
            if hasattr(self,"o_path"):
                self.o_path.set(""); self.o_path_enabled.set(False); self.o_path_cb["values"]=[""]
            if hasattr(self,"o_props"):
                for v in self.o_props:v.set(0)
            self.o_scene_cb["values"]=[s.name for s in self.project.scenes]
            self._refresh_object_room_choices()
            return
        self.o_name.set(o.name); self.o_sprite.set(o.sprite_id); self.o_x.set(o.x); self.o_y.set(o.y)
        self.o_scene.set(o.scene); self.o_room.set(o.room_id); self.o_active.set(o.active)
        if hasattr(self,"o_path"):
            choices=[""]+[p.name for p in self.project.paths if p.level_id==o.scene]
            self.o_path_cb["values"]=choices
            self.o_path.set(getattr(o,"path_name","") if getattr(o,"path_name","") in choices else "")
            self.o_path_enabled.set(bool(getattr(o,"path_enabled",False)))
        vals=(list(getattr(o,"properties",[0]*8))+[0]*8)[:8]
        if hasattr(self,"o_props"):
            for i,v in enumerate(self.o_props):v.set(int(vals[i])&255)
        self.o_scene_cb["values"]=[s.name for s in self.project.scenes]
        self._refresh_object_room_choices()

    def _refresh_logic_objects(self):
        ids=sorted(self.project.objects)
        self.logic_object_cb["values"]=[f"{oid:03d}: {self.project.objects[oid].name}" for oid in ids]
        if self.current_object_id in ids:
            self.logic_object_cb.current(ids.index(self.current_object_id))
        else:
            self.logic_object_cb.set("")

    def _refresh_event_list(self):
        self.event_list.delete(0,"end")
        o=self.current_object()
        if not o:return
        for i,e in enumerate(o.events):
            cond="" if e.get("condition","None")=="None" else f" IF {e.get('condition')} {e.get('condition_arg1','')} {e.get('condition_arg2','')}"
            actions=self._event_actions(e)
            first=actions[0] if actions else {"action":"","action_arg1":"","action_arg2":""}
            do_summary=f"{len(actions)} DO" if len(actions)==1 else f"{len(actions)} DOs"
            self.event_list.insert("end",
                f"{i:02d} WHEN {e.get('event')} {e.get('event_arg1','')} {e.get('event_arg2','')}{cond} "
                f"-> {do_summary}: {first.get('action')} {first.get('action_arg1','')} {first.get('action_arg2','')}")
        if self.current_event_index is not None and 0<=self.current_event_index<len(o.events):
            self.event_list.selection_set(self.current_event_index)
            self._load_event(o.events[self.current_event_index])

    def _refresh_scenes(self):
        self.scene_list.delete(0,"end")
        for s in self.project.scenes:self.scene_list.insert("end",s.name)
        self.o_scene_cb["values"]=[s.name for s in self.project.scenes]

    def _refresh_rooms(self):
        if not hasattr(self,"room_list"):return
        self._ensure_at_least_one_player_start()
        rooms=sorted(self.project.rooms,key=lambda r:r.room_id)
        self.room_list.delete(0,"end")
        for r in rooms:
            start_mark=" *START*" if r.room_id==self.project.start_room_id else ""
            self.room_list.insert("end",f"{r.room_id:03d}: {r.name} [{r.level_id}]{start_mark}")
        ids=[r.room_id for r in rooms]
        if self.current_room_id not in ids:self.current_room_id=ids[0] if ids else None
        if self.current_room_id in ids:
            i=ids.index(self.current_room_id); self.room_list.selection_set(i); self.room_list.see(i)
            room=self._room_by_id(self.current_room_id)
            self.room_id_var.set(room.room_id); self.room_name_var.set(room.name); self.room_level_var.set(room.level_id)
        else:
            self.room_id_var.set(0); self.room_name_var.set(""); self.room_level_var.set("")
        self.room_level_cb["values"]=[s.name for s in self.project.scenes]

        self.room_object_list.delete(0,"end")
        self.room_tile_list.delete(0,"end")
        self.room_object_place_list.delete(0,"end")
        room=self.current_room()
        if room:
            level_objects=self._level_objects(room.level_id)
            for oid,o in sorted(level_objects.items()):
                if oid==0:
                    current_room=self._room_by_id(o.room_id)
                    room_name=current_room.name if current_room else f"Room {o.room_id}"
                    suffix=f"[unique - currently {room_name}]"
                else:
                    count=sum(1 for inst in self.project.instances if inst.object_id==oid)
                    suffix=f"[reusable - {count} placed]"
                self.room_object_place_list.insert("end",f"{oid:03d}: {o.name}  {suffix}")
            if level_objects:
                if self.current_room_object_id not in level_objects:
                    self.current_room_object_id=sorted(level_objects)[0]
                obj_ids=sorted(level_objects)
                oi=obj_ids.index(self.current_room_object_id)
                self.room_object_place_list.selection_set(oi)
                self.room_object_place_list.see(oi)
                self.room_object_place_info.set(
                    f"Level {room.level_id}: {len(level_objects)} objects. "
                    f"Entry: {self._automatic_entry_description(room)}"
                )
            else:
                self.room_object_place_info.set(
                    f"No objects in level {room.level_id}. Create objects in the Objects tab first. "
                    f"Entry: {self._automatic_entry_description(room)}"
                )

            ts=self.project.tilesets.get(room.level_id)
            if ts and ts.tiles:
                self.room_tileset_info.set(
                    f"{ts.name}\n{len(ts.tiles)} tiles - "
                    f"{getattr(ts,'tile_width',8)}x{getattr(ts,'tile_height',8)} "
                    f"{getattr(ts,'mode','multicolor')}\n{ts.source_format}\n"
                    "Colors shown with this level's shared palette."
                )
                while len(ts.tile_collision)<len(ts.tiles):ts.tile_collision.append(0)
                while len(ts.tile_properties)<len(ts.tiles):ts.tile_properties.append([0,0,0,0])
                for tid in range(len(ts.tiles)):
                    ctag={0:"",1:" [SOLID]",2:" [HAZARD]"}.get(ts.tile_collision[tid],"")
                    vals=(list(ts.tile_properties[tid])+[0,0,0,0])[:4]
                    ptag=" " + " ".join(f"P{i}={v}" for i,v in enumerate(vals) if int(v)) if any(vals) else ""
                    self.room_tile_list.insert("end",f"{tid:03d}: Tile {tid}{ctag}{ptag}")
                if 0<=self.current_tile_id<len(ts.tiles):
                    self.room_tile_list.selection_set(self.current_tile_id)
                    self.room_tile_list.see(self.current_tile_id)
            else:
                self.room_tileset_info.set("No tileset loaded for this level.")
            o0=self.project.objects.get(0)
            if o0 and o0.room_id==room.room_id and o0.scene==room.level_id:
                self.room_object_list.insert("end",f"000: {o0.name} [unique]")
            for inst in sorted(self.project.instances,key=lambda i:i.instance_id):
                if inst.room_id==room.room_id and inst.level_id==room.level_id:
                    o=self.project.objects.get(inst.object_id)
                    if o:
                        vals=(list(getattr(inst,"properties",[0]*8))+[0]*8)[:8]
                        ptag=" " + " ".join(f"P{i}={v}" for i,v in enumerate(vals) if int(v)) if any(vals) else ""
                        self.room_object_list.insert("end",f"{inst.object_id:03d}#{inst.instance_id}: {o.name}  Z={int(getattr(inst,'z_order',0))}{ptag}")
            level=next((s for s in self.project.scenes if s.name==room.level_id),None)
            if level:
                self.room_inherited_var.set(
                    f"Level: {level.name}\nMode: {level.display_mode}\n"
                    f"Background: {level.background_color} ({C64_PALETTE[level.background_color][0]})\n"
                    f"MC1: {level.mc1} ({C64_PALETTE[level.mc1][0]})\n"
                    f"MC2: {level.mc2} ({C64_PALETTE[level.mc2][0]})\n"
                    f"Local default: {level.local} ({C64_PALETTE[level.local][0]})\n\n"
                    "Room colors are inherited from the level."
                )
        else:self.room_inherited_var.set("No room selected.")
        self.after_idle(self._draw_room)

    def _refresh_variables(self):
        self.var_list.delete(0,"end")
        for v in self.project.variables:self.var_list.insert("end",f"{v.name} = {v.initial}")

    # ---------------- sprite operations ----------------
    def add_sprite(self):
        sprites=self._level_sprites()
        avail=[i for i in range(256) if i not in sprites]
        if not avail:return messagebox.showwarning("Sprite limit","All 256 sprite IDs are used in this level.")
        initial=0 if 0 in avail else avail[0]
        sid=simpledialog.askinteger("Add Sprite",f"Sprite ID 0-255 for level '{self.current_level}'",initialvalue=initial,minvalue=0,maxvalue=255)
        if sid is None:return
        if sid in sprites:return messagebox.showerror("ID used","That sprite ID already exists in this level.")
        if sid!=0 and 0 not in sprites:
            return messagebox.showwarning("Create Sprite 0 first","Each level needs Sprite 0 first. Sprite 0 defines the graphics mode and shared color defaults for new sprites in that level.")
        self._ensure_sprite(sid,self.current_level)
        self.current_sprite_id=sid; self.current_frame_index=0; self.dirty=True; self._refresh_all()

    def delete_sprite(self):
        self.stop_animation_preview()
        s=self.current_sprite()
        if not s:return

        level_sprites=self._level_sprites(s.level_id)
        users=[o for o in self.project.objects.values()
               if o.sprite_id==s.sprite_id and getattr(o,"sprite_level",o.scene)==s.level_id]

        if s.sprite_id==0:
            # Sprite 0 is the level master. Deleting it while a level exists
            # would break inherited mode/shared colors, so make Delete perform
            # a deliberate reset to a clean default master instead of silently
            # refusing to work.
            if not messagebox.askyesno(
                "Reset Sprite 0",
                "Sprite 0 is the required level master.\n\n"
                "Reset it to a blank Software/Multicolor Sprite 0? "
                "Objects assigned to Sprite 0 will remain assigned to it."
            ):
                return
            scene=next((x for x in self.project.scenes if x.name==s.level_id),None)
            mc1=(scene.mc1 if scene else 6); mc2=(scene.mc2 if scene else 1)
            s.name="Sprite 0"
            s.renderer="software"; s.mode="multicolor"; s.width=8; s.height=4
            s.colors={"hires":1,"mc1":mc1,"mc2":mc2,"local":(scene.local if scene else 7)}
            s.source_format=""
            s.frames=[Frame(name="Frame 1",pixels=blank_pixels("multicolor",8,4))]
            if scene:
                scene.display_mode="multicolor"
                scene.mc1=mc1;scene.mc2=mc2
            # Nonzero sprites inherit the shared mode/colors from Sprite 0.
            for sid,other in level_sprites.items():
                if sid==0:continue
                other.mode="multicolor"
                other.colors["mc1"]=mc1;other.colors["mc2"]=mc2
            self.current_frame_index=0
            self.dirty=True
            self._refresh_all()
            self.status.set("Sprite 0 reset to blank Software/Multicolor master.")
            return

        replacement=level_sprites.get(0)
        if users:
            if replacement is None:
                return messagebox.showwarning(
                    "Sprite in use",
                    "This sprite is assigned to objects and the level has no Sprite 0 to reassign them to."
                )
            if not messagebox.askyesno(
                "Delete Sprite",
                f"Sprite {s.sprite_id} is used by {len(users)} object(s).\n\n"
                "Delete it and reassign those objects to Sprite 0?"
            ):
                return
            for o in users:
                o.sprite_id=0
                o.sprite_level=s.level_id
        else:
            if not messagebox.askyesno("Delete",f"Delete sprite {s.sprite_id}?"):return

        del self.project.sprites[self._sprite_key(s.level_id,s.sprite_id)]
        ids=sorted(self._level_sprites(s.level_id))
        self.current_sprite_id=ids[0] if ids else None
        self.current_frame_index=0
        self.dirty=True
        self._refresh_all()
        self.status.set(f"Deleted Sprite {s.sprite_id}.")

    def _on_sprite_select(self,e=None):
        self.stop_animation_preview()
        sel=self.sprite_list.curselection()
        if not sel:return
        self.current_sprite_id=int(self.sprite_list.get(sel[0]).split(":",1)[0]); self.current_frame_index=0; self._refresh_sprite_fields()

    def _software_compatible_size(self,mode,w,h):
        w=max(1,int(w)); h=max(1,int(h))
        if mode=="hires":
            w=max(8,((w+7)//8)*8)
            h=max(8,((h+7)//8)*8)
        else:
            w=max(8,((w+3)//4)*4)
            h=max(4,((h+3)//4)*4)
        return w,h

    def _ask_vic_conversion(self,s):
        """Return duplicate, convert, or cancel before destructive VIC sizing."""
        result={"value":"cancel"}
        win=tk.Toplevel(self); win.title("Convert Software Sprite to VIC-II?"); win.transient(self); win.grab_set(); win.resizable(False,False)
        body=ttk.Frame(win,padding=14); body.pack(fill="both",expand=True)
        ttk.Label(body,text="VIC-II conversion changes sprite geometry",font=("",11,"bold")).pack(anchor="w")
        ttk.Label(body,justify="left",wraplength=540,text=(
            f"Sprite {s.sprite_id} is currently a {s.width}x{s.height} software sprite.\n\n"
            "A VIC-II sprite has a fixed 24x21 physical size (12x21 logical pixels in multicolor). "
            "Converting can resize or discard artwork and can make existing room placements overlap "
            "solid tiles or other objects. Switching back to Software will not restore the original.\n\n"
            "Duplicate and Convert preserves this software sprite and creates a separate VIC-II copy."
        )).pack(anchor="w",pady=(8,12))
        buttons=ttk.Frame(body); buttons.pack(fill="x")
        def choose(value):result["value"]=value;win.destroy()
        recommended=ttk.Button(buttons,text="Duplicate and Convert (Recommended)",command=lambda:choose("duplicate"))
        recommended.pack(side="left")
        ttk.Button(buttons,text="Convert Original",command=lambda:choose("convert")).pack(side="left",padx=6)
        ttk.Button(buttons,text="Cancel",command=lambda:choose("cancel")).pack(side="right")
        win.protocol("WM_DELETE_WINDOW",lambda:choose("cancel")); recommended.focus_set()
        win.update_idletasks()
        win.geometry(f"+{self.winfo_rootx()+max(20,(self.winfo_width()-win.winfo_reqwidth())//2)}+{self.winfo_rooty()+max(20,(self.winfo_height()-win.winfo_reqheight())//3)}")
        self.wait_window(win)
        return result["value"]

    def _sprite_renderer_changed(self,event=None):
        s=self.current_sprite()
        if not s:return
        renderer=self.s_renderer.get()
        mode=self.s_mode.get()
        if renderer=="vic" and getattr(s,"renderer","software")!="vic":
            original_id=s.sprite_id
            choice=self._ask_vic_conversion(s)
            if choice=="cancel":
                self.s_renderer.set("software"); self._refresh_sprite_fields(); return
            if choice=="duplicate":
                import copy
                sprites=self._level_sprites(s.level_id); available=[i for i in range(256) if i not in sprites]
                if not available:
                    self.s_renderer.set("software")
                    return messagebox.showwarning("Sprite limit","No free sprite ID is available for the VIC-II copy.")
                sid=available[0]; duplicate=copy.deepcopy(s); duplicate.sprite_id=sid; duplicate.name=f"{s.name} VIC"
                self.project.sprites[self._sprite_key(s.level_id,sid)]=duplicate
                self.current_sprite_id=sid; self.current_frame_index=0; s=duplicate
                self.status.set(f"Preserved software Sprite {original_id} and created VIC-II Sprite {sid}.")
            self._vic_conversion_confirmed=True
        if renderer=="vic":
            self.s_width.set(24 if mode=="hires" else 12)
            self.s_height.set(21)
            self.s_width_widget.configure(state="disabled")
            self.s_height_widget.configure(state="disabled")
        else:
            # A VIC sprite can have geometry that is illegal for the software
            # renderer (especially 21-pixel height, or 12-wide MC artwork if
            # the level master forces hires). Convert to the nearest legal
            # software dimensions before committing the renderer change.
            master=self._level_sprites(s.level_id).get(0)
            if s.sprite_id!=0 and master:
                mode=master.mode
                self.s_mode.set(mode)
            w,h=self._software_compatible_size(mode,self.s_width.get(),self.s_height.get())
            self.s_width.set(w); self.s_height.set(h)
            self.s_width_widget.configure(state="normal")
            self.s_height_widget.configure(state="normal")

        # VER 08.21: renderer selection is a real setting, not merely a pending
        # form value.  Previously the combobox changed visually but the Sprite
        # model remained unchanged until Apply Sprite Properties was clicked.
        # Project save / ASM generation therefore continued to emit the old
        # renderer, which made a visually-selected Software sprite compile as
        # a VIC sprite.  Commit the selection immediately through the normal
        # validation/apply path so the editor UI, saved project and generator
        # cannot disagree.
        self.apply_sprite_props()
        s=self.current_sprite()
        if s:
            self.status.set(
                f"Renderer applied: {getattr(s,'renderer','software').upper()} - "
                f"generator will emit {'VIC' if getattr(s,'renderer','software')=='vic' else 'SOFTWARE'}."
            )

    def apply_sprite_props(self):
        s=self.current_sprite()
        if not s:
            return messagebox.showwarning("No sprite","Create or select a sprite first.")
        mode=self.s_mode.get(); w=int(self.s_width.get()); h=int(self.s_height.get())
        renderer=self.s_renderer.get()

        # Resolve the level's inherited mode before deciding legal geometry.
        # VER 07.0 did this in the opposite order, so a 12-wide VIC MC sprite
        # could be changed to hires by Sprite 0 and then immediately fail the
        # software width-divisibility test.
        if s.sprite_id != 0:
            master=self._level_sprites(s.level_id).get(0)
            if master:
                mode=master.mode
                self.s_mode.set(mode)

        if renderer=="vic":
            w=24 if mode=="hires" else 12
            h=21
            self.s_width.set(w); self.s_height.set(h)
        elif getattr(s,"renderer","software")=="vic":
            w,h=self._software_compatible_size(mode,w,h)
            self.s_width.set(w); self.s_height.set(h)

        if renderer!="vic":
            if mode=="hires" and (w<8 or w%8):
                return messagebox.showerror("Width","Hires width must be >=8 and divisible by 8.")
            if mode=="multicolor" and (w<8 or w%4):
                return messagebox.showerror("Width","Multicolor width must be >=8 and divisible by 4.")
            if mode=="hires" and (h<8 or h%8):return messagebox.showerror("Height","Hires height must be >=8 and divisible by 8.")
            if mode=="multicolor" and (h<4 or h%4):return messagebox.showerror("Height","Multicolor height must be >=4 and divisible by 4.")
        if self.s_storage.get()=="expanded_memory" and not self.project.expanded_memory:return messagebox.showerror("REU disabled","Enable expanded memory first.")
        if (mode,w,h)!=(s.mode,s.width,s.height):
            # Padding a frame to a larger compatible software size is lossless,
            # so do not force a confirmation merely for VIC -> Software.
            # Shrinking or changing pixel mode can discard/convert pixels and
            # still requires explicit confirmation.
            lossless_padding=(mode==s.mode and w>=s.width and h>=s.height)
            already_confirmed=bool(getattr(self,"_vic_conversion_confirmed",False) and renderer=="vic")
            if not lossless_padding and not already_confirmed and not messagebox.askyesno("Resize","Resize all frames? Pixels outside the new bounds are discarded."):return
            for f in s.frames:
                old=f.pixels; new=blank_pixels(mode,w,h)
                for y in range(min(h,len(old))):
                    for x in range(min(w,len(old[y]))):
                        v=old[y][x]; new[y][x]=(1 if mode=="hires" and v else min(3,v))
                f.pixels=new
        s.name=self.s_name.get().strip() or f"Sprite {s.sprite_id}"
        s.mode=mode; s.width=w; s.height=h; s.storage=self.s_storage.get(); s.bank=int(self.s_bank.get())
        s.renderer=renderer; s.auto_animate=bool(self.s_auto_animate.get()); s.loop=bool(self.s_loop.get())
        self._vic_conversion_confirmed=False
        if s.sprite_id==0:
            scene=next((x for x in self.project.scenes if x.name==s.level_id),None)
            if scene:
                scene.display_mode=s.mode
                scene.mc1=s.colors.get("mc1",scene.mc1)
                scene.mc2=s.colors.get("mc2",scene.mc2)
                scene.local=s.colors.get("local",scene.local)
        self.dirty=True; self._refresh_all()

    def _sprite_colors_changed(self):
        s=self.current_sprite()
        if not s:
            return
        if s.sprite_id==0:
            s.colors={"hires":self.s_hires.get(),"mc1":self.s_mc1.get(),"mc2":self.s_mc2.get(),"local":self.s_local.get()}
            scene=next((x for x in self.project.scenes if x.name==s.level_id),None)
            if scene:
                scene.mc1=s.colors["mc1"]; scene.mc2=s.colors["mc2"]; scene.local=s.colors["local"]
        else:
            master=self._level_sprites(s.level_id).get(0)
            s.colors["hires"]=self.s_hires.get()
            s.colors["local"]=self.s_local.get()
            if master:
                s.colors["mc1"]=master.colors.get("mc1",5)
                s.colors["mc2"]=master.colors.get("mc2",6)
                self.s_mc1.set(s.colors["mc1"]); self.s_mc2.set(s.colors["mc2"])
        self.dirty=True; self._build_paint_buttons(); self._draw_sprite()

    def _build_paint_buttons(self):
        for w in self.paint_box.winfo_children():w.destroy()
        s=self.current_sprite()
        if not s:
            return
        vals=[(0,"Transparent",0)]
        if s.mode=="hires":vals.append((1,f"Foreground ({s.colors['hires']})",s.colors["hires"]))
        else:
            vals += [(1,f"MC1 ({s.colors['mc1']})",s.colors["mc1"]),
                     (2,f"MC2 ({s.colors['mc2']})",s.colors["mc2"]),
                     (3,f"Local ({s.colors['local']})",s.colors["local"])]
        for v,lab,cidx in vals:
            kw={}
            if v:kw["bg"]=C64_PALETTE[cidx][1]
            tk.Button(self.paint_box,text=lab,width=18,command=lambda n=v:self._set_paint(n),**kw).pack(side="left",padx=3,pady=3)

    def _set_paint(self,n):
        self.current_tool_value=n; self.status.set(f"Paint value {n}")

    def _sprite_canvas_zoom_wheel(self,event,direction=None):
        if not self.current_sprite():return "break"
        if direction is None:
            direction=1 if getattr(event,"delta",0)>0 else -1
        old=max(8,min(64,int(self.zoom_var.get())))
        new=max(8,min(64,old+(2 if direction>0 else -2)))
        if new==old:return "break"

        # Preserve the point under the mouse as closely as Tk Canvas allows.
        cx=self.sprite_canvas.canvasx(getattr(event,"x",0))
        cy=self.sprite_canvas.canvasy(getattr(event,"y",0))
        xfrac=(cx/max(1,self.sprite_canvas.bbox("all")[2] if self.sprite_canvas.bbox("all") else 1))
        yfrac=(cy/max(1,self.sprite_canvas.bbox("all")[3] if self.sprite_canvas.bbox("all") else 1))
        self.zoom_var.set(new)
        self._draw_sprite()
        self.sprite_canvas.xview_moveto(max(0,min(1,xfrac)))
        self.sprite_canvas.yview_moveto(max(0,min(1,yfrac)))
        self.status.set(f"Sprite zoom {new} px")
        return "break"

    def _paint_sprite(self,e,value):
        s=self.current_sprite(); f=self.current_frame()
        if not s or not f:
            return
        z=max(8,int(self.zoom_var.get())); xs=2 if s.mode=="multicolor" else 1
        x=int(self.sprite_canvas.canvasx(e.x)//(z*xs)); y=int(self.sprite_canvas.canvasy(e.y)//z)
        if 0<=x<s.width and 0<=y<s.height:
            f.pixels[y][x]=(1 if s.mode=="hires" and value else value)
            self.dirty=True; self._draw_sprite()

    def _draw_sprite(self):
        self.sprite_canvas.delete("all")
        s=self.current_sprite(); f=self.current_frame()
        if not s or not f:return
        z=max(8,int(self.zoom_var.get())); xs=2 if s.mode=="multicolor" else 1
        for y,row in enumerate(f.pixels):
            for x,v in enumerate(row):
                if v==0:fill="#1d1d1d"
                elif s.mode=="hires":fill=C64_PALETTE[s.colors["hires"]][1]
                else:fill=C64_PALETTE[s.colors[{1:"mc1",2:"mc2",3:"local"}[v]]][1]
                x0=x*z*xs; y0=y*z
                self.sprite_canvas.create_rectangle(x0,y0,x0+z*xs,y0+z,fill=fill,outline="#444")
        self.sprite_canvas.configure(scrollregion=(0,0,s.width*z*xs,s.height*z))

    def add_frame(self):
        self.stop_animation_preview()
        s=self.current_sprite()
        if not s:
            return messagebox.showwarning("No sprite","Create or select a sprite first.")
        s.frames.append(Frame(name=f"Frame {len(s.frames)+1}",pixels=blank_pixels(s.mode,s.width,s.height)))
        self.current_frame_index=len(s.frames)-1; self.dirty=True; self._refresh_frames(); self._draw_sprite()

    def duplicate_frame(self):
        self.stop_animation_preview()
        s=self.current_sprite(); f=self.current_frame()
        if not s or not f:
            return messagebox.showwarning("No frame","Create or select a sprite frame first.")
        s.frames.insert(self.current_frame_index+1,Frame(name=f"{f.name} Copy",duration=f.duration,pixels=[r[:] for r in f.pixels]))
        self.current_frame_index+=1; self.dirty=True; self._refresh_frames(); self._draw_sprite()

    def delete_frame(self):
        self.stop_animation_preview()
        s=self.current_sprite()
        if not s:
            return messagebox.showwarning("No sprite","Create or select a sprite first.")
        if len(s.frames)<=1:return messagebox.showwarning("Required","A sprite needs at least one frame.")
        del s.frames[self.current_frame_index]; self.current_frame_index=max(0,self.current_frame_index-1)
        self.dirty=True; self._refresh_frames(); self._draw_sprite()

    def toggle_animation_preview(self):
        if self.animation_preview_running:
            self.stop_animation_preview()
        else:
            self.start_animation_preview()

    def start_animation_preview(self):
        s=self.current_sprite()
        if not s or not s.frames:
            return messagebox.showwarning("No animation","Create or select a sprite with at least one frame first.")
        self.stop_animation_preview()
        self.animation_preview_running=True
        self.animation_play_button.configure(text="Stop")
        self._schedule_animation_preview_frame()

    def stop_animation_preview(self):
        self.animation_preview_running=False
        if getattr(self,"animation_preview_after_id",None):
            try:
                self.after_cancel(self.animation_preview_after_id)
            except Exception:
                pass
            self.animation_preview_after_id=None
        if hasattr(self,"animation_play_button"):
            self.animation_play_button.configure(text="Play")

    def _schedule_animation_preview_frame(self):
        if not self.animation_preview_running:
            return
        s=self.current_sprite()
        if not s or not s.frames:
            self.stop_animation_preview()
            return

        self.current_frame_index=max(0,min(self.current_frame_index,len(s.frames)-1))
        self._refresh_frames()
        self._draw_sprite()

        # Frame duration uses C64-style ticks. Preview assumes ~60 Hz:
        # 1 tick ~= 16.67 ms, with a small floor for UI responsiveness.
        f=s.frames[self.current_frame_index]
        delay=max(16,int(max(1,f.duration) * (1000/60)))

        self.current_frame_index += 1
        if self.current_frame_index >= len(s.frames):
            if s.loop:
                self.current_frame_index=0
            else:
                self.current_frame_index=len(s.frames)-1
                self.stop_animation_preview()
                self._refresh_frames()
                self._draw_sprite()
                return

        self.animation_preview_after_id=self.after(delay,self._schedule_animation_preview_frame)

    def _step_frame(self,d):
        self.stop_animation_preview()
        s=self.current_sprite()
        if not s or not s.frames:
            return
        self.current_frame_index=(self.current_frame_index+d)%len(s.frames)
        self._refresh_frames(); self._draw_sprite()

    def _on_frame_select(self,e=None):
        self.stop_animation_preview()
        sel=self.frame_list.curselection()
        if not sel:return
        self.current_frame_index=sel[0]; self._refresh_frames(); self._draw_sprite()

    def _frame_live_changed(self):
        if self._frame_syncing:return
        f=self.current_frame()
        if not f:return
        try:d=max(1,min(255,int(self.f_duration.get())))
        except:return
        f.name=self.f_name.get().strip() or f"Frame {self.current_frame_index+1}"
        f.duration=d; self.dirty=True
        if self.frame_list.size()>self.current_frame_index:
            self.frame_list.delete(self.current_frame_index)
            self.frame_list.insert(self.current_frame_index,f"{self.current_frame_index:03d}: {f.name}  [{f.duration}]")
            self.frame_list.selection_set(self.current_frame_index)

    def _update_sprite_info(self):
        s=self.current_sprite()
        if not s:
            self.sprite_info.set("No sprite selected. Click + Sprite to create the first sprite.")
            return
        role = "Level template/master" if s.sprite_id==0 else "Uses Sprite 0 shared mode/colors"
        renderer=getattr(s,"renderer","software")
        if renderer=="vic":
            render_note="VIC-II hardware sprite; raster multiplexer supports up to 16 active VIC objects when vertical spacing permits"
        else:
            render_note="Software bitmap sprite; unlimited definitions, CPU cost scales with redraw work"
        self.sprite_info.set(
            f"Level tag: {s.level_id}\nSprite ID: {s.sprite_id}\nRole: {role}\n"
            f"Renderer: {renderer.upper()}\n{render_note}\nFrames: {len(s.frames)}\n"
            f"Storage: {s.storage}\nLevel sprites: {len(self._level_sprites())}/256"
        )

    # ---------------- objects ----------------
    def add_object(self):
        room=self.current_room()
        if not room:
            return messagebox.showwarning("Create a room first","Create/select a room before adding game objects.")
        self.current_level=room.level_id
        if not self._level_sprites(room.level_id):
            return messagebox.showwarning("Create a sprite first","A game object must reference a sprite in the room's level. Create Sprite 0 first.")
        avail=[i for i in range(256) if i not in self.project.objects]
        if not avail:return messagebox.showwarning("Object limit","All 256 object IDs are used.")
        oid=simpledialog.askinteger("Add Object","Object ID 0-255",initialvalue=avail[0],minvalue=0,maxvalue=255)
        if oid is None:return
        if oid in self.project.objects:return messagebox.showerror("ID used","That object ID already exists.")
        self._ensure_object(oid); self.current_object_id=oid; self.current_event_index=None; self.dirty=True; self._refresh_all()

    def delete_object(self):
        o=self.current_object()
        if not o:
            return
        if not messagebox.askyesno("Delete",f"Delete object {self.current_object_id}?"):return
        doomed=self.current_object_id
        del self.project.objects[doomed]
        self.project.instances=[i for i in self.project.instances if i.object_id!=doomed]
        for r in self.project.rooms:
            if r.player_start_enabled and r.player_start_object_id==doomed:r.player_start_enabled=False
        self.current_object_id=sorted(self.project.objects)[0] if self.project.objects else None
        self.current_event_index=None
        self.dirty=True
        self._refresh_all()

    def _on_object_select(self,e=None):
        sel=self.object_list.curselection()
        if not sel:return
        self.current_object_id=int(self.object_list.get(sel[0]).split(":",1)[0])
        self.current_event_index=None; self._refresh_object_fields(); self._refresh_logic_objects(); self._refresh_event_list()

    def apply_object_props(self):
        o=self.current_object()
        if not o:
            return messagebox.showwarning("No object","Create or select an object first.")
        sid=int(self.o_sprite.get())
        target_level=self.o_scene.get() or self.current_level
        room_text=self.o_room_cb.get()
        try:target_room=int(room_text.split(":",1)[0])
        except:return messagebox.showerror("Room","Choose a room in the selected level.")
        if target_room not in [r.room_id for r in self._rooms_for_level(target_level)]:
            return messagebox.showerror("Room","That room does not belong to the selected level.")
        if sid not in self._level_sprites(target_level):return messagebox.showerror("Sprite","That sprite ID does not exist in the object's level.")
        o.sprite_level=target_level
        o.name=self.o_name.get().strip() or f"Object {o.object_id}"
        o.sprite_id=sid; o.x=int(self.o_x.get()); o.y=int(self.o_y.get())
        o.scene=target_level; o.room_id=target_room; o.active=bool(self.o_active.get())
        o.properties=[max(0,min(255,int(v.get()))) for v in self.o_props]
        o.path_name=self.o_path.get().strip() if hasattr(self,"o_path") else ""
        o.path_enabled=bool(self.o_path_enabled.get()) if hasattr(self,"o_path_enabled") else False
        if o.path_name and not any(p.name==o.path_name and p.level_id==target_level for p in self.project.paths):
            return messagebox.showerror("Path","Choose a path that belongs to the object's level.")
        self.dirty=True; self._refresh_all()

    # ---------------- visual logic ----------------
    def _logic_object_changed(self,e=None):
        txt=self.logic_object_cb.get()
        if not txt:return
        self.current_object_id=int(txt.split(":",1)[0]); self.current_event_index=None; self.current_action_index=0
        self._refresh_object_list(); self._refresh_object_fields(); self._refresh_event_list()

    def _event_actions(self,event):
        actions=event.get("actions")
        if isinstance(actions,list) and actions:
            return actions
        return [{
            "action":event.get("action","Move X"),
            "action_arg1":event.get("action_arg1",""),
            "action_arg2":event.get("action_arg2",""),
        }]

    def _normalize_event_actions(self,event):
        actions=self._event_actions(event)
        event["actions"]=[{
            "action":a.get("action","Move X"),
            "action_arg1":a.get("action_arg1",""),
            "action_arg2":a.get("action_arg2",""),
        } for a in actions]
        # Keep the first DO mirrored into legacy fields for older generated/project tooling.
        first=event["actions"][0]
        event["action"]=first["action"]
        event["action_arg1"]=first["action_arg1"]
        event["action_arg2"]=first["action_arg2"]
        return event["actions"]

    def _refresh_do_list(self):
        if not hasattr(self,"do_list"):return
        self.do_list.delete(0,"end")
        o=self.current_object()
        if not o or self.current_event_index is None or not (0<=self.current_event_index<len(o.events)):
            return
        actions=self._normalize_event_actions(o.events[self.current_event_index])
        for i,a in enumerate(actions):
            self.do_list.insert("end",f"{i+1:02d}  {a.get('action','')} | {a.get('action_arg1','')} | {a.get('action_arg2','')}")
        if actions:
            self.current_action_index=max(0,min(self.current_action_index,len(actions)-1))
            self.do_list.selection_set(self.current_action_index)
            self.do_list.see(self.current_action_index)

    def _on_do_select(self,e=None):
        sel=self.do_list.curselection()
        if not sel:return
        self.current_action_index=sel[0]
        o=self.current_object()
        if not o or self.current_event_index is None:return
        actions=self._normalize_event_actions(o.events[self.current_event_index])
        if 0<=self.current_action_index<len(actions):
            a=actions[self.current_action_index]
            self.e_action.set(a.get("action","Move X"))
            self.e_action_a.set(a.get("action_arg1",""))
            self.e_action_b.set(a.get("action_arg2",""))
            self._update_logic_arg_choices()

    def add_do(self):
        o=self.current_object()
        if not o or self.current_event_index is None:
            return messagebox.showwarning("Select event","Select or add a visual event first.")
        actions=self._normalize_event_actions(o.events[self.current_event_index])
        actions.append({"action":"Move X","action_arg1":"0","action_arg2":""})
        self.current_action_index=len(actions)-1
        self.dirty=True
        self._refresh_do_list()
        self._on_do_select()

    def delete_do(self):
        o=self.current_object()
        if not o or self.current_event_index is None:return
        actions=self._normalize_event_actions(o.events[self.current_event_index])
        if len(actions)<=1:
            return messagebox.showwarning("DO required","Each visual event block must keep at least one DO action.")
        if not (0<=self.current_action_index<len(actions)):return
        del actions[self.current_action_index]
        self.current_action_index=max(0,min(self.current_action_index,len(actions)-1))
        first=actions[0]
        o.events[self.current_event_index]["action"]=first["action"]
        o.events[self.current_event_index]["action_arg1"]=first["action_arg1"]
        o.events[self.current_event_index]["action_arg2"]=first["action_arg2"]
        self.dirty=True
        self._refresh_event_list()

    def move_do(self,direction):
        o=self.current_object()
        if not o or self.current_event_index is None:return
        actions=self._normalize_event_actions(o.events[self.current_event_index])
        old=self.current_action_index
        new=old+direction
        if not (0<=old<len(actions) and 0<=new<len(actions)):return
        actions[old],actions[new]=actions[new],actions[old]
        self.current_action_index=new
        first=actions[0]
        o.events[self.current_event_index]["action"]=first["action"]
        o.events[self.current_event_index]["action_arg1"]=first["action_arg1"]
        o.events[self.current_event_index]["action_arg2"]=first["action_arg2"]
        self.dirty=True
        self._refresh_event_list()

    def add_event(self):
        o=self.current_object()
        if not o:
            return messagebox.showwarning("No object","Create or select an object first.")
        o.events.append({"event":"Every Frame","event_arg1":"","event_arg2":"",
                         "condition":"None","condition_arg1":"","condition_arg2":"",
                         "action":"Move X","action_arg1":"1","action_arg2":"",
                         "actions":[{"action":"Move X","action_arg1":"1","action_arg2":""}]})
        self.current_event_index=len(o.events)-1
        self.current_action_index=0
        self.dirty=True
        self._refresh_event_list()

    def delete_event(self):
        o=self.current_object()
        if not o or self.current_event_index is None:return
        del o.events[self.current_event_index]; self.current_event_index=None; self.dirty=True; self._refresh_event_list()

    def _on_event_select(self,e=None):
        sel=self.event_list.curselection()
        if not sel:return
        self.current_event_index=sel[0]; self.current_action_index=0
        self._load_event(self.current_object().events[self.current_event_index])

    def _logic_object_id_choices(self):
        return [str(i) for i in sorted(self.project.objects)]

    def _logic_sprite_id_choices(self):
        return [str(i) for i in sorted({s.sprite_id for s in self.project.sprites.values()})]

    def _logic_variable_choices(self):
        return [v.name for v in self.project.variables]

    def _update_logic_arg_choices(self):
        if not hasattr(self,"e_cond_a_cb"):return
        # Editable comboboxes retain manual numeric entry, while common values
        # are discoverable in dropdowns.
        event=self.e_event.get()
        cond=self.e_cond.get()
        action=self.e_action.get()

        self.e_event_a_cb["values"]=()
        self.e_event_b_cb["values"]=()
        self.e_cond_a_cb["values"]=()
        self.e_cond_b_cb["values"]=()
        self.e_action_a_cb["values"]=()
        self.e_action_b_cb["values"]=()

        if event in ("Keyboard Held","Keyboard Pressed","Keyboard Pressed Over Topmost Object"):
            self.e_event_a_cb["values"]=["A","D","W","S","SPACE","LEFT","RIGHT","UP","DOWN"]
        elif event=="Keyboard Pressed Over Object":
            self.e_event_a_cb["values"]=["A","D","W","S","SPACE","LEFT","RIGHT","UP","DOWN"]
            self.e_event_b_cb["values"]=self._logic_object_id_choices()
        elif event=="Collision With Object":
            self.e_event_a_cb["values"]=self._logic_object_id_choices()
        elif event=="Collision With Topmost Object":
            self.e_event_a_cb["values"]=["Any"]
        elif event=="Collision With Sprite":
            self.e_event_a_cb["values"]=self._logic_sprite_id_choices()
        elif event=="Tile Collision":
            self.e_event_a_cb["values"]=["Any","Solid","Hazard"]
        elif event=="Tile Property Equals":
            self.e_event_a_cb["values"]=["0","1","2","3"]
            self.e_event_b_cb["values"]=[str(i) for i in range(0,256,16)]
        elif event.startswith("Variable "):
            self.e_event_a_cb["values"]=self._logic_variable_choices()
        elif event=="Path Finished":
            pass

        if cond.startswith("Self Property ") or cond.startswith("Other Property "):
            self.e_cond_a_cb["values"]=OBJECT_PROPERTIES
            if cond.endswith(" Variable"):
                self.e_cond_b_cb["values"]=self._logic_variable_choices()
            elif cond.endswith(" Other Property"):
                self.e_cond_b_cb["values"]=OBJECT_PROPERTIES
        elif cond=="Self Touching Tile":
            self.e_cond_a_cb["values"]=["Any","Solid","Hazard"]
        elif cond=="Self Overlaps Topmost Object":
            pass
        elif cond in ("Self Tile Property Equals","Self Center Tile Property Equals"):
            self.e_cond_a_cb["values"]=["0","1","2","3"]
            self.e_cond_b_cb["values"]=[str(i) for i in range(0,256,16)]
        elif cond=="Self Tile Ahead Is":
            self.e_cond_a_cb["values"]=["Up","Right","Down","Left"]
            self.e_cond_b_cb["values"]=["Empty","Solid","Hazard","Any"]
        elif cond=="Self Aligned To Tile":
            self.e_cond_a_cb["values"]=["Both","X","Y"]
        elif cond in ("Inventory Contains Item","Inventory Quantity At Least"):
            self.e_cond_a_cb["values"]=[str(i.item_id) for i in sorted(self.project.inventory.items,key=lambda x:x.item_id)]
            self.e_cond_b_cb["values"]=["1","2","5","10","25","50","99"]
        elif cond=="Inventory Slot Equals":
            self.e_cond_a_cb["values"]=[str(i) for i in range(self.project.inventory.slot_count)]
            self.e_cond_b_cb["values"]=["255"]+[str(i.item_id) for i in sorted(self.project.inventory.items,key=lambda x:x.item_id)]
        elif cond.startswith("Variable "):
            self.e_cond_a_cb["values"]=self._logic_variable_choices()
        elif cond=="Self Does Not Overlap Object":
            self.e_cond_a_cb["values"]=self._logic_object_id_choices()+["1-7"]
        elif cond.startswith("Object "):
            self.e_cond_a_cb["values"]=[""]+self._logic_object_id_choices()

        if action in ("Set Self Property","Add To Self Property","Set Other Property","Add To Other Property"):
            self.e_action_a_cb["values"]=SETTABLE_OBJECT_PROPERTIES
        elif action in ("Set Variable","Add To Variable","Set Variable Random"):
            self.e_action_a_cb["values"]=self._logic_variable_choices()
        elif action in ("Set Variable From Self Property","Set Variable From Other Property"):
            self.e_action_a_cb["values"]=self._logic_variable_choices()
            self.e_action_b_cb["values"]=OBJECT_PROPERTIES
        elif action in ("Set Frame From Self Property","Set Frame From Other Property"):
            self.e_action_a_cb["values"]=OBJECT_PROPERTIES
        elif action in ("Set Other Property From Self Property","Set Self Property From Other Property"):
            self.e_action_a_cb["values"]=SETTABLE_OBJECT_PROPERTIES
            self.e_action_b_cb["values"]=OBJECT_PROPERTIES
        elif action in ("Toggle Self Property","Toggle Other Property"):
            self.e_action_a_cb["values"]=["Active"]+[f"P{i}" for i in range(8)]
        elif action in (
            "Set Self Property From Variable","Set Other Property From Variable",
            "Add Variable To Self Property","Subtract Variable From Self Property",
            "Add Variable To Other Property","Subtract Variable From Other Property"
        ):
            self.e_action_a_cb["values"]=SETTABLE_OBJECT_PROPERTIES
            self.e_action_b_cb["values"]=self._logic_variable_choices()
        elif action in ("Destroy Object","Create Object","Set Object Active","Set Object Room","Set Object X","Set Object Y","Create Object At Object"):
            self.e_action_a_cb["values"]=[""]+self._logic_object_id_choices()
            if action=="Create Object At Object":
                self.e_action_b_cb["values"]=[""]+self._logic_object_id_choices()
        elif action=="Set Colliding Object Active":
            self.e_action_a_cb["values"]=["0","1"]
        elif action in ("Start Path","Stop Path","Restart Path"):
            pass
        elif action=="Set Path":
            level=self.current_level or self.project.start_scene
            self.e_action_a_cb["values"]=[p.name for p in self.project.paths if p.level_id==level]
        elif action=="Move Toward Object":
            self.e_action_a_cb["values"]=self._logic_object_id_choices()
            self.e_action_b_cb["values"]=[str(i) for i in range(1,17)]
        elif action=="Set Direction":
            self.e_action_a_cb["values"]=[f"P{i}" for i in range(8)]
            self.e_action_b_cb["values"]=["Up","Right","Down","Left"]
        elif action=="Move In Direction Property":
            self.e_action_a_cb["values"]=[f"P{i}" for i in range(8)]
            self.e_action_b_cb["values"]=[str(i) for i in range(1,17)]
        elif action=="Choose Available Direction":
            self.e_action_a_cb["values"]=[f"P{i}" for i in range(8)]
            self.e_action_b_cb["values"]=["Allow Reverse","Avoid Reverse"]
        elif action=="Apply Queued Direction":
            self.e_action_a_cb["values"]=[f"P{i}" for i in range(8)]
            self.e_action_b_cb["values"]=[f"P{i}" for i in range(8)]
        elif action=="Snap Self To Tile":
            self.e_action_a_cb["values"]=["Both","X","Y"]
        elif action=="Set Tile Under Self":
            room=self.current_room()
            ts=self.project.tilesets.get(room.level_id) if room else None
            self.e_action_a_cb["values"]=[str(i) for i in range(len(ts.tiles))] if ts else []
        elif action in ("Add Inventory Item","Remove Inventory Item","Use Inventory Item"):
            self.e_action_a_cb["values"]=[str(i.item_id) for i in sorted(self.project.inventory.items,key=lambda x:x.item_id)]
            self.e_action_b_cb["values"]=["1","2","5","10","25","50","99"]
        elif action=="Move Inventory Slot":
            vals=[str(i) for i in range(self.project.inventory.slot_count)];self.e_action_a_cb["values"]=vals;self.e_action_b_cb["values"]=vals
        elif action=="Set Selected Inventory Slot":
            self.e_action_a_cb["values"]=[str(i) for i in range(self.project.inventory.slot_count)]
        elif action=="Render Inventory Tiles":
            self.e_action_a_cb["values"]=["Configured Room"]+[str(r.room_id) for r in self.project.rooms]

    def _load_event(self,e):
        self.e_event.set(e.get("event","Every Frame")); self.e_event_a.set(e.get("event_arg1","")); self.e_event_b.set(e.get("event_arg2",""))
        self.e_cond.set(e.get("condition","None")); self.e_cond_a.set(e.get("condition_arg1","")); self.e_cond_b.set(e.get("condition_arg2",""))
        actions=self._normalize_event_actions(e)
        self.current_action_index=max(0,min(self.current_action_index,len(actions)-1))
        a=actions[self.current_action_index]
        self.e_action.set(a.get("action","Move X")); self.e_action_a.set(a.get("action_arg1","")); self.e_action_b.set(a.get("action_arg2",""))
        self._refresh_do_list()
        self._update_logic_arg_choices()

    def apply_event(self):
        o=self.current_object()
        if not o:
            return messagebox.showwarning("No object","Create or select an object first.")
        if self.current_event_index is None:return messagebox.showwarning("Select event","Select or add a visual event first.")
        event=o.events[self.current_event_index]
        event.update({
            "event":self.e_event.get(),"event_arg1":self.e_event_a.get().strip(),"event_arg2":self.e_event_b.get().strip(),
            "condition":self.e_cond.get(),"condition_arg1":self.e_cond_a.get().strip(),"condition_arg2":self.e_cond_b.get().strip()})
        actions=self._normalize_event_actions(event)
        self.current_action_index=max(0,min(self.current_action_index,len(actions)-1))
        actions[self.current_action_index]={
            "action":self.e_action.get(),
            "action_arg1":self.e_action_a.get().strip(),
            "action_arg2":self.e_action_b.get().strip()
        }
        first=actions[0]
        event["action"]=first["action"]; event["action_arg1"]=first["action_arg1"]; event["action_arg2"]=first["action_arg2"]
        self.dirty=True
        self._refresh_event_list()

    def attach_behavior(self):
        o=self.current_object()
        if not o:
            return messagebox.showwarning("No object","Create or select an object first.")
        for e in BEHAVIOR_TEMPLATES[self.behavior_var.get()]:o.events.append(dict(e))
        self.current_event_index=len(o.events)-1 if o.events else None
        self.dirty=True; self._refresh_event_list()

    # ---------------- scenes ----------------
    def add_scene(self):
        name=simpledialog.askstring("Add Scene","Scene name")
        if not name:return
        if any(s.name==name for s in self.project.scenes):return messagebox.showerror("Exists","That scene already exists.")
        self.project.scenes.append(Scene(name=name))
        self.current_level=name
        self.current_sprite_id=None
        self.dirty=True; self._refresh_all()

    def delete_scene(self):
        sel=self.scene_list.curselection()
        if not sel:return
        if len(self.project.scenes)<=1:return messagebox.showwarning("Required","Keep at least one scene.")
        idx=sel[0]; name=self.project.scenes[idx].name
        if any(o.scene==name for o in self.project.objects.values()):return messagebox.showerror("In use","Move objects out of this level first.")
        if self._rooms_for_level(name):return messagebox.showerror("Rooms exist","Delete this level's rooms before deleting the level.")
        if self._level_sprites(name):return messagebox.showerror("Sprites exist","Delete this level's sprites before deleting the level.")
        if name in self.project.tilesets:return messagebox.showerror("Tileset exists","Remove or replace this level's imported tileset before deleting the level.")
        del self.project.scenes[idx]
        if self.current_level==name:self.current_level=self.project.scenes[0].name
        self.dirty=True; self._refresh_all()

    def _on_scene_select(self,e=None):
        sel=self.scene_list.curselection()
        if not sel:return
        s=self.project.scenes[sel[0]]
        self.scene_name.set(s.name); self.scene_mode.set(s.display_mode); self.scene_color_cb.current(s.background_color)
        self.scene_mc_cbs[0].current(s.mc1); self.scene_mc_cbs[1].current(s.mc2); self.scene_mc_cbs[2].current(s.local)

    def apply_scene(self):
        sel=self.scene_list.curselection()
        if not sel:return
        s=self.project.scenes[sel[0]]; old=s.name; new=self.scene_name.get().strip() or old
        if new!=old and any(x.name==new for x in self.project.scenes):return messagebox.showerror("Exists","Scene name already exists.")
        s.name=new; s.background_color=self.scene_color_cb.current(); s.display_mode=self.scene_mode.get()
        s.mc1=self.scene_mc_cbs[0].current(); s.mc2=self.scene_mc_cbs[1].current(); s.local=self.scene_mc_cbs[2].current()
        for o in self.project.objects.values():
            if o.scene==old:o.scene=new
            if getattr(o,"sprite_level",o.scene)==old:o.sprite_level=new
        for room in self.project.rooms:
            if room.level_id==old:room.level_id=new
        if old in self.project.tilesets:
            self.project.tilesets[new]=self.project.tilesets.pop(old)
        moved={}
        for key,sp in list(self.project.sprites.items()):
            if getattr(sp,"level_id",old)==old:
                del self.project.sprites[key]
                sp.level_id=new
                moved[self._sprite_key(new,sp.sprite_id)]=sp
        self.project.sprites.update(moved)
        if self.project.start_scene==old:self.project.start_scene=new
        if self.current_level==old:self.current_level=new
        self.dirty=True; self._refresh_all()

    # ---------------- rooms ----------------
    def add_room(self):
        used={r.room_id for r in self.project.rooms}
        avail=[i for i in range(256) if i not in used]
        if not avail:return messagebox.showwarning("Room limit","All 256 room IDs are used.")
        rid=simpledialog.askinteger("Add Room","Room ID 0-255",initialvalue=avail[0],minvalue=0,maxvalue=255)
        if rid is None:return
        if rid in used:return messagebox.showerror("ID used","That room ID already exists.")
        name=simpledialog.askstring("Add Room","Room name",initialvalue=f"Room {rid}") or f"Room {rid}"
        level=self.current_level if self.current_level in [s.name for s in self.project.scenes] else self.project.start_scene
        self.project.rooms.append(Room(room_id=rid,name=name,level_id=level))
        self.current_room_id=rid; self.dirty=True; self._refresh_all()

    def delete_room(self):
        room=self.current_room()
        if not room:return
        if len(self.project.rooms)<=1:return messagebox.showwarning("Required","Keep at least one room.")
        if any(o.room_id==room.room_id for o in self.project.objects.values()):
            return messagebox.showwarning("Room in use","Move or delete the objects assigned to this room first.")
        if not messagebox.askyesno("Delete Room",f"Delete {room.name}?"):return
        self.project.rooms=[r for r in self.project.rooms if r.room_id!=room.room_id]
        if self.project.start_room_id==room.room_id:self.project.start_room_id=self.project.rooms[0].room_id
        self.current_room_id=self.project.rooms[0].room_id
        self.dirty=True; self._refresh_all()

    def _on_room_select(self,e=None):
        sel=self.room_list.curselection()
        if not sel:return
        try:self.current_room_id=int(self.room_list.get(sel[0]).split(":",1)[0])
        except:return
        room=self.current_room()
        if room:self.current_level=room.level_id
        self.room_drag_object_id=None
        self.current_room_instance_id=None
        self._refresh_all()
        self.after_idle(self._draw_room)

    def apply_room(self):
        room=self.current_room()
        if not room:return
        level=self.room_level_var.get()
        if level not in [s.name for s in self.project.scenes]:
            return messagebox.showerror("Level","Choose a valid level.")
        if level!=room.level_id and any(o.room_id==room.room_id for o in self.project.objects.values()):
            return messagebox.showwarning("Room in use","Move/delete this room's objects before moving the room to a different level.")
        room.name=self.room_name_var.get().strip() or f"Room {room.room_id}"
        room.level_id=level
        start_obj=self.project.objects.get(room.player_start_object_id)
        if room.player_start_enabled and (not start_obj or start_obj.scene!=level):
            room.player_start_enabled=False
        self.current_level=level
        self.dirty=True; self._refresh_all()

    def set_start_room(self):
        room=self.current_room()
        if not room:return
        self.project.start_room_id=room.room_id
        self.project.start_scene=room.level_id
        self.current_level=room.level_id
        self.dirty=True
        self.status.set(f"Start room: {room.name} / level {room.level_id}")
        self._refresh_all()

    # ---------------- variables ----------------
    def add_variable(self):
        name=simpledialog.askstring("Add Variable","Variable name")
        if not name:return
        if any(v.name==name for v in self.project.variables):return messagebox.showerror("Exists","Variable already exists.")
        self.project.variables.append(Variable(name=name,initial=0)); self.dirty=True; self._refresh_variables()

    def delete_variable(self):
        sel=self.var_list.curselection()
        if not sel:return
        if len(self.project.variables)<=1:return messagebox.showwarning("Required","Keep at least one variable.")
        del self.project.variables[sel[0]]; self.dirty=True; self._refresh_variables()

    def _on_var_select(self,e=None):
        sel=self.var_list.curselection()
        if not sel:return
        v=self.project.variables[sel[0]]; self.var_name.set(v.name); self.var_initial.set(v.initial)

    def apply_variable(self):
        sel=self.var_list.curselection()
        if not sel:return
        v=self.project.variables[sel[0]]; new=self.var_name.get().strip() or v.name
        if new!=v.name and any(x.name==new for x in self.project.variables):return messagebox.showerror("Exists","Variable already exists.")
        old=v.name; v.name=new; v.initial=max(0,min(255,int(self.var_initial.get())))
        for o in self.project.objects.values():
            for e in o.events:
                if e.get("event","").startswith("Variable") and e.get("event_arg1")==old:e["event_arg1"]=new
                if e.get("condition","").startswith("Variable") and e.get("condition_arg1")==old:e["condition_arg1"]=new
                if e.get("action") in ("Set Variable","Add To Variable") and e.get("action_arg1")==old:e["action_arg1"]=new
        self.dirty=True; self._refresh_variables(); self._refresh_event_list()

    # ---------------- export ----------------
    @staticmethod
    def _pack1(row):
        out=[]
        for i in range(0,len(row),8):
            b=0
            for j,v in enumerate(row[i:i+8]):
                if v:b|=1<<(7-j)
            out.append(b)
        return out

    @staticmethod
    def _packmc(row):
        out=[]
        hwmap=(0,3,2,1)
        for i in range(0,len(row),4):
            b=0
            for j,v in enumerate(row[i:i+4]):
                b|=(hwmap[v&3]&3)<<(6-j*2)
            out.append(b)
        return out

    def _frame_bytes(self,s,f):
        img=[]; mask=[]
        for row in f.pixels:
            img += self._pack1(row) if s.mode=="hires" else self._packmc(row)
            mask += self._pack1([1 if x else 0 for x in row])
        return bytes(img+mask)

    def _vic_frame_bytes(self,s,f):
        if getattr(s,"renderer","software")!="vic":
            raise ValueError("VIC frame requested for a software sprite.")
        expected_w=24 if s.mode=="hires" else 12
        if s.width!=expected_w or s.height!=21:
            raise ValueError(
                f"VIC-II Sprite {s.sprite_id} must be "
                f"{expected_w}x21 in {s.mode} mode."
            )
        out=[]
        for row in f.pixels[:21]:
            vals=(list(row)+[0]*expected_w)[:expected_w]
            if s.mode=="hires":
                for q in range(0,24,8):
                    b=0
                    for bit,v in enumerate(vals[q:q+8]):
                        if v:b|=1<<(7-bit)
                    out.append(b)
            else:
                # Editor semantics are 1=MC1, 2=MC2, 3=local.
                # VIC-II hardware-sprite bitpairs are
                # 01=MC1, 10=local, 11=MC2, so swap logical 2/3.
                hwmap=(0,1,3,2)
                for q in range(0,12,4):
                    v=vals[q:q+4]
                    out.append(
                        ((hwmap[v[0]&3]&3)<<6) |
                        ((hwmap[v[1]&3]&3)<<4) |
                        ((hwmap[v[2]&3]&3)<<2) |
                        (hwmap[v[3]&3]&3)
                    )
        if len(out)!=63:
            raise ValueError(f"VIC-II Sprite {s.sprite_id} frame did not encode to 63 bytes.")
        return bytes(out+[0])

    @staticmethod
    def _safe_label(name):
        s="".join(ch if ch.isalnum() or ch=="_" else "_" for ch in name)
        if not s or s[0].isdigit():s="_"+s
        return s

    def _generate_folder(self,d):
        if not self.project.sprites or not self.project.objects:
            raise ValueError("Create at least one sprite and one object before building the game.")
        for o in self.project.objects.values():
            if self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id) not in self.project.sprites:
                raise ValueError(f"Object {o.object_id} references missing Sprite {o.sprite_id} in level {getattr(o,'sprite_level',o.scene)}.")
        d=Path(d)
        d.mkdir(parents=True,exist_ok=True)

        # ------------------------------------------------------------
        # Export sprite binary resources.
        # ------------------------------------------------------------
        sprite_meta={}
        vic_blob=bytearray()
        vic_frame_cursor=0
        for key,s in sorted(self.project.sprites.items(), key=lambda kv:(kv[1].level_id,kv[1].sprite_id)):
            level_tag=self._safe_label(s.level_id)
            sid=s.sprite_id
            frame_payloads=[self._frame_bytes(s,f) for f in s.frames]
            payload=b"".join(frame_payloads)
            fname=f"sprite_{level_tag}_{sid:03d}.bin"
            (d/fname).write_bytes(payload)

            if s.mode=="hires":
                image_bytes=(s.width//8)*s.height
            else:
                image_bytes=(s.width//4)*s.height
            frame_size=len(frame_payloads[0]) if frame_payloads else 0

            vic_base_ptr=0
            if getattr(s,"renderer","software")=="vic":
                vic_base_ptr=0x24+vic_frame_cursor
                for f in s.frames:
                    vic_blob.extend(self._vic_frame_bytes(s,f))
                    vic_frame_cursor+=1
                if vic_frame_cursor>28:
                    raise ValueError(
                        "VER 06.0 supports up to 28 total VIC-II hardware sprite frames "
                        "across the project. Reduce hardware-sprite animation frames or "
                        "switch some sprites back to software rendering."
                    )

            sprite_meta[self._sprite_key(s.level_id,sid)]={
                "sprite":s,
                "file":fname,
                "frame_size":frame_size,
                "image_bytes":image_bytes,
                "frame_count":len(s.frames),
                "anim_duration":max(1,int(s.frames[0].duration if s.frames else 6)),
                "vic_base_ptr":vic_base_ptr,
            }

        (d/"vic_sprites.bin").write_bytes(bytes(vic_blob))
        vic_asm=[
            "// Next64 VIC-II hardware sprite data mirrored into both bitmap banks.",
            "// $0900-$0fff and $4900-$4fff hold mirrored VIC sprite frames; main engine is at $8000+.",
        ]
        if vic_blob:
            vic_asm += [
                '* = $0900 "VIC Sprite Data Bank A"',
                'vicSpriteDataA: .import binary "vic_sprites.bin"',
                '* = $4900 "VIC Sprite Data Bank B"',
                'vicSpriteDataB: .import binary "vic_sprites.bin"',
            ]
        (d/"generated_vic_sprites.asm").write_text("\n".join(vic_asm)+"\n",encoding="utf-8")

        # ------------------------------------------------------------
        # C64 live runtime slots.
        #
        # Object definitions are templates. Object 0 is unique. Every placed
        # reusable RoomInstance gets its own independent runtime slot. A
        # nonzero definition with no placed instance keeps one definition slot
        # so it can still be spawned dynamically (projectiles, effects, etc.).
        # ------------------------------------------------------------
        instances_by_template={}
        for inst in sorted(self.project.instances,key=lambda i:i.instance_id):
            instances_by_template.setdefault(inst.object_id,[]).append(inst)

        runtime_slots=[]
        for oid,o in sorted(self.project.objects.items()):
            insts=instances_by_template.get(oid,[])
            if oid==0 or not insts:
                runtime_slots.append({
                    "template_id":oid,
                    "instance_id":255,
                    "x":o.x,"y":o.y,"room_id":o.room_id,"level_id":o.scene,
                    "active":bool(o.active),
                    "properties":(list(getattr(o,"properties",[0]*8))+[0]*8)[:8],
                    "z_order":0,
                })
            if oid!=0:
                for inst in insts:
                    runtime_slots.append({
                        "template_id":oid,
                        "instance_id":inst.instance_id & 255,
                        "x":inst.x,"y":inst.y,"room_id":inst.room_id,
                        "level_id":inst.level_id,"active":bool(inst.active),
                        "properties":(list(getattr(inst,"properties",getattr(o,"properties",[0]*8)))+[0]*8)[:8],
                        "z_order":int(getattr(inst,"z_order",0))&255,
                    })

        if len(runtime_slots)>255:
            raise ValueError(
                f"This project needs {len(runtime_slots)} live C64 object slots. "
                "VER 07.5 currently supports at most 255 live slots per build."
            )

        template_to_slots={}
        for slot_index,slot in enumerate(runtime_slots):
            template_to_slots.setdefault(slot["template_id"],[]).append(slot_index)
        template_first_index={tid:slots[0] for tid,slots in template_to_slots.items()}

        start_scene = next((s for s in self.project.scenes if s.name==self.project.start_scene), self.project.scenes[0] if self.project.scenes else Scene())
        scene_mode = 1 if start_scene.display_mode=="multicolor" else 0
        self._inventory_normalize()
        inv=self.project.inventory
        (d/"generated_defs.asm").write_text(
            f"// Generated Next64 definitions\n"
            f".const OBJ_COUNT = {len(runtime_slots)}\n"
            f".const SPRITE_COUNT = {len(self.project.sprites)}\n"
            f".const VAR_COUNT = {len(self.project.variables)}\n"
            f".const ROOM_COUNT = {len(self.project.rooms)}\n"
            f".const PATH_COUNT = {len([p for p in self.project.paths if p.points])}\n"
            f".const INVENTORY_ENABLED = {1 if inv.enabled else 0}\n"
            f".const INVENTORY_SLOT_COUNT = {inv.slot_count}\n"
            f".const INVENTORY_ITEM_COUNT = {len(inv.items)}\n"
            f".const INVENTORY_ROOM = {inv.display_room_id}\n"
            f".const INVENTORY_X = {inv.display_x}\n"
            f".const INVENTORY_Y = {inv.display_y}\n"
            f".const INVENTORY_COLUMNS = {inv.display_columns}\n"
            f".const INVENTORY_EMPTY_TILE = {inv.empty_tile_id}\n"
            f".const VIC_FRAME_COUNT = {vic_frame_cursor}\n"
            f".const START_ROOM_ID = {self.project.start_room_id}\n"
            f".const SCENE_MODE = {scene_mode}\n"
            f".const SCENE_BG = {start_scene.background_color & 15}\n"
            f".const SCENE_MC1 = {start_scene.mc1 & 15}\n"
            f".const SCENE_MC2 = {start_scene.mc2 & 15}\n"
            f".const SCENE_LOCAL = {start_scene.local & 15}\n",
            encoding="utf-8")

        # ------------------------------------------------------------
        # Sprite labels and binary data.
        # ------------------------------------------------------------
        # Software-sprite resources follow the generated engine/data instead
        # of forcing a second fixed address.  VER 07.3 moved Main to $8000,
        # so retaining the old sprite-data $8000 origin caused an assembler
        # overlap between Main and Software Sprite Data.
        slines=[
            "// Generated sprite resources",
            "// Contiguous with Main; no fixed origin here."
        ]
        for key,meta in sorted(sprite_meta.items()):
            s=meta["sprite"]; level_tag=self._safe_label(s.level_id); sid=s.sprite_id
            label=f"sprite_{level_tag}_{sid:03d}_data"
            meta["label"]=label
            slines += [
                f".const SPR_{level_tag}_{sid:03d}_MODE = {0 if s.mode=='hires' else 1}",
                f".const SPR_{level_tag}_{sid:03d}_WIDTH = {s.width}",
                f".const SPR_{level_tag}_{sid:03d}_HEIGHT = {s.height}",
                f".const SPR_{level_tag}_{sid:03d}_FRAMES = {meta['frame_count']}",
                f".const SPR_{level_tag}_{sid:03d}_FRAME_SIZE = {meta['frame_size']}",
                f".const SPR_{level_tag}_{sid:03d}_IMAGE_BYTES = {meta['image_bytes']}",
                f'{label}: .import binary "{meta["file"]}"',
                ""
            ]
        (d/"generated_sprites.asm").write_text("\n".join(slines),encoding="utf-8")

        # ------------------------------------------------------------
        # Live object state.
        # Every placed reusable room instance has its own independent C64
        # runtime slot. objectId stores the shared template ID; objectInstanceId
        # identifies the editor placement (255 = definition/dynamic slot).
        # ------------------------------------------------------------
        def slot_object(slot):
            return self.project.objects[slot["template_id"]]

        def slot_meta(slot):
            o=slot_object(slot)
            return sprite_meta[self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id)]

        def slot_start_active(slot):
            return (
                slot["active"]
                and slot["room_id"]==self.project.start_room_id
                and slot["level_id"]==self.project.start_scene
            )

        obj_lines=["// Generated live object state tables"]
        obj_lines.append("objectId: .byte "+",".join(str(s["template_id"]&255) for s in runtime_slots))
        obj_lines.append("objectInstanceId: .byte "+",".join(str(s["instance_id"]&255) for s in runtime_slots))
        for pi in range(8):
            obj_lines.append(f"objectP{pi}: .byte "+",".join(
                str((list(s.get("properties",getattr(slot_object(s),"properties",[0]*8)))+[0]*8)[pi]&255)
                for s in runtime_slots
            ))
        obj_lines.append("objectZ: .byte "+",".join(str(int(s.get("z_order",0))&255) for s in runtime_slots))
        initial_draw_order=sorted(range(len(runtime_slots)),key=lambda idx:(int(runtime_slots[idx].get("z_order",0))&255,idx))
        obj_lines.append("objectDrawOrder: .byte "+",".join(str(i&255) for i in initial_draw_order))
        obj_lines.append("objectSprite: .byte "+",".join(str(slot_object(s).sprite_id&255) for s in runtime_slots))
        obj_lines.append("objectXLo: .byte "+",".join(str(s["x"]&255) for s in runtime_slots))
        obj_lines.append("objectXHi: .byte "+",".join(str((s["x"]>>8)&1) for s in runtime_slots))
        obj_lines.append("objectY: .byte "+",".join(str(s["y"]&255) for s in runtime_slots))
        obj_lines.append("objectLastXLo: .byte "+",".join(str(s["x"]&255) for s in runtime_slots))
        obj_lines.append("objectLastXHi: .byte "+",".join(str((s["x"]>>8)&1) for s in runtime_slots))
        obj_lines.append("objectLastY: .byte "+",".join(str(s["y"]&255) for s in runtime_slots))
        obj_lines.append("objectRoom: .byte "+",".join(str(s["room_id"]&255) for s in runtime_slots))
        obj_lines.append("objectSpriteId: .byte "+",".join(str(slot_object(s).sprite_id&255) for s in runtime_slots))
        obj_lines.append("objectDefaultActive: .byte "+",".join("1" if s["active"] else "0" for s in runtime_slots))
        obj_lines.append("objectActive: .byte "+",".join("1" if s["active"] else "0" for s in runtime_slots))
        obj_lines.append("objectPrevAXLo: .byte "+",".join(str(s["x"]&255) for s in runtime_slots))
        obj_lines.append("objectPrevAXHi: .byte "+",".join(str((s["x"]>>8)&1) for s in runtime_slots))
        obj_lines.append("objectPrevAY: .byte "+",".join(str(s["y"]&255) for s in runtime_slots))
        obj_lines.append("objectPrevAActive: .byte "+",".join("0" for _ in runtime_slots))
        obj_lines.append("objectPrevBXLo: .byte "+",".join(str(s["x"]&255) for s in runtime_slots))
        obj_lines.append("objectPrevBXHi: .byte "+",".join(str((s["x"]>>8)&1) for s in runtime_slots))
        obj_lines.append("objectPrevBY: .byte "+",".join(str(s["y"]&255) for s in runtime_slots))
        obj_lines.append("objectPrevBActive: .byte "+",".join("0" for _ in runtime_slots))
        obj_lines.append("objectFrame: .byte "+",".join("0" for _ in runtime_slots))
        obj_lines.append("objectAnimTimer: .byte "+",".join("0" for _ in runtime_slots))
        usable_paths_for_ids=[p for p in self.project.paths if p.points]
        path_id_by_name={p.name:i for i,p in enumerate(usable_paths_for_ids)}
        obj_lines.append("objectPathId: .byte "+",".join(str(path_id_by_name.get(getattr(slot_object(s),"path_name",""),255)&255) for s in runtime_slots))
        obj_lines.append("objectPathPoint: .byte "+",".join("0" for _ in runtime_slots))
        obj_lines.append("objectPathDir: .byte "+",".join("1" for _ in runtime_slots))
        obj_lines.append("objectPathActive: .byte "+",".join("1" if (bool(getattr(slot_object(s),"path_enabled",False)) and getattr(slot_object(s),"path_name","") in path_id_by_name) else "0" for s in runtime_slots))
        obj_lines.append("objectPathDone: .byte "+",".join("0" for _ in runtime_slots))
        obj_lines.append("objectRenderer: .byte "+",".join(str(1 if getattr(slot_meta(s)["sprite"],"renderer","software")=="vic" else 0) for s in runtime_slots))
        obj_lines.append("objectVICBasePtr: .byte "+",".join(str(slot_meta(s).get("vic_base_ptr",0)&255) for s in runtime_slots))
        obj_lines.append("objectVICColor: .byte "+",".join(str((slot_meta(s)["sprite"].colors.get("local",1) if slot_meta(s)["sprite"].mode=="multicolor" else slot_meta(s)["sprite"].colors.get("hires",1))&15) for s in runtime_slots))
        obj_lines.append("objectUsesLocal: .byte "+",".join(
            "1" if (
                slot_meta(s)["sprite"].mode=="multicolor"
                and any(3 in row for fr in slot_meta(s)["sprite"].frames for row in fr.pixels)
            ) else "0"
            for s in runtime_slots
        ))
        obj_lines.append("objectMode: .byte "+",".join(str(0 if slot_meta(s)["sprite"].mode=="hires" else 1) for s in runtime_slots))
        obj_lines.append("objectWidthBytes: .byte "+",".join(str((slot_meta(s)["sprite"].width//8) if slot_meta(s)["sprite"].mode=="hires" else (slot_meta(s)["sprite"].width//4)) for s in runtime_slots))
        obj_lines.append("objectHeight: .byte "+",".join(str(slot_meta(s)["sprite"].height) for s in runtime_slots))
        obj_lines.append("objectFrameCount: .byte "+",".join(str(slot_meta(s)["frame_count"]) for s in runtime_slots))
        obj_lines.append("objectAutoAnimate: .byte "+",".join("1" if bool(getattr(slot_meta(s)["sprite"],"auto_animate",True)) else "0" for s in runtime_slots))
        obj_lines.append("objectAnimLoop: .byte "+",".join("1" if bool(getattr(slot_meta(s)["sprite"],"loop",True)) else "0" for s in runtime_slots))
        obj_lines.append("objectAnimDuration: .byte "+",".join(str(slot_meta(s)["anim_duration"] & 255) for s in runtime_slots))
        obj_lines.append("objectDataLo: .byte "+",".join(f"<{slot_meta(s)['label']}" for s in runtime_slots))
        obj_lines.append("objectDataHi: .byte "+",".join(f">{slot_meta(s)['label']}" for s in runtime_slots))
        obj_lines.append("objectFrameSizeLo: .byte "+",".join(str(slot_meta(s)["frame_size"] & 255) for s in runtime_slots))
        obj_lines.append("objectFrameSizeHi: .byte "+",".join(str((slot_meta(s)["frame_size"]>>8) & 255) for s in runtime_slots))
        obj_lines.append("objectImageBytesLo: .byte "+",".join(str(slot_meta(s)["image_bytes"] & 255) for s in runtime_slots))
        obj_lines.append("objectImageBytesHi: .byte "+",".join(str((slot_meta(s)["image_bytes"]>>8) & 255) for s in runtime_slots))
        (d/"generated_objects.asm").write_text("\n".join(obj_lines)+"\n",encoding="utf-8")

        # ------------------------------------------------------------
        # Reusable room instances. Object 0 remains unique; object definitions
        # 1-255 may have any number of editor/runtime placement records.
        # ------------------------------------------------------------
        ilines=["// Reusable room object instances"]
        ordered_instances=sorted(self.project.instances,key=lambda i:i.instance_id)
        ilines.append(f".const ROOM_INSTANCE_COUNT = {len(ordered_instances)}")
        if ordered_instances:
            instance_slot_lookup={}
            for slot_index,slot in enumerate(runtime_slots):
                if slot["instance_id"]!=255:
                    instance_slot_lookup[slot["instance_id"]]=slot_index
            ilines.append("instanceRuntimeSlot: .byte "+",".join(str(instance_slot_lookup.get(i.instance_id,255)&255) for i in ordered_instances))
            ilines.append("instanceTemplate: .byte "+",".join(str(i.object_id&255) for i in ordered_instances))
            ilines.append("instanceRoom: .byte "+",".join(str(i.room_id&255) for i in ordered_instances))
            ilines.append("instanceXLo: .byte "+",".join(str(i.x&255) for i in ordered_instances))
            ilines.append("instanceXHi: .byte "+",".join(str((i.x>>8)&1) for i in ordered_instances))
            ilines.append("instanceY: .byte "+",".join(str(i.y&255) for i in ordered_instances))
            ilines.append("instanceActive: .byte "+",".join("1" if i.active else "0" for i in ordered_instances))
        (d/"generated_instances.asm").write_text("\n".join(ilines)+"\n",encoding="utf-8")

        # ------------------------------------------------------------
        # Room metadata. Rooms are separate from levels and inherit the level
        # display mode/colors. Runtime room switching is a future layer.
        # ------------------------------------------------------------
        rlines=["// Generated room metadata"]
        ordered_rooms=sorted(self.project.rooms,key=lambda r:r.room_id)
        for r in ordered_rooms:
            if r.player_start_enabled:
                rlines.append(
                    f"// Room {r.room_id}: {r.name} / level {r.level_id} / "
                    f"EXPLICIT player Object {r.player_start_object_id} at {r.player_start_x},{r.player_start_y}"
                )
            else:
                rlines.append(
                    f"// Room {r.room_id}: {r.name} / level {r.level_id} / AUTO EDGE ENTRY"
                )
        rlines += [
            "// AUTO EDGE ENTRY rule for rooms without an explicit start:",
            "// DOWN -> y=top, keep prior x; UP -> y=bottom, keep prior x;",
            "// RIGHT -> x=left, keep prior y; LEFT -> x=right, keep prior y.",
        ]
        rlines.append("roomId: .byte "+",".join(str(r.room_id & 255) for r in ordered_rooms))
        rlines.append("roomPlayerStartMode: .byte "+",".join("1" if r.player_start_enabled else "0" for r in ordered_rooms))
        rlines.append("roomPlayerObject: .byte "+",".join(str(r.player_start_object_id & 255) for r in ordered_rooms))
        rlines.append("roomPlayerSprite: .byte "+",".join(str(r.player_start_sprite_id & 255) for r in ordered_rooms))
        rlines.append("roomPlayerStartXLo: .byte "+",".join(str(r.player_start_x & 255) for r in ordered_rooms))
        rlines.append("roomPlayerStartXHi: .byte "+",".join(str((r.player_start_x>>8)&1) for r in ordered_rooms))
        rlines.append("roomPlayerStartY: .byte "+",".join(str(r.player_start_y & 255) for r in ordered_rooms))
        (d/"generated_rooms.asm").write_text("\n".join(rlines)+"\n",encoding="utf-8")

        # ------------------------------------------------------------
        # Named object paths. Waypoints use absolute C64 coordinates.
        # Runtime tables use one-byte flattened point indexes, so keep the
        # total point count at or below 255 for the 8-bit C64 engine.
        # ------------------------------------------------------------
        usable_paths=[p for p in self.project.paths if p.points]
        flat_points=[]; starts=[]; counts=[]; speeds=[]; modes=[]
        for pth in usable_paths:
            starts.append(len(flat_points))
            pts=[[max(0,min(319,int(q[0]))),max(0,min(199,int(q[1])))] for q in pth.points]
            flat_points.extend(pts)
            counts.append(len(pts))
            speeds.append(max(1,min(16,int(pth.speed))))
            modes.append({"loop":0,"patrol":1,"once":2}.get(pth.mode,0))
        if len(flat_points)>255:
            raise ValueError("Object paths contain more than 255 total waypoints. Split or shorten the paths for the C64 runtime.")
        plines=["// Generated named object paths"]
        if usable_paths:
            plines.append("pathStart: .byte "+",".join(str(x&255) for x in starts))
            plines.append("pathCount: .byte "+",".join(str(x&255) for x in counts))
            plines.append("pathSpeed: .byte "+",".join(str(x&255) for x in speeds))
            plines.append("pathMode: .byte "+",".join(str(x&255) for x in modes))
        else:
            plines += ["pathStart: .byte 0","pathCount: .byte 0","pathSpeed: .byte 1","pathMode: .byte 0"]
        if flat_points:
            plines.append("pathPointXLo: .byte "+",".join(str(x&255) for x,y in flat_points))
            plines.append("pathPointXHi: .byte "+",".join(str((x>>8)&1) for x,y in flat_points))
            plines.append("pathPointY: .byte "+",".join(str(y&255) for x,y in flat_points))
        else:
            plines += ["pathPointXLo: .byte 0","pathPointXHi: .byte 0","pathPointY: .byte 0"]
        (d/"generated_paths.asm").write_text("\n".join(plines)+"\n",encoding="utf-8")

        # ------------------------------------------------------------
        # Imported level tilesets and room tile maps.
        # These are exported now for compatibility/data preservation.
        # The current runtime does not yet composite the room tile layer.
        # ------------------------------------------------------------
        tile_lines=["// Next64 room tile resources, renderer metadata, and collision data"]
        level_tile_meta={}

        for level_name,ts in sorted(self.project.tilesets.items()):
            tag=self._safe_label(level_name)
            packed=[]
            tw=max(1,int(getattr(ts,"tile_width",8)))
            th=max(1,int(getattr(ts,"tile_height",8)))
            tmode=getattr(ts,"mode","multicolor")
            wb=max(1,(tw+7)//8)

            while len(ts.tile_collision)<len(ts.tiles):
                ts.tile_collision.append(0)
            while len(ts.tile_properties)<len(ts.tiles):
                ts.tile_properties.append([0,0,0,0])
            ts.tile_properties=[(list(v)+[0,0,0,0])[:4] for v in ts.tile_properties[:len(ts.tiles)]]

            for tile in ts.tiles:
                for row in tile[:th]:
                    if tmode=="multicolor":
                        vals=list(row)
                        while len(vals)%4: vals.append(0)
                        for q in range(0,len(vals),4):
                            v=vals[q:q+4]
                            hwmap=(0,3,2,1)
                            packed.append(
                                ((hwmap[v[0]&3]&3)<<6) |
                                ((hwmap[v[1]&3]&3)<<4) |
                                ((hwmap[v[2]&3]&3)<<2) |
                                (hwmap[v[3]&3]&3)
                            )
                    else:
                        vals=[1 if x else 0 for x in row]
                        while len(vals)%8: vals.append(0)
                        for q in range(0,len(vals),8):
                            b=0
                            for bit,val in enumerate(vals[q:q+8]):
                                if val:b|=1<<(7-bit)
                            packed.append(b)

            fname=f"tiles_{tag}.bin"
            cfile=f"tile_collision_{tag}.bin"
            pfiles=[f"tile_prop{i}_{tag}.bin" for i in range(4)]
            (d/fname).write_bytes(bytes(packed))
            (d/cfile).write_bytes(bytes((ts.tile_collision+[0]*len(ts.tiles))[:len(ts.tiles)]))
            for pi,pf in enumerate(pfiles):
                (d/pf).write_bytes(bytes(int(ts.tile_properties[tid][pi])&255 for tid in range(len(ts.tiles))))

            tile_size=wb*th
            tile_label=f"tiles_{tag}_data"
            ptrlo=f"tilePtrLo_{tag}"
            ptrhi=f"tilePtrHi_{tag}"
            coll_label=f"tileCollision_{tag}"
            prop_labels=[f"tileProp{i}_{tag}" for i in range(4)]
            xcell=f"tileXCell_{tag}"
            ycell=f"tileYCell_{tag}"
            yofflo=f"tileYOffLo_{tag}"
            yoffhi=f"tileYOffHi_{tag}"

            # Lookup tables make arbitrary supported tile sizes cheap at runtime.
            xvals=[min(255,x//tw) for x in range(320)]
            yvals=[min(255,y//th) for y in range(200)]
            cols=min(40,(320+tw-1)//tw)
            yoffs=[(y//th)*cols for y in range(200)]

            tile_lines += [
                f"// Level {level_name}: {ts.name}",
                f".const TILESET_{tag}_COUNT = {len(ts.tiles)}",
                f".const TILESET_{tag}_WIDTH = {tw}",
                f".const TILESET_{tag}_HEIGHT = {th}",
                f".const TILESET_{tag}_WIDTH_BYTES = {wb}",
                f".const TILESET_{tag}_MODE = {0 if tmode=='hires' else 1}",
                f'{tile_label}: .import binary "{fname}"',
                f'{coll_label}: .import binary "{cfile}"',
                f'{prop_labels[0]}: .import binary "{pfiles[0]}"',
                f'{prop_labels[1]}: .import binary "{pfiles[1]}"',
                f'{prop_labels[2]}: .import binary "{pfiles[2]}"',
                f'{prop_labels[3]}: .import binary "{pfiles[3]}"',
            ]
            if ts.tiles:
                tile_lines.append(f"{ptrlo}: .byte "+",".join(f"<({tile_label}+{i*tile_size})" for i in range(len(ts.tiles))))
                tile_lines.append(f"{ptrhi}: .byte "+",".join(f">({tile_label}+{i*tile_size})" for i in range(len(ts.tiles))))
            else:
                tile_lines += [f"{ptrlo}: .byte 0",f"{ptrhi}: .byte 0"]
            tile_lines.append(f"{xcell}: .byte "+",".join(str(v) for v in xvals))
            tile_lines.append(f"{ycell}: .byte "+",".join(str(v) for v in yvals))
            tile_lines.append(f"{yofflo}: .byte "+",".join(str(v&255) for v in yoffs))
            tile_lines.append(f"{yoffhi}: .byte "+",".join(str((v>>8)&255) for v in yoffs))
            tile_lines.append("")

            level_tile_meta[level_name]={
                "tag":tag,"tw":tw,"th":th,"wb":wb,"cols":cols,
                "rows":min(25,(200+th-1)//th),
                "tile_label":tile_label,"ptrlo":ptrlo,"ptrhi":ptrhi,
                "coll":coll_label,"props":prop_labels,"xcell":xcell,"ycell":ycell,
                "yofflo":yofflo,"yoffhi":yoffhi,
            }

        room_meta=[]
        for r in sorted(self.project.rooms,key=lambda rr:rr.room_id):
            meta=level_tile_meta.get(r.level_id)
            if meta:
                tw,th,wb=meta["tw"],meta["th"],meta["wb"]
                map_cols,map_rows=meta["cols"],meta["rows"]
            else:
                tw=th=8;wb=1;map_cols=40;map_rows=25

            room_vals=[]
            tm=r.tile_map if r.tile_map else [[-1 for _ in range(40)] for _ in range(25)]
            for yy in range(map_rows):
                row=tm[yy] if yy<len(tm) else []
                for xx in range(map_cols):
                    v=row[xx] if xx<len(row) else -1
                    room_vals.append(255 if int(v)<0 else int(v)&255)

            fname=f"room_{r.room_id:03d}_tilemap.bin"
            label=f"room_{r.room_id:03d}_tilemap"
            (d/fname).write_bytes(bytes(room_vals))
            tile_lines += [
                f"// Room {r.room_id} [{r.level_id}] {map_cols}x{map_rows} cells, {tw}x{th}px",
                f'{label}: .import binary "{fname}"',
                ""
            ]
            room_meta.append((r,meta,label,map_cols,map_rows,tw,th,wb))

        # Room metadata is scanned by room ID, so sparse room IDs are fine.
        tile_lines.append(f".const ROOM_TILE_META_COUNT = {len(room_meta)}")
        if room_meta:
            tile_lines.append("roomTileId: .byte "+",".join(str(r.room_id&255) for r,_,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileMapLo: .byte "+",".join(f"<{label}" for _,_,label,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileMapHi: .byte "+",".join(f">{label}" for _,_,label,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileCols: .byte "+",".join(str(cols) for _,_,_,cols,_,_,_,_ in room_meta))
            tile_lines.append("roomTileRows: .byte "+",".join(str(rows) for _,_,_,_,rows,_,_,_ in room_meta))
            tile_lines.append("roomTileWidthBytes: .byte "+",".join(str(wb) for _,_,_,_,_,_,_,wb in room_meta))
            tile_lines.append("roomTileHeight: .byte "+",".join(str(th) for _,_,_,_,_,_,th,_ in room_meta))
            tile_lines.append("roomTilePtrLoLo: .byte "+",".join(f"<{m['ptrlo']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTilePtrLoHi: .byte "+",".join(f">{m['ptrlo']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTilePtrHiLo: .byte "+",".join(f"<{m['ptrhi']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTilePtrHiHi: .byte "+",".join(f">{m['ptrhi']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileCollisionLo: .byte "+",".join(f"<{m['coll']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileCollisionHi: .byte "+",".join(f">{m['coll']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            for _pi in range(4):
                tile_lines.append(f"roomTileProp{_pi}Lo: .byte "+",".join(f"<{m['props'][_pi]}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
                tile_lines.append(f"roomTileProp{_pi}Hi: .byte "+",".join(f">{m['props'][_pi]}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileXCellLo: .byte "+",".join(f"<{m['xcell']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileXCellHi: .byte "+",".join(f">{m['xcell']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileYCellLo: .byte "+",".join(f"<{m['ycell']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileYCellHi: .byte "+",".join(f">{m['ycell']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileYOffLoLo: .byte "+",".join(f"<{m['yofflo']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileYOffLoHi: .byte "+",".join(f">{m['yofflo']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileYOffHiLo: .byte "+",".join(f"<{m['yoffhi']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
            tile_lines.append("roomTileYOffHiHi: .byte "+",".join(f">{m['yoffhi']}" if m else "0" for _,m,_,_,_,_,_,_ in room_meta))
        else:
            tile_lines += [
                "roomTileId: .byte 0","roomTileMapLo: .byte 0","roomTileMapHi: .byte 0",
                "roomTileCols: .byte 40","roomTileRows: .byte 25","roomTileWidthBytes: .byte 1",
                "roomTileHeight: .byte 8","roomTilePtrLoLo: .byte 0","roomTilePtrLoHi: .byte 0",
                "roomTilePtrHiLo: .byte 0","roomTilePtrHiHi: .byte 0","roomTileCollisionLo: .byte 0",
                "roomTileCollisionHi: .byte 0",
                "roomTileProp0Lo: .byte 0","roomTileProp0Hi: .byte 0",
                "roomTileProp1Lo: .byte 0","roomTileProp1Hi: .byte 0",
                "roomTileProp2Lo: .byte 0","roomTileProp2Hi: .byte 0",
                "roomTileProp3Lo: .byte 0","roomTileProp3Hi: .byte 0",
                "roomTileXCellLo: .byte 0","roomTileXCellHi: .byte 0",
                "roomTileYCellLo: .byte 0","roomTileYCellHi: .byte 0",
                "roomTileYOffLoLo: .byte 0","roomTileYOffLoHi: .byte 0",
                "roomTileYOffHiLo: .byte 0","roomTileYOffHiHi: .byte 0",
            ]

        (d/"generated_room_tiles.asm").write_text("\n".join(tile_lines)+"\n",encoding="utf-8")

        # ------------------------------------------------------------
        # Variables.
        # ------------------------------------------------------------
        vlines=["// Generated 8-bit globals"]
        for v in self.project.variables:
            vlines.append(f"var_{self._safe_label(v.name)}: .byte {v.initial & 255}")
        inv_items=sorted(self.project.inventory.items,key=lambda x:x.item_id)
        vlines += [
            "// Persistent inventory storage ($ff item means empty)",
            "inventoryItems: .byte "+",".join(str(int(x)&255) for x in self.project.inventory.initial_items),
            "inventoryQuantities: .byte "+",".join(str(int(x)&255) for x in self.project.inventory.initial_quantities),
            f"inventorySelectedSlot: .byte {self.project.inventory.selected_slot & 255}",
            "inventoryDefinitionIds: .byte "+(",".join(str(x.item_id&255) for x in inv_items) if inv_items else "255"),
            "inventoryDefinitionTiles: .byte "+(",".join(str(x.tile_id&255) for x in inv_items) if inv_items else "0"),
            "inventoryDefinitionMax: .byte "+(",".join(str(x.max_stack&255) for x in inv_items) if inv_items else "1"),
        ]
        (d/"generated_variables.asm").write_text("\n".join(vlines)+"\n",encoding="utf-8")

        # ------------------------------------------------------------
        # Visual event/action source.
        # ------------------------------------------------------------
        elines=["// Generated visual event/action code","compareOtherTemp: .byte 0"]
        custom_calls=set()

        def num(v,default=0):
            try:return int(v,0)
            except:return default

        def object_selector_ids(v):
            out=[]
            for part in str(v).replace(";",",").split(","):
                part=part.strip()
                if not part:continue
                if "-" in part:
                    try:
                        a,b=[int(x.strip(),0) for x in part.split("-",1)]
                        step=1 if b>=a else -1
                        out.extend(range(a,b+step,step))
                    except:pass
                else:
                    try:out.append(int(part,0))
                    except:pass
            return [x for x in dict.fromkeys(out) if x in template_to_slots]

        def tile_collision_code(v):
            s=str(v).strip().lower()
            return {"any":0,"solid":1,"hazard":2,"none":0}.get(s,num(v,0)&255)

        id_to_index=template_first_index

        for oi,slot in enumerate(runtime_slots):
            oid=slot["template_id"]
            o=self.project.objects[oid]
            elines.append(f"events_slot_{oi:03d}: // template {oid}, instance {slot['instance_id']}")
            elines += [
                f"    ldx #{oi}",
                "    lda objectActive,x",
                "    bne !slot_active+",
                "    rts",
                "!slot_active:",
                "    lda objectRoom,x",
                "    cmp currentRoom",
                "    beq !slot_room+",
                "    rts",
                "!slot_room:",
            ]
            for idx,e in enumerate(o.events):
                skip=f"!skip_{oi}_{idx}+"
                evt=e.get("event","Every Frame")

                if evt=="Create":
                    elines += ["    lda frameCounter",f"    cmp #1",f"    bne {skip}"]
                elif evt=="Keyboard Held":
                    k=e.get("event_arg1","").upper()
                    # C64 CIA1 matrix: cached once per frame. Values are
                    # (column index PA0..PA7, row bit PB0..PB7), active low.
                    held_map={
                        "W":(1,0x02),
                        "A":(2,0x02),
                        "S":(5,0x02),
                        "D":(2,0x04),
                        "SPACE":(7,0x10),
                    }
                    if k in held_map:
                        colidx,rowmask=held_map[k]
                        elines += [
                            f"    lda keyMatrixCurrent+{colidx}",
                            f"    and #${rowmask:02x}",
                            f"    bne {skip}",
                        ]
                    else:
                        elines += [f"    // Keyboard Held '{k}' is not mapped yet",f"    jmp {skip}"]
                elif evt in ("Keyboard Pressed","Keyboard Pressed Over Object","Keyboard Pressed Over Topmost Object"):
                    k=e.get("event_arg1","").upper()
                    matrix_map={
                        "W":(1,0x02),
                        "A":(2,0x02),
                        "S":(5,0x02),
                        "D":(2,0x04),
                        "SPACE":(7,0x10),
                    }
                    if k in matrix_map:
                        colidx,rowmask=matrix_map[k]
                        # Pressed = down now (0) and up last frame (1).
                        elines += [
                            f"    lda keyMatrixCurrent+{colidx}",
                            f"    and #${rowmask:02x}",
                            f"    bne {skip}",
                            f"    lda keyMatrixPrevious+{colidx}",
                            f"    and #${rowmask:02x}",
                            f"    beq {skip}",
                        ]
                    else:
                        code=ord(k) if len(k)==1 else {
                            "DOWN":17,
                            "RIGHT":29,
                            "UP":145,
                            "LEFT":157,
                        }.get(k,0)
                        elines += ["    lda lastKey",f"    cmp #{code}",f"    bne {skip}"]
                    if evt=="Keyboard Pressed Over Object":
                        target=num(e.get("event_arg2"),-1)
                        if target in template_to_slots:
                            elines += [
                                f"    ldx #{oi}",
                                f"    lda #{target & 255}",
                                "    jsr CheckCollisionWithTemplate",
                                f"    bcc {skip}",
                            ]
                        else:
                            elines += [f"    jmp {skip}"]
                    elif evt=="Keyboard Pressed Over Topmost Object":
                        elines += [
                            f"    ldx #{oi}",
                            "    jsr CheckCollisionTopmost",
                            f"    bcc {skip}",
                        ]
                elif evt in ("Variable Equals","Variable Greater Than","Variable Less Than"):
                    lab=self._safe_label(e.get("event_arg1",""))
                    vv=num(e.get("event_arg2"),0)&255
                    elines += [f"    lda var_{lab}",f"    cmp #{vv}"]
                    if evt=="Variable Equals":
                        elines += [f"    bne {skip}"]
                    elif evt=="Variable Greater Than":
                        elines += [f"    bcc {skip}",f"    beq {skip}"]
                    else:
                        elines += [f"    bcs {skip}"]
                elif evt=="Every N Frames":
                    n=max(1,num(e.get("event_arg1"),1))
                    if (n & (n-1)) == 0 and n <= 128:
                        elines += ["    lda frameCounter",f"    and #{n-1}",f"    bne {skip}"]
                    else:
                        elines += [f"    // Non-power-of-two Every N Frames ({n}) currently runs every frame"]
                elif evt=="Object Leaves Screen":
                    elines += [f"    ldx #{oi}","    lda objectY,x","    cmp #200",f"    bcc {skip}"]
                elif evt=="Path Finished":
                    elines += [f"    ldx #{oi}","    lda objectPathDone,x",f"    beq {skip}","    lda #0","    sta objectPathDone,x"]
                elif evt=="Collision With Object":
                    target=num(e.get("event_arg1"),-1)
                    if target in template_to_slots:
                        elines += [
                            f"    ldx #{oi}",
                            f"    lda #{target & 255}",
                            "    jsr CheckCollisionWithTemplate",
                            f"    bcc {skip}",
                        ]
                    else:
                        elines += [f"    jmp {skip}"]
                elif evt=="Collision With Sprite":
                    sid=num(e.get("event_arg1"),-1)
                    if sid>=0:
                        elines += [
                            f"    ldx #{oi}",
                            f"    lda #{sid & 255}",
                            "    jsr CheckCollisionWithSprite",
                            f"    bcc {skip}",
                        ]
                    else:
                        elines += [f"    jmp {skip}"]
                elif evt=="Collision With Topmost Object":
                    elines += [
                        f"    ldx #{oi}",
                        "    jsr CheckCollisionTopmost",
                        f"    bcc {skip}",
                    ]
                elif evt=="Tile Collision":
                    tcode=tile_collision_code(e.get("event_arg1","Any"))
                    elines += [
                        f"    ldx #{oi}",
                        f"    lda #{tcode}",
                        "    jsr CheckObjectTileCollision",
                        f"    bcc {skip}",
                    ]
                elif evt=="Tile Property Equals":
                    pidx=max(0,min(3,num(e.get("event_arg1"),0)))
                    pval=num(e.get("event_arg2"),0)&255
                    elines += [
                        f"    lda #{pidx}","    sta tilePropertyIndex",
                        f"    lda #{pval}","    sta tilePropertyWanted",
                        f"    ldx #{oi}",
                        "    jsr CheckObjectTileProperty",
                        f"    bcc {skip}",
                    ]
                elif evt!="Every Frame":
                    elines += [f"    // Trigger '{evt}' reserved for later runtime layer"]

                cond=e.get("condition","None")
                ca=e.get("condition_arg1","")
                cv=num(e.get("condition_arg2"),0)

                if cond.startswith("Variable") and ca:
                    lab=self._safe_label(ca)
                    elines.append(f"    lda var_{lab}")
                    if cond=="Variable Equals":
                        elines += [f"    cmp #{cv & 255}",f"    bne {skip}"]
                    elif cond=="Variable Greater Than":
                        elines += [f"    cmp #{min(255,cv+1)}",f"    bcc {skip}"]
                    elif cond=="Variable Less Than":
                        elines += [f"    cmp #{cv & 255}",f"    bcs {skip}"]
                elif cond in ("Object Active","Object Inactive"):
                    if not str(ca).strip():
                        elines += [f"    ldx #{oi}","    lda objectActive,x"]
                        if cond=="Object Active":
                            elines += [f"    beq {skip}"]
                        else:
                            elines += [f"    bne {skip}"]
                    else:
                        target=num(ca,oid)
                        if target in id_to_index:
                            elines += [f"    ldx #{id_to_index[target]}","    lda objectActive,x"]
                            if cond=="Object Active":
                                elines += [f"    beq {skip}"]
                            else:
                                elines += [f"    bne {skip}"]
                elif cond in ("Object X Greater Than","Object X Less Than","Object Y Greater Than","Object Y Less Than"):
                    target=num(ca,oid) if str(ca).strip() else oid
                    if (not str(ca).strip()) or target in id_to_index:
                        ti=oi if not str(ca).strip() else id_to_index[target]
                        if cond.startswith("Object X"):
                            # 9-bit X comparisons; values 0-319.
                            elines += [f"    ldx #{ti}"]
                            if cv>=256:
                                if cond=="Object X Greater Than":
                                    elines += ["    lda objectXHi,x",f"    beq {skip}","    lda objectXLo,x",f"    cmp #{(cv-256)&255}",f"    bcc {skip}",f"    beq {skip}"]
                                else:
                                    elines += ["    lda objectXHi,x",f"    beq !xcond_ok_{oid}_{idx}+",
                                               "    lda objectXLo,x",f"    cmp #{(cv-256)&255}",f"    bcs {skip}",f"!xcond_ok_{oi}_{idx}:"]
                            else:
                                if cond=="Object X Greater Than":
                                    elines += ["    lda objectXHi,x",f"    bne !xcond_ok_{oid}_{idx}+",
                                               "    lda objectXLo,x",f"    cmp #{cv&255}",f"    bcc {skip}",f"    beq {skip}",f"!xcond_ok_{oi}_{idx}:"]
                                else:
                                    elines += ["    lda objectXHi,x",f"    bne {skip}","    lda objectXLo,x",f"    cmp #{cv&255}",f"    bcs {skip}"]
                        else:
                            elines += [f"    ldx #{ti}","    lda objectY,x",f"    cmp #{cv&255}"]
                            if cond=="Object Y Greater Than":
                                elines += [f"    bcc {skip}",f"    beq {skip}"]
                            else:
                                elines += [f"    bcs {skip}"]
                elif cond=="Variable Not Equals" and ca:
                    lab=self._safe_label(ca)
                    elines += [f"    lda var_{lab}",f"    cmp #{cv&255}",f"    beq {skip}"]
                elif cond=="Object In Room":
                    if not str(ca).strip():
                        elines += [f"    ldx #{oi}","    lda objectRoom,x",f"    cmp #{cv&255}",f"    bne {skip}"]
                    else:
                        target=num(ca,oid)
                        if target in id_to_index:
                            elines += [f"    ldx #{id_to_index[target]}","    lda objectRoom,x",f"    cmp #{cv&255}",f"    bne {skip}"]
                elif cond=="Self Overlaps Topmost Object":
                    elines += [f"    ldx #{oi}","    jsr CheckCollisionTopmost",f"    bcc {skip}"]
                elif cond=="Self Does Not Overlap Object":
                    targets=object_selector_ids(ca)
                    if targets:
                        for target in targets:
                            elines += [f"    ldx #{oi}",f"    lda #{target & 255}","    jsr CheckCollisionWithTemplate",f"    bcs {skip}"]
                    else:
                        elines += [f"    jmp {skip}"]
                elif cond=="Self Touching Tile":
                    tcode=tile_collision_code(ca or "Any")
                    elines += [
                        f"    ldx #{oi}",
                        f"    lda #{tcode}",
                        "    jsr CheckObjectTileCollision",
                        f"    bcc {skip}",
                    ]
                elif cond=="Self Tile Property Equals":
                    pidx=max(0,min(3,num(ca,0)))
                    pval=cv&255
                    elines += [
                        f"    lda #{pidx}","    sta tilePropertyIndex",
                        f"    lda #{pval}","    sta tilePropertyWanted",
                        f"    ldx #{oi}",
                        "    jsr CheckObjectTileProperty",
                        f"    bcc {skip}",
                    ]
                elif cond=="Self Center Tile Property Equals":
                    pidx=max(0,min(3,num(ca,0))); pval=cv&255
                    elines += [f"    lda #{pidx}","    sta tilePropertyIndex",f"    lda #{pval}","    sta tilePropertyWanted",f"    ldx #{oi}","    jsr CheckObjectCenterTileProperty",f"    bcc {skip}"]
                elif cond=="Self Tile Ahead Is":
                    dcode={"up":0,"right":1,"down":2,"left":3}.get(str(ca).strip().lower(),0)
                    wanted=str(e.get("condition_arg2","")).strip().lower()
                    tcode=tile_collision_code(wanted if wanted!="empty" else "Any")
                    elines += [f"    ldx #{oi}",f"    lda #{dcode}","    sta tileAheadDirection",f"    lda #{tcode}","    jsr CheckObjectTileAhead"]
                    if wanted=="empty": elines += [f"    bcs {skip}"]
                    else: elines += [f"    bcc {skip}"]
                elif cond=="Self Aligned To Tile":
                    axis={"both":0,"x":1,"y":2}.get(str(ca).strip().lower(),0)
                    elines += [f"    ldx #{oi}",f"    lda #{axis}","    jsr CheckObjectTileAligned",f"    bcc {skip}"]
                elif cond in ("Inventory Contains Item","Inventory Quantity At Least"):
                    iid=num(ca,0)&255;qty=max(1,num(e.get("condition_arg2","1"),1))&255
                    elines += [f"    lda #{iid}",f"    ldy #{qty}","    jsr InventoryHasAtLeast",f"    bcc {skip}"]
                elif cond=="Inventory Slot Equals":
                    slot=max(0,min(self.project.inventory.slot_count-1,num(ca,0)));iid=num(e.get("condition_arg2","255"),255)&255
                    elines += [f"    lda inventoryItems+{slot}",f"    cmp #{iid}",f"    bne {skip}"]
                elif (cond.startswith("Self Property ") or cond.startswith("Other Property ")) and cond.endswith(" Variable"):
                    prop=str(ca).strip().title()
                    op=cond.split(" Property ",1)[1].replace(" Variable","")
                    varlab=self._safe_label(e.get("condition_arg2",""))
                    use_other=cond.startswith("Other ")
                    if use_other:
                        elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}"]
                    else:
                        elines += [f"    ldx #{oi}"]
                    table={
                        "Y":"objectY","Active":"objectActive","Room":"objectRoom",
                        "Sprite":"objectSpriteId","Frame":"objectFrame",
                        "Object Id":"objectId","Instance Id":"objectInstanceId",
                        **{f"P{i}":f"objectP{i}" for i in range(8)}
                    }.get(prop)
                    if prop=="X":
                        # Variables are bytes; compare against X low byte only.
                        elines += ["    lda objectXLo,x",f"    cmp var_{varlab}"]
                    elif table:
                        elines += [f"    lda {table},x",f"    cmp var_{varlab}"]
                    if prop=="X" or table:
                        if op=="Equals": elines += [f"    bne {skip}"]
                        elif op=="Not Equals": elines += [f"    beq {skip}"]
                        elif op=="Greater Than": elines += [f"    bcc {skip}",f"    beq {skip}"]
                        elif op=="Less Than": elines += [f"    bcs {skip}"]
                elif cond.startswith("Self Property ") and cond.endswith(" Other Property"):
                    self_prop=str(ca).strip().title()
                    other_prop=str(e.get("condition_arg2","")).strip().title()
                    op=cond.split(" Property ",1)[1].replace(" Other Property","")
                    self_table={
                        "X":"objectXLo","Y":"objectY","Active":"objectActive","Room":"objectRoom",
                        "Sprite":"objectSpriteId","Frame":"objectFrame",
                        "Object Id":"objectId","Instance Id":"objectInstanceId",
                        **{f"P{i}":f"objectP{i}" for i in range(8)}
                    }.get(self_prop)
                    other_table={
                        "X":"objectXLo","Y":"objectY","Active":"objectActive","Room":"objectRoom",
                        "Sprite":"objectSpriteId","Frame":"objectFrame",
                        "Object Id":"objectId","Instance Id":"objectInstanceId",
                        **{f"P{i}":f"objectP{i}" for i in range(8)}
                    }.get(other_prop)
                    if self_table and other_table:
                        elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}",
                                   f"    lda {other_table},x","    sta compareOtherTemp",
                                   f"    ldx #{oi}",f"    lda {self_table},x","    cmp compareOtherTemp"]
                        if op=="Equals": elines += [f"    bne {skip}"]
                        elif op=="Not Equals": elines += [f"    beq {skip}"]
                        elif op=="Greater Than": elines += [f"    bcc {skip}",f"    beq {skip}"]
                        elif op=="Less Than": elines += [f"    bcs {skip}"]
                        elif op=="One Greater Than":
                            # SELF == OTHER + 1 (8-bit properties).
                            elines += ["    sec","    sbc #$01","    cmp compareOtherTemp",f"    bne {skip}"]
                        elif op=="One Less Than":
                            # SELF == OTHER - 1, equivalently SELF + 1 == OTHER.
                            elines += ["    clc","    adc #$01","    cmp compareOtherTemp",f"    bne {skip}"]
                elif cond.startswith("Self Property ") or cond.startswith("Other Property "):
                    prop=str(ca).strip().title()
                    op=cond.split(" Property ",1)[1]
                    use_other=cond.startswith("Other ")
                    if use_other:
                        elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}"]
                    else:
                        elines += [f"    ldx #{oi}"]
                    if prop=="X":
                        # Full 9-bit X property comparison.
                        if cv>=256:
                            elines += ["    lda objectXHi,x",f"    cmp #{(cv>>8)&1}"]
                            if op=="Equals":
                                elines += [f"    bne {skip}","    lda objectXLo,x",f"    cmp #{cv&255}",f"    bne {skip}"]
                            elif op=="Not Equals":
                                neqok=f"!prop_neq_{oi}_{idx}"
                                elines += [f"    bne {neqok}+","    lda objectXLo,x",f"    cmp #{cv&255}",f"    beq {skip}",f"{neqok}:"]
                            elif op=="Greater Than":
                                passlab=f"!prop_gt_{oi}_{idx}"
                                elines += [f"    bcc {skip}",f"    bne {passlab}+","    lda objectXLo,x",f"    cmp #{cv&255}",f"    bcc {skip}",f"    beq {skip}",f"{passlab}:"]
                            elif op=="Less Than":
                                passlab=f"!prop_lt_{oi}_{idx}"
                                elines += [f"    bcc {passlab}+",f"    bne {skip}","    lda objectXLo,x",f"    cmp #{cv&255}",f"    bcs {skip}",f"{passlab}:"]
                        else:
                            if op=="Equals":
                                elines += ["    lda objectXHi,x",f"    bne {skip}","    lda objectXLo,x",f"    cmp #{cv&255}",f"    bne {skip}"]
                            elif op=="Not Equals":
                                ok=f"!prop_neq_{oi}_{idx}"
                                elines += ["    lda objectXHi,x",f"    bne {ok}+","    lda objectXLo,x",f"    cmp #{cv&255}",f"    beq {skip}",f"{ok}:"]
                            elif op=="Greater Than":
                                ok=f"!prop_gt_{oi}_{idx}"
                                elines += ["    lda objectXHi,x",f"    bne {ok}+","    lda objectXLo,x",f"    cmp #{cv&255}",f"    bcc {skip}",f"    beq {skip}",f"{ok}:"]
                            elif op=="Less Than":
                                elines += ["    lda objectXHi,x",f"    bne {skip}","    lda objectXLo,x",f"    cmp #{cv&255}",f"    bcs {skip}"]
                    else:
                        table={
                            "Y":"objectY","Active":"objectActive","Room":"objectRoom",
                            "Sprite":"objectSpriteId","Frame":"objectFrame",
                            "Object Id":"objectId","Instance Id":"objectInstanceId",
                            **{f"P{i}":f"objectP{i}" for i in range(8)}
                        }.get(prop)
                        if table:
                            elines += [f"    lda {table},x",f"    cmp #{cv&255}"]
                            if op=="Equals": elines += [f"    bne {skip}"]
                            elif op=="Not Equals": elines += [f"    beq {skip}"]
                            elif op=="Greater Than": elines += [f"    bcc {skip}",f"    beq {skip}"]
                            elif op=="Less Than": elines += [f"    bcs {skip}"]

                for action_idx,do in enumerate(self._event_actions(e)):
                    act=do.get("action","Move X")
                    a=do.get("action_arg1","")
                    b=do.get("action_arg2","")

                    if act=="Move X":
                        amount=num(a,0)
                        elines += [
                            f"    ldx #{oi}",
                            "    lda objectXLo,x",
                            "    clc",
                            f"    adc #{amount & 255}",
                            "    sta objectXLo,x",
                        ]
                        # Maintain the 9th X bit for signed +/- movement in the common cases.
                        if amount > 0:
                            elines += ["    bcc !mx_done+","    inc objectXHi,x","!mx_done:"]
                        elif amount < 0:
                            elines += ["    bcs !mx_done+","    dec objectXHi,x","!mx_done:"]
                    elif act=="Move Y":
                        amount=num(a,0)
                        elines += [
                            f"    ldx #{oi}",
                            "    lda objectY,x",
                            "    clc",
                            f"    adc #{amount & 255}",
                            "    sta objectY,x",
                        ]
                    elif act=="Set Position":
                        xv=num(a,0); yv=num(b,0)
                        elines += [
                            f"    ldx #{oi}",
                            f"    lda #{xv & 255}","    sta objectXLo,x",
                            f"    lda #{(xv>>8)&1}","    sta objectXHi,x",
                            f"    lda #{yv & 255}","    sta objectY,x",
                        ]
                    elif act=="Set Variable":
                        elines += [f"    lda #{num(b,0)&255}",f"    sta var_{self._safe_label(a)}"]
                    elif act=="Add To Variable":
                        elines += [
                            f"    lda var_{self._safe_label(a)}",
                            "    clc",
                            f"    adc #{num(b,0)&255}",
                            f"    sta var_{self._safe_label(a)}",
                        ]
                    elif act=="Set Frame":
                        elines += [f"    ldx #{oi}",f"    lda #{num(a,0)&255}","    sta objectFrame,x"]
                    elif act in ("Set Other Property From Self Property","Set Self Property From Other Property"):
                        dst_prop=str(a).strip().title(); src_prop=str(b).strip().title()
                        table={"X":"objectXLo","Y":"objectY","Active":"objectActive","Room":"objectRoom",
                               "Frame":"objectFrame","P0":"objectP0","P1":"objectP1","P2":"objectP2","P3":"objectP3",
                               "P4":"objectP4","P5":"objectP5","P6":"objectP6","P7":"objectP7"}
                        dst_table=table.get(dst_prop); src_table={**table,"Sprite":"objectSpriteId","Object Id":"objectId","Instance Id":"objectInstanceId"}.get(src_prop)
                        if dst_table and src_table:
                            if act=="Set Other Property From Self Property":
                                elines += [f"    ldx #{oi}",f"    lda {src_table},x","    sta compareOtherTemp",
                                           "    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}",
                                           "    lda compareOtherTemp",f"    sta {dst_table},x"]
                            else:
                                elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}",f"    lda {src_table},x","    sta compareOtherTemp",
                                           f"    ldx #{oi}","    lda compareOtherTemp",f"    sta {dst_table},x"]
                    elif act in ("Toggle Self Property","Toggle Other Property"):
                        prop=str(a).strip().title()
                        table={"Active":"objectActive",**{f"P{i}":f"objectP{i}" for i in range(8)}}.get(prop)
                        if table:
                            if "Other" in act:
                                elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}"]
                            else:
                                elines += [f"    ldx #{oi}"]
                            elines += [f"    lda {table},x","    eor #$01",f"    sta {table},x"]
                    elif act in ("Set Frame From Self Property","Set Frame From Other Property"):
                        prop=str(a).strip().title()
                        table={"X":"objectXLo","Y":"objectY","Active":"objectActive","Room":"objectRoom",
                               "Sprite":"objectSpriteId","Frame":"objectFrame","Object Id":"objectId","Instance Id":"objectInstanceId",
                               **{f"P{i}":f"objectP{i}" for i in range(8)}}.get(prop)
                        if table:
                            if "Other" in act:
                                elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}",f"    lda {table},x",f"    ldx #{oi}","    sta objectFrame,x"]
                            else:
                                elines += [f"    ldx #{oi}",f"    lda {table},x","    sta objectFrame,x"]
                    elif act=="Set Variable Random":
                        elines += [f"    lda #{num(b,255)&255}","    jsr RandomInclusive",f"    sta var_{self._safe_label(a)}"]
                    elif act=="Bring Self To Front":
                        elines += [f"    ldx #{oi}","    jsr BringIndexToFront"]
                    elif act=="Bring Other To Front":
                        elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}","    jsr BringIndexToFront"]
                    elif act=="Send Self To Back":
                        elines += [f"    ldx #{oi}","    jsr SendIndexToBack"]
                    elif act=="Send Other To Back":
                        elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}","    jsr SendIndexToBack"]
                    elif act=="Set Object Active":
                        target=num(a,oid)
                        if target in id_to_index:
                            elines += [f"    ldx #{id_to_index[target]}",f"    lda #{1 if num(b,0) else 0}","    sta objectActive,x"]
                    elif act=="Destroy Object":
                        if not str(a).strip():
                            elines += [f"    ldx #{oi}","    lda #0","    sta objectActive,x"]
                        else:
                            target=num(a,oid)
                            if target in id_to_index:
                                elines += [f"    ldx #{id_to_index[target]}","    lda #0","    sta objectActive,x"]
                    elif act=="Create Object":
                        target=num(a,oid)
                        if target in template_to_slots:
                            elines += [
                                f"    lda #{target & 255}",
                                "    jsr FindInactiveTemplateSlot",
                                f"    bcc {skip}",
                                "    lda #$01",
                                "    sta objectActive,x",
                            ]
                    elif act=="Create Object At Object":
                        target=num(a,oid)
                        source=num(b,oid)
                        if target in template_to_slots and source in template_to_slots:
                            # Find a free live slot for the target template.
                            elines += [
                                f"    lda #{target & 255}",
                                "    jsr FindInactiveTemplateSlot",
                                f"    bcc {skip}",
                                "    stx spawnTargetSlot",
                            ]
                            # A blank/self source means the exact live instance
                            # currently executing this block. Explicit template
                            # IDs resolve to the first matching live slot.
                            if not str(b).strip() or source==oid:
                                elines += [f"    ldx #{oi}"]
                            else:
                                elines += [
                                    f"    lda #{source & 255}",
                                    "    jsr FindFirstTemplateSlot",
                                    f"    bcc {skip}",
                                ]
                            elines += [
                                "    ldy spawnTargetSlot",
                                "    lda objectXLo,x",
                                "    sta objectXLo,y",
                                "    lda objectXHi,x",
                                "    sta objectXHi,y",
                                "    lda objectY,x",
                                "    sec",
                                "    sbc objectHeight,y",
                                "    sta objectY,y",
                                "    lda objectRoom,x",
                                "    sta objectRoom,y",
                                "    lda #$00",
                                "    sta objectFrame,y",
                                "    sta objectAnimTimer,y",
                                "    lda #$01",
                                "    sta objectActive,y",
                            ]
                    elif act=="Set Object Room":
                        target=num(a,oid)
                        if target in id_to_index:
                            elines += [f"    ldx #{id_to_index[target]}",f"    lda #{num(b,0)&255}","    sta objectRoom,x"]
                    elif act in ("Start Path","Stop Path","Restart Path"):
                        elines += [f"    ldx #{oi}"]
                        if act=="Stop Path":
                            elines += ["    lda #0","    sta objectPathActive,x"]
                        else:
                            if act=="Restart Path":
                                elines += ["    lda #0","    sta objectPathPoint,x","    lda #1","    sta objectPathDir,x"]
                            elines += ["    lda #0","    sta objectPathDone,x","    lda #1","    sta objectPathActive,x"]
                    elif act=="Set Path":
                        pid=path_id_by_name.get(str(a).strip(),255)
                        if pid!=255:
                            elines += [f"    ldx #{oi}",f"    lda #{pid}","    sta objectPathId,x","    lda #0","    sta objectPathPoint,x","    sta objectPathDone,x","    lda #1","    sta objectPathDir,x","    sta objectPathActive,x"]
                    elif act=="Move Toward Object":
                        target=num(a,-1); speed=max(1,min(16,num(b,1)))
                        if target in id_to_index:
                            ti=id_to_index[target]
                            elines += [f"    ldx #{oi}",f"    ldy #{ti}",f"    lda #{speed}","    jsr MoveIndexTowardIndex"]
                    elif act=="Set Direction":
                        pi=max(0,min(7,num(str(a).strip()[1:] if str(a).strip().upper().startswith("P") else a,0)))
                        dc={"up":0,"right":1,"down":2,"left":3}.get(str(b).strip().lower(),0)
                        elines += [f"    ldx #{oi}",f"    lda #{dc}",f"    sta objectP{pi},x"]
                    elif act=="Move In Direction Property":
                        pi=max(0,min(7,num(str(a).strip()[1:] if str(a).strip().upper().startswith("P") else a,0)))
                        speed=max(1,min(16,num(b,1)))
                        elines += [f"    ldx #{oi}",f"    lda objectP{pi},x",f"    ldy #{speed}","    jsr MoveObjectInDirection"]
                    elif act=="Choose Available Direction":
                        pi=max(0,min(7,num(str(a).strip()[1:] if str(a).strip().upper().startswith("P") else a,0)))
                        avoid=1 if str(b).strip().lower().startswith("avoid") else 0
                        elines += [f"    ldx #{oi}",f"    lda #{pi}","    sta directionPropertyIndex",f"    lda #{avoid}","    sta directionAvoidReverse","    jsr ChooseObjectAvailableDirection"]
                    elif act=="Apply Queued Direction":
                        current_pi=max(0,min(7,num(str(a).strip()[1:] if str(a).strip().upper().startswith("P") else a,0)))
                        queued_pi=max(0,min(7,num(str(b).strip()[1:] if str(b).strip().upper().startswith("P") else b,1)))
                        qname=f"!queued_blocked_{oi}_{idx}_{action_idx}"
                        elines += [
                            f"    ldx #{oi}",
                            f"    lda objectP{queued_pi},x",
                            "    and #$03",
                            "    jsr CheckQueuedGridDirectionBlocked",
                            f"    bcs {qname}+",
                            f"    ldx #{oi}",
                            f"    lda objectP{queued_pi},x",
                            f"    sta objectP{current_pi},x",
                            f"{qname}:",
                        ]
                    elif act=="Snap Self To Tile":
                        axis={"both":0,"x":1,"y":2}.get(str(a).strip().lower(),0)
                        elines += [f"    ldx #{oi}",f"    lda #{axis}","    jsr SnapObjectToTile"]
                    elif act=="Set Tile Under Self":
                        elines += [f"    ldx #{oi}",f"    lda #{num(a,0)&255}","    jsr SetTileUnderObject"]
                    elif act=="Add Inventory Item":
                        elines += [f"    lda #{num(a,0)&255}",f"    ldy #{max(1,num(b,1))&255}","    jsr InventoryAddItem"]
                    elif act in ("Remove Inventory Item","Use Inventory Item"):
                        elines += [f"    lda #{num(a,0)&255}",f"    ldy #{max(1,num(b,1))&255}","    jsr InventoryRemoveItem"]
                    elif act=="Move Inventory Slot":
                        elines += [f"    ldx #{max(0,min(self.project.inventory.slot_count-1,num(a,0)))}",f"    ldy #{max(0,min(self.project.inventory.slot_count-1,num(b,0)))}","    jsr InventoryMoveSlot"]
                    elif act=="Set Selected Inventory Slot":
                        elines += [f"    lda #{max(0,min(self.project.inventory.slot_count-1,num(a,0)))}","    sta inventorySelectedSlot"]
                    elif act=="Render Inventory Tiles":
                        rid=self.project.inventory.display_room_id if str(a).strip().lower() in ("","configured room") else num(a,self.project.inventory.display_room_id)
                        elines += [f"    lda #{rid&255}","    jsr RenderInventoryTiles"]
                    elif act=="Set Object X":
                        target=num(a,oid); xv=num(b,0)
                        if target in id_to_index:
                            elines += [f"    ldx #{id_to_index[target]}",f"    lda #{xv&255}","    sta objectXLo,x",f"    lda #{(xv>>8)&1}","    sta objectXHi,x"]
                    elif act=="Set Object Y":
                        target=num(a,oid); yv=num(b,0)
                        if target in id_to_index:
                            elines += [f"    ldx #{id_to_index[target]}",f"    lda #{yv&255}","    sta objectY,x"]
                    elif act=="Change Room":
                        elines += [
                            f"    lda #{num(a,0)&255}",
                            "    sta currentRoom",
                            "    jsr LoadCurrentRoomSlots",
                            "    jsr LoadCurrentRoomBackground",
                        ]
                    elif act=="Destroy Colliding Object":
                        elines += [
                            "    ldx collisionOtherIndex",
                            "    lda #$00",
                            "    sta objectActive,x",
                        ]
                    elif act=="Destroy Collision Pair":
                        elines += [
                            "    ldx collisionOtherIndex",
                            "    lda #$00",
                            "    sta objectActive,x",
                            f"    ldx #{oi}",
                            "    sta objectActive,x",
                        ]
                    elif act=="Set Colliding Object Active":
                        elines += [
                            "    ldx collisionOtherIndex",
                            f"    lda #{1 if num(a,1) else 0}",
                            "    sta objectActive,x",
                        ]
                    elif act in ("Set Self Property","Add To Self Property","Set Other Property","Add To Other Property"):
                        prop=str(a).strip().title()
                        value=num(b,0)
                        use_other="Other" in act
                        add_mode=act.startswith("Add ")
                        if use_other:
                            elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}"]
                        else:
                            elines += [f"    ldx #{oi}"]
                        if prop=="X":
                            if add_mode:
                                elines += ["    lda objectXLo,x","    clc",f"    adc #{value&255}","    sta objectXLo,x"]
                                if value>0: elines += ["    bcc !propx_done+","    inc objectXHi,x","!propx_done:"]
                                elif value<0: elines += ["    bcs !propx_done+","    dec objectXHi,x","!propx_done:"]
                            else:
                                elines += [f"    lda #{value&255}","    sta objectXLo,x",f"    lda #{(value>>8)&1}","    sta objectXHi,x"]
                        else:
                            table={
                                "Y":"objectY","Active":"objectActive","Room":"objectRoom","Frame":"objectFrame",
                                **{f"P{i}":f"objectP{i}" for i in range(8)}
                            }.get(prop)
                            if table:
                                if add_mode:
                                    elines += [f"    lda {table},x","    clc",f"    adc #{value&255}",f"    sta {table},x"]
                                else:
                                    elines += [f"    lda #{value&255}",f"    sta {table},x"]
                    elif act in ("Set Variable From Self Property","Set Variable From Other Property"):
                        varlab=self._safe_label(a)
                        prop=str(b).strip().title()
                        if "Other" in act:
                            elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}"]
                        else:
                            elines += [f"    ldx #{oi}"]
                        table={
                            "X":"objectXLo","Y":"objectY","Active":"objectActive","Room":"objectRoom",
                            "Sprite":"objectSpriteId","Frame":"objectFrame",
                            "Object Id":"objectId","Instance Id":"objectInstanceId",
                            **{f"P{i}":f"objectP{i}" for i in range(8)}
                        }.get(prop)
                        if table:
                            elines += [f"    lda {table},x",f"    sta var_{varlab}"]
                    elif act in ("Set Self Property From Variable","Set Other Property From Variable"):
                        prop=str(a).strip().title()
                        varlab=self._safe_label(b)
                        if "Other" in act:
                            elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}"]
                        else:
                            elines += [f"    ldx #{oi}"]
                        table={
                            "Y":"objectY","Active":"objectActive","Room":"objectRoom","Frame":"objectFrame",
                            **{f"P{i}":f"objectP{i}" for i in range(8)}
                        }.get(prop)
                        if prop=="X":
                            elines += [f"    lda var_{varlab}","    sta objectXLo,x","    lda #$00","    sta objectXHi,x"]
                        elif table:
                            elines += [f"    lda var_{varlab}",f"    sta {table},x"]
                    elif act in (
                        "Add Variable To Self Property","Subtract Variable From Self Property",
                        "Add Variable To Other Property","Subtract Variable From Other Property"
                    ):
                        prop=str(a).strip().title()
                        varlab=self._safe_label(b)
                        use_other="Other" in act
                        subtract=act.startswith("Subtract ")
                        if use_other:
                            elines += ["    ldx collisionOtherIndex","    cpx #$ff",f"    beq {skip}"]
                        else:
                            elines += [f"    ldx #{oi}"]
                        table={
                            "Y":"objectY","Room":"objectRoom","Frame":"objectFrame",
                            **{f"P{i}":f"objectP{i}" for i in range(8)}
                        }.get(prop)
                        if prop=="X":
                            elines += ["    lda objectXLo,x", "    sec" if subtract else "    clc",
                                       f"    {'sbc' if subtract else 'adc'} var_{varlab}",
                                       "    sta objectXLo,x"]
                        elif table:
                            elines += [f"    lda {table},x", "    sec" if subtract else "    clc",
                                       f"    {'sbc' if subtract else 'adc'} var_{varlab}",
                                       f"    sta {table},x"]
                    elif act=="Restore Self Position":
                        elines += [
                            f"    ldx #{oi}",
                            "    lda objectLastXLo,x","    sta objectXLo,x",
                            "    lda objectLastXHi,x","    sta objectXHi,x",
                            "    lda objectLastY,x","    sta objectY,x",
                        ]
                    elif act=="Custom ASM Call":
                        lab=self._safe_label(a)
                        if lab:
                            custom_calls.add(lab)
                            elines.append(f"    jsr {lab}")
                    else:
                        elines.append(f"    // Action '{act}' reserved for later runtime layer")
    
                elines.append(f"!skip_{oi}_{idx}:")
            elines.append("    rts\n")

        (d/"generated_events.asm").write_text("\n".join(elines),encoding="utf-8")

        # ------------------------------------------------------------
        # Demo projects use the same generated runtime path as user projects.
        # ------------------------------------------------------------
        # Built-in demos must use the same generator path available to users.
        # No demo-specific game-rule source is emitted here.

        # ------------------------------------------------------------
        # Hires software-sprite runtime.
        # This first integrated renderer clears the bitmap each frame and
        # redraws all active hires objects. It is deliberately simple.
        # ------------------------------------------------------------
        row_lo=[]
        row_hi=[]
        for y in range(200):
            addr=0x2000+(y//8)*320+(y&7)
            row_lo.append(addr&255)
            row_hi.append((addr>>8)&255)

        screen_row_lo=[]
        screen_row_hi_a=[]
        screen_row_hi_b=[]
        for cy in range(25):
            addr_a=0x0400+cy*40
            addr_b=0x4400+cy*40
            screen_row_lo.append(addr_a&255)
            screen_row_hi_a.append((addr_a>>8)&255)
            screen_row_hi_b.append((addr_b>>8)&255)

        def asm_bytes(vals,per=16):
            return "\n".join(
                "    .byte "+",".join(f"${b:02x}" for b in vals[i:i+per])
                for i in range(0,len(vals),per)
            )

        runtime = """// Next64 integrated hires/multicolor software-sprite runtime v0.5
// Double-buffered, dirty-region, pixel-X proof runtime.
// Hybrid renderer: software sprites plus up to 8 VIC-II hardware sprites.

.const SS_IMG_LO  = $f0
.const SS_IMG_HI  = $f1
.const SS_MASK_LO = $f2
.const SS_MASK_HI = $f3
.const SS_DST_LO  = $f4
.const SS_DST_HI  = $f5

.const ROOM_MAP_LO       = $e0
.const ROOM_MAP_HI       = $e1
.const ROOM_PTRLO_LO     = $e2
.const ROOM_PTRLO_HI     = $e3
.const ROOM_PTRHI_LO     = $e4
.const ROOM_PTRHI_HI     = $e5
.const ROOM_COLL_LO      = $e6
.const ROOM_COLL_HI      = $e7
.const ROOM_XCELL_LO     = $e8
.const ROOM_XCELL_HI     = $e9
.const ROOM_YCELL_LO     = $ea
.const ROOM_YCELL_HI     = $eb
.const ROOM_YOFFLO_LO    = $ec
.const ROOM_YOFFLO_HI    = $ed
.const ROOM_YOFFHI_LO    = $ee
.const ROOM_YOFFHI_HI    = $ef

frontBuffer: .byte 0
renderBuffer: .byte 1
currentRoom: .byte START_ROOM_ID
drawIndex: .byte 0
drawOrderPos: .byte 0
ss_xcell: .byte 0
ss_xshift: .byte 0
ss_ypixel: .byte 0
ss_widthbytes: .byte 1
ss_clearbytes: .byte 1
ss_height: .byte 8
ss_xoff_lo: .byte 0
ss_xoff_hi: .byte 0
ss_cur_y: .byte 0
ss_rows_left: .byte 0
ss_col: .byte 0
ss_img_temp: .byte 0
ss_spill_temp: .byte 0
ss_shift_count: .byte 0
ss_mc_maskbyte: .byte 0
ss_mc_shift: .byte 0
ss_mask_temp: .byte 0
ss_mask_spill: .byte 0
ss_count: .byte 0
keyColumn: .byte 0
keyMask: .byte 0
keyResult: .byte 0
keySavedPortA: .byte 0
keySavedDDRA: .byte 0
keySavedDDRB: .byte 0
vicEnableMask: .byte 0
vicMulticolorMask: .byte 0
vicXHighMask: .byte 0
vicSlot: .byte 0
vicObjectIndex: .byte 0
roomMetaIndex: .byte 0
roomCols: .byte 40
roomRows: .byte 25
roomTileWidthBytesRT: .byte 1
roomTileHeightRT: .byte 8
roomDrawRow: .byte 0
roomDrawCol: .byte 0
roomDrawBaseY: .byte 0
roomDrawCurrentY: .byte 0
roomDrawXByte: .byte 0
roomTileRow: .byte 0
roomTileByte: .byte 0
roomTileIdTemp: .byte 0
tileCollisionWanted: .byte 0
tileCollisionSource: .byte 0
tilePropertyMode: .byte 0
tilePropertyIndex: .byte 0
tilePropertyWanted: .byte 0
tileAheadDirection: .byte 0
tileAheadWanted: .byte 0
directionPropertyIndex: .byte 0
directionAvoidReverse: .byte 0
directionTryCount: .byte 0
directionOriginal: .byte 0
directionMask: .byte 0
directionCandidate: .byte 0
tileAlignAxis: .byte 0
tileGridSize: .byte 8
tileGridRemainder: .byte 0
tileProbeXLo: .byte 0
tileProbeXHi: .byte 0
tileProbeY: .byte 0
tileProbeCol: .byte 0
tileProbeRowOffLo: .byte 0
tileProbeRowOffHi: .byte 0
tileWriteId: .byte 0
tileWriteCol: .byte 0
tileWriteRow: .byte 0
tileWriteXByte: .byte 0
tileWriteY: .byte 0
pathDiffHi: .byte 0
tileLeftCell: .byte 0
tileRightCell: .byte 0
tileTopCell: .byte 0
tileBottomCell: .byte 0
tileCurrentRow: .byte 0
tileRowOffLo: .byte 0
tileRowOffHi: .byte 0
tileMapIndexLo: .byte 0
tileMapIndexHi: .byte 0
tileRightXLo: .byte 0
tileRightXHi: .byte 0
tileBottomY: .byte 0
restoreAbsXByte: .byte 0
restoreTileCol: .byte 0
restoreTileRow: .byte 0
restoreWithinX: .byte 0
restoreWithinY: .byte 0
restoreOffsetLo: .byte 0
restoreOffsetHi: .byte 0
restoreTemp: .byte 0
ss_color_value: .byte 0
ss_color_row: .byte 0
ss_color_lastrow: .byte 0
ss_color_col: .byte 0

// Cached keyboard matrix. Scan once per frame instead of reprogramming CIA1
// separately for every visual-logic key condition. A pressed key reads as 0.
keyMatrixCurrent: .byte $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff
keyMatrixPrevious: .byte $ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff
keyboardColumnMasks: .byte $fe,$fd,$fb,$f7,$ef,$df,$bf,$7f
keySavedPortB: .byte 0

ScanKeyboardMatrix:
    // Preserve the caller's interrupt state and all CIA1 keyboard port state.
    php
    sei
    lda $dc00
    sta keySavedPortA
    lda $dc01
    sta keySavedPortB
    lda $dc02
    sta keySavedDDRA
    lda $dc03
    sta keySavedDDRB
    // CIA1 port A drives columns; port B reads rows.
    lda #$ff
    sta $dc02
    lda #$00
    sta $dc03
    ldy #$00
!scan_key_column:
    lda keyboardColumnMasks,y
    sta $dc00
    // Give the CIA/matrix a few cycles to settle before sampling Port B.
    nop
    nop
    lda $dc01
    sta keyMatrixCurrent,y
    iny
    cpy #$08
    bne !scan_key_column-
    // Restore latches first, then original data directions.
    lda keySavedPortA
    sta $dc00
    lda keySavedPortB
    sta $dc01
    lda keySavedDDRA
    sta $dc02
    lda keySavedDDRB
    sta $dc03

    // VER 09.12: KERNAL SCNKEY fallback.  The direct CIA matrix remains the
    // primary multi-key path, but SCNKEY gives us an independent, known-good
    // held-key result on real C64s and VICE.  Merge W/A/S/D/SPACE into the
    // cached matrix so existing Visual Logic needs no special case.
    jsr $ff9f
    lda $cb
    cmp #$09              // W
    bne !kernal_not_w+
    lda keyMatrixCurrent+1
    and #$fd
    sta keyMatrixCurrent+1
!kernal_not_w:
    lda $cb
    cmp #$0a              // A
    bne !kernal_not_a+
    lda keyMatrixCurrent+2
    and #$fd
    sta keyMatrixCurrent+2
!kernal_not_a:
    lda $cb
    cmp #$0d              // S
    bne !kernal_not_s+
    lda keyMatrixCurrent+5
    and #$fd
    sta keyMatrixCurrent+5
!kernal_not_s:
    lda $cb
    cmp #$12              // D
    bne !kernal_not_d+
    lda keyMatrixCurrent+2
    and #$fb
    sta keyMatrixCurrent+2
!kernal_not_d:
    lda $cb
    cmp #$3c              // SPACE
    bne !kernal_key_done+
    lda keyMatrixCurrent+7
    and #$ef
    sta keyMatrixCurrent+7
!kernal_key_done:
    plp
    rts

CommitKeyboardMatrix:
    ldy #$00
!commit_key_column:
    lda keyMatrixCurrent,y
    sta keyMatrixPrevious,y
    iny
    cpy #$08
    bne !commit_key_column-
    rts

// Compatibility helper retained for generated/custom code that may call it.
// A=column select mask, X=row mask. Returns Z=1 while the key is held.
CheckMatrixKeyHeld:
    sta keyColumn
    stx keyMask
    jsr ScanKeyboardMatrix
    ldy #$00
!find_key_column:
    lda keyboardColumnMasks,y
    cmp keyColumn
    beq !check_cached_key+
    iny
    cpy #$08
    bne !find_key_column-
    lda #$ff
    rts
!check_cached_key:
    lda keyMatrixCurrent,y
    and keyMask
    rts

InitSoftwareDisplay:
    lda #$00
    sta $d015
    sta $d017
    sta $d01d
    sta $d020
    sta $d021
    sta frontBuffer
    lda #$01
    sta renderBuffer

    lda #$18
    sta $d018
    lda #$3b
    sta $d011
    lda #SCENE_BG
    sta $d021
    lda #SCENE_MODE
    beq InitHiresMode
    lda #$18
    sta $d016
    jmp InitModeDone
InitHiresMode:
    lda #$08
    sta $d016
InitModeDone:
    lda #SCENE_MC1
    sta $d025
    lda #SCENE_MC2
    sta $d026

    lda $dd00
    and #$fc
    ora #$03
    sta $dd00

    lda #SCENE_MODE
    beq InitHiresColors
    // Multicolor bitmap mapping in VER 08.8:
    // screen high nibble = per-cell local color
    // screen low nibble  = MC2
    // Color RAM          = MC1
    lda #((SCENE_LOCAL << 4) | SCENE_MC2)
    jmp InitScreenColorReady
InitHiresColors:
    lda #$10
InitScreenColorReady:
    ldx #$00
InitColorsLoop:
    sta $0400,x
    sta $0500,x
    sta $0600,x
    sta $0700,x
    sta $4400,x
    sta $4500,x
    sta $4600,x
    sta $4700,x
    pha
    lda #SCENE_MC1
    sta $d800,x
    sta $d900,x
    sta $da00,x
    sta $db00,x
    pla
    inx
    bne InitColorsLoop

    jsr LoadCurrentRoomBackground
    jsr InitRasterMultiplexer
    rts

ClearBothBitmaps:
    lda #$00
    ldx #$00
ClearBothLoop:
    sta $2000,x
    sta $2100,x
    sta $2200,x
    sta $2300,x
    sta $2400,x
    sta $2500,x
    sta $2600,x
    sta $2700,x
    sta $2800,x
    sta $2900,x
    sta $2a00,x
    sta $2b00,x
    sta $2c00,x
    sta $2d00,x
    sta $2e00,x
    sta $2f00,x
    sta $3000,x
    sta $3100,x
    sta $3200,x
    sta $3300,x
    sta $3400,x
    sta $3500,x
    sta $3600,x
    sta $3700,x
    sta $3800,x
    sta $3900,x
    sta $3a00,x
    sta $3b00,x
    sta $3c00,x
    sta $3d00,x
    sta $3e00,x
    sta $3f00,x
    sta $6000,x
    sta $6100,x
    sta $6200,x
    sta $6300,x
    sta $6400,x
    sta $6500,x
    sta $6600,x
    sta $6700,x
    sta $6800,x
    sta $6900,x
    sta $6a00,x
    sta $6b00,x
    sta $6c00,x
    sta $6d00,x
    sta $6e00,x
    sta $6f00,x
    sta $7000,x
    sta $7100,x
    sta $7200,x
    sta $7300,x
    sta $7400,x
    sta $7500,x
    sta $7600,x
    sta $7700,x
    sta $7800,x
    sta $7900,x
    sta $7a00,x
    sta $7b00,x
    sta $7c00,x
    sta $7d00,x
    sta $7e00,x
    sta $7f00,x
    inx
    beq ClearBothDone
    jmp ClearBothLoop
ClearBothDone:
    rts

// ------------------------------------------------------------
// C64 Room tile renderer.
// The selected Room tile map is rendered directly into both bitmap buffers.
// Dirty software-sprite restoration reconstructs original bytes from the tile
// map and tile graphics, so no extra 8 KB background copy is required.
// ------------------------------------------------------------
FindRoomTileMeta:
    // A = room ID. Returns C=1, X=metadata index.
    sta roomMetaIndex
    ldx #$00
FindRoomTileMetaLoop:
    cpx #ROOM_TILE_META_COUNT
    bne FindRoomTileMetaCheck
    clc
    rts
FindRoomTileMetaCheck:
    lda roomTileId,x
    cmp roomMetaIndex
    beq FindRoomTileMetaFound
    inx
    jmp FindRoomTileMetaLoop
FindRoomTileMetaFound:
    stx roomMetaIndex
    sec
    rts

LoadRoomTilePointers:
    // X = room metadata index.
    stx roomMetaIndex
    lda roomTileMapLo,x
    sta ROOM_MAP_LO
    lda roomTileMapHi,x
    sta ROOM_MAP_HI
    lda roomTilePtrLoLo,x
    sta ROOM_PTRLO_LO
    lda roomTilePtrLoHi,x
    sta ROOM_PTRLO_HI
    lda roomTilePtrHiLo,x
    sta ROOM_PTRHI_LO
    lda roomTilePtrHiHi,x
    sta ROOM_PTRHI_HI
    lda roomTileCollisionLo,x
    sta ROOM_COLL_LO
    lda roomTileCollisionHi,x
    sta ROOM_COLL_HI
    lda roomTileXCellLo,x
    sta ROOM_XCELL_LO
    lda roomTileXCellHi,x
    sta ROOM_XCELL_HI
    lda roomTileYCellLo,x
    sta ROOM_YCELL_LO
    lda roomTileYCellHi,x
    sta ROOM_YCELL_HI
    lda roomTileYOffLoLo,x
    sta ROOM_YOFFLO_LO
    lda roomTileYOffLoHi,x
    sta ROOM_YOFFLO_HI
    lda roomTileYOffHiLo,x
    sta ROOM_YOFFHI_LO
    lda roomTileYOffHiHi,x
    sta ROOM_YOFFHI_HI
    lda roomTileCols,x
    sta roomCols
    lda roomTileRows,x
    sta roomRows
    lda roomTileWidthBytes,x
    sta roomTileWidthBytesRT
    lda roomTileHeight,x
    sta roomTileHeightRT
    rts

LoadCurrentRoomBackground:
    jsr ClearBothBitmaps
    lda currentRoom
    jsr FindRoomTileMeta
    bcs LoadCurrentRoomBGMetaFound
    rts

LoadCurrentRoomBGMetaFound:
    jsr LoadRoomTilePointers
    lda ROOM_PTRLO_LO
    ora ROOM_PTRLO_HI
    bne RoomRenderHaveTiles
    rts

RoomRenderHaveTiles:
    lda #$00
    sta roomDrawRow
    sta roomDrawBaseY

RoomRenderRowLoop:
    lda roomDrawRow
    cmp roomRows
    bcc RoomRenderRowOkay
    rts
RoomRenderRowOkay:
    lda #$00
    sta roomDrawCol
    sta roomDrawXByte

RoomRenderCellLoop:
    lda roomDrawCol
    cmp roomCols
    bcc RoomRenderCellOkay
    clc
    lda roomDrawBaseY
    adc roomTileHeightRT
    sta roomDrawBaseY
    inc roomDrawRow
    jmp RoomRenderRowLoop

RoomRenderCellOkay:
    ldy #$00
    lda (ROOM_MAP_LO),y
    sta roomTileIdTemp
    inc ROOM_MAP_LO
    bne RoomRenderMapAdvanced
    inc ROOM_MAP_HI
RoomRenderMapAdvanced:

    lda roomTileIdTemp
    cmp #$ff
    bne RoomRenderHaveTile
    jmp RoomRenderNextCell
RoomRenderHaveTile:

    tay
    lda (ROOM_PTRLO_LO),y
    sta SS_IMG_LO
    lda (ROOM_PTRHI_LO),y
    sta SS_IMG_HI

    lda #$00
    sta roomTileRow
    lda roomDrawBaseY
    sta roomDrawCurrentY

RoomRenderTileRowLoop:
    lda roomTileRow
    cmp roomTileHeightRT
    bcc RoomRenderTileRowOkay
    jmp RoomRenderNextCell
RoomRenderTileRowOkay:
    ldx roomDrawCurrentY
    cpx #200
    bcc RoomRenderYInBounds
    jmp RoomRenderNextCell
RoomRenderYInBounds:
    // C64 bitmap memory is character-cell interleaved: neighboring
    // 8-pixel columns are 8 bytes apart, not 1 byte apart.
    // Convert the logical bitmap-byte column to a 16-bit *8 offset.
    lda roomDrawXByte
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi

    lda bitmapRowLo,x
    clc
    adc ss_xoff_lo
    sta SS_DST_LO
    sta SS_MASK_LO
    lda bitmapRowHi,x
    adc ss_xoff_hi
    sta SS_DST_HI
    clc
    adc #$40
    sta SS_MASK_HI

    lda #$00
    sta roomTileByte
RoomRenderTileByteLoop:
    lda roomTileByte
    cmp roomTileWidthBytesRT
    bcc RoomRenderTileByteOkay
    jmp RoomRenderTileRowDone
RoomRenderTileByteOkay:
    // Tile source bytes are packed, but destination bitmap cells are
    // separated by 8 bytes horizontally.
    tay
    lda (SS_IMG_LO),y
    sta roomTileIdTemp
    ldx roomTileByte
    ldy offset8,x
    lda roomTileIdTemp
    sta (SS_DST_LO),y
    sta (SS_MASK_LO),y
    inc roomTileByte
    jmp RoomRenderTileByteLoop

RoomRenderTileRowDone:
    clc
    lda SS_IMG_LO
    adc roomTileWidthBytesRT
    sta SS_IMG_LO
    bcc RoomRenderSourceAdvanced
    inc SS_IMG_HI
RoomRenderSourceAdvanced:
    inc roomDrawCurrentY
    inc roomTileRow
    jmp RoomRenderTileRowLoop

RoomRenderNextCell:
    clc
    lda roomDrawXByte
    adc roomTileWidthBytesRT
    sta roomDrawXByte
    inc roomDrawCol
    jmp RoomRenderCellLoop

SelectBackBuffer:
    lda frontBuffer
    eor #$01
    sta renderBuffer
    rts

SwapDisplayBuffer:
    lda renderBuffer
    sta frontBuffer
    beq ShowBufferA
    lda $dd00
    and #$fc
    ora #$02
    sta $dd00
    rts
ShowBufferA:
    lda $dd00
    and #$fc
    ora #$03
    sta $dd00
    rts

SetDestinationFromCurrentRow:
    ldx ss_cur_y
    lda bitmapRowLo,x
    clc
    adc ss_xoff_lo
    sta SS_DST_LO
    lda bitmapRowHi,x
    adc ss_xoff_hi
    ldx renderBuffer
    beq SetDestDone
    clc
    adc #$40
SetDestDone:
    sta SS_DST_HI
    rts

ErasePreviousObjects:
    ldx #$00
ErasePrevLoop:
    cpx #OBJ_COUNT
    bne ErasePrevContinue
    jmp ErasePrevDone
ErasePrevContinue:
    stx drawIndex
    lda objectRenderer,x
    beq ErasePrevContinueSoftware
    jmp ErasePrevNext
ErasePrevContinueSoftware:
    lda objectRoom,x
    cmp currentRoom
    beq ErasePrevContinueSoftwareRoomOkay
    jmp ErasePrevNext
ErasePrevContinueSoftwareRoomOkay:
    lda objectMode,x
    cmp #SCENE_MODE
    beq EraseModeOkay
    jmp ErasePrevNext
EraseModeOkay:
    lda renderBuffer
    beq EraseA

EraseB:
    lda objectPrevBActive,x
    bne EraseBActive
    jmp ErasePrevNext
EraseBActive:
    lda objectPrevBXLo,x
    sta ss_img_temp
    lda objectMode,x
    beq EraseBShiftHires
    lda ss_img_temp
    and #$06
    sta ss_xshift
    jmp EraseBShiftDone
EraseBShiftHires:
    lda ss_img_temp
    and #$07
    sta ss_xshift
EraseBShiftDone:
    lda ss_img_temp
    lsr
    lsr
    lsr
    sta ss_xcell
    lda objectPrevBXHi,x
    beq EraseBHiDone
    lda ss_xcell
    clc
    adc #32
    sta ss_xcell
EraseBHiDone:
    lda objectPrevBY,x
    sta ss_ypixel
    jmp EraseHaveState

EraseA:
    lda objectPrevAActive,x
    bne EraseAActive
    jmp ErasePrevNext
EraseAActive:
    lda objectPrevAXLo,x
    sta ss_img_temp
    lda objectMode,x
    beq EraseAShiftHires
    lda ss_img_temp
    and #$06
    sta ss_xshift
    jmp EraseAShiftDone
EraseAShiftHires:
    lda ss_img_temp
    and #$07
    sta ss_xshift
EraseAShiftDone:
    lda ss_img_temp
    lsr
    lsr
    lsr
    sta ss_xcell
    lda objectPrevAXHi,x
    beq EraseAHiDone
    lda ss_xcell
    clc
    adc #32
    sta ss_xcell
EraseAHiDone:
    lda objectPrevAY,x
    sta ss_ypixel

EraseHaveState:
    lda ss_ypixel
    cmp #200
    bcc EraseYOkay
    jmp ErasePrevNext
EraseYOkay:
    lda ss_xcell
    cmp #40
    bcc EraseXOkay
    jmp ErasePrevNext
EraseXOkay:

    lda objectWidthBytes,x
    sta ss_clearbytes
    lda ss_xshift
    beq EraseWidthReady
    inc ss_clearbytes
EraseWidthReady:
    lda ss_xcell
    clc
    adc ss_clearbytes
    cmp #41
    bcc EraseWidthInBounds
    jmp ErasePrevNext
EraseWidthInBounds:
    lda objectHeight,x
    sta ss_height
    jsr RestoreSpriteRect
    ldx drawIndex
    lda objectActive,x
    bne ErasePrevNext
    lda renderBuffer
    beq ClearPrevAFlag
    lda #$00
    sta objectPrevBActive,x
    jmp ErasePrevNext
ClearPrevAFlag:
    lda #$00
    sta objectPrevAActive,x

ErasePrevNext:
    ldx drawIndex
    inx
    jmp ErasePrevLoop
ErasePrevDone:
    rts

// Clear the latest logical object rectangle in the selected back buffer too.
// Each bitmap is displayed every other frame, so its saved previous rectangle
// can lag the current logical position. Clearing both rectangles before redraw
// prevents sub-byte/fast-moving software sprites from leaving isolated pixels.
EraseCurrentObjectRects:
    ldx #$00
EraseCurrentLoop:
    cpx #OBJ_COUNT
    bne EraseCurrentContinue
    jmp EraseCurrentDone
EraseCurrentContinue:
    stx drawIndex
    lda objectRenderer,x
    beq EraseCurrentContinueSoftware
    jmp EraseCurrentNext
EraseCurrentContinueSoftware:
    lda objectRoom,x
    cmp currentRoom
    beq EraseCurrentContinueSoftwareRoomOkay
    jmp EraseCurrentNext
EraseCurrentContinueSoftwareRoomOkay:
    lda objectActive,x
    bne EraseCurrentActive
    jmp EraseCurrentNext
EraseCurrentActive:
    lda objectMode,x
    cmp #SCENE_MODE
    beq EraseCurrentModeOkay
    jmp EraseCurrentNext
EraseCurrentModeOkay:
    // The saved dirty rectangle already clears stationary objects. The second
    // safety clear is needed only when the object's logical position differs
    // from the position last drawn into this specific back buffer.
    lda renderBuffer
    beq EraseCurrentCompareA
EraseCurrentCompareB:
    lda objectPrevBActive,x
    bne EraseCurrentBWasActive
    jmp EraseCurrentNext
EraseCurrentBWasActive:
    lda objectXLo,x
    cmp objectPrevBXLo,x
    bne EraseCurrentMoved
    lda objectXHi,x
    cmp objectPrevBXHi,x
    bne EraseCurrentMoved
    lda objectY,x
    cmp objectPrevBY,x
    bne EraseCurrentMoved
    jmp EraseCurrentNext
EraseCurrentCompareA:
    lda objectPrevAActive,x
    bne EraseCurrentAWasActive
    jmp EraseCurrentNext
EraseCurrentAWasActive:
    lda objectXLo,x
    cmp objectPrevAXLo,x
    bne EraseCurrentMoved
    lda objectXHi,x
    cmp objectPrevAXHi,x
    bne EraseCurrentMoved
    lda objectY,x
    cmp objectPrevAY,x
    bne EraseCurrentMoved
    jmp EraseCurrentNext
EraseCurrentMoved:
    lda objectXLo,x
    sta ss_img_temp
    lda objectMode,x
    beq EraseCurrentShiftHires
    lda ss_img_temp
    and #$06
    sta ss_xshift
    jmp EraseCurrentShiftDone
EraseCurrentShiftHires:
    lda ss_img_temp
    and #$07
    sta ss_xshift
EraseCurrentShiftDone:
    lda ss_img_temp
    lsr
    lsr
    lsr
    sta ss_xcell
    lda objectXHi,x
    beq EraseCurrentHiDone
    lda ss_xcell
    clc
    adc #32
    sta ss_xcell
EraseCurrentHiDone:
    lda objectY,x
    sta ss_ypixel

    lda ss_ypixel
    cmp #200
    bcc EraseCurrentYOkay
    jmp EraseCurrentNext
EraseCurrentYOkay:
    lda ss_xcell
    cmp #40
    bcc EraseCurrentXOkay
    jmp EraseCurrentNext
EraseCurrentXOkay:
    lda objectWidthBytes,x
    sta ss_clearbytes
    lda ss_xshift
    beq EraseCurrentWidthReady
    inc ss_clearbytes
EraseCurrentWidthReady:
    lda ss_xcell
    clc
    adc ss_clearbytes
    cmp #41
    bcc EraseCurrentWidthOkay
    jmp EraseCurrentNext
EraseCurrentWidthOkay:
    lda objectHeight,x
    sta ss_height
    jsr RestoreSpriteRect
EraseCurrentNext:
    ldx drawIndex
    inx
    jmp EraseCurrentLoop
EraseCurrentDone:
    rts

SaveCurrentObjectState:
    ldx #$00
SaveStateLoop:
    cpx #OBJ_COUNT
    beq SaveStateDone
    lda renderBuffer
    beq SaveStateA
    lda objectXLo,x
    sta objectPrevBXLo,x
    lda objectXHi,x
    sta objectPrevBXHi,x
    lda objectY,x
    sta objectPrevBY,x
    lda objectActive,x
    sta objectPrevBActive,x
    jmp SaveStateNext
SaveStateA:
    lda objectXLo,x
    sta objectPrevAXLo,x
    lda objectXHi,x
    sta objectPrevAXHi,x
    lda objectY,x
    sta objectPrevAY,x
    lda objectActive,x
    sta objectPrevAActive,x
SaveStateNext:
    inx
    jmp SaveStateLoop
SaveStateDone:
    rts

// Restore a dirty sprite rectangle. Current C64 runtime background is blank,
 // so restoration writes zero. When room-tile rendering is enabled, this is
 // the single hook that will copy the underlying room background instead.
// ------------------------------------------------------------
// Multicolor bitmap local-color compositor - VER 08.8.
//
// Color RAM ($D800) is NOT double-buffered. Writing per-object colors there
// while rendering the back bitmap made the currently displayed frame visibly
// change row-by-row before SwapDisplayBuffer.
//
// VER 08.8 keeps MC1 permanently in Color RAM and moves the per-object local
// color to the HIGH nibble of the screen byte. Screen RAM is already separate
// for bitmap A ($0400) and bitmap B ($4400), so local-color changes remain
// hidden until the matching bitmap is swapped to the VIC-II.
//
// Logical editor colors are encoded as:
//   value 1 (MC1)   -> VIC bitmap %11 -> Color RAM
//   value 2 (MC2)   -> VIC bitmap %10 -> screen low nibble
//   value 3 (local) -> VIC bitmap %01 -> screen high nibble
//
// Inputs:
//   A = local VIC color index
//   ss_xcell / ss_clearbytes = physical 8-pixel cells touched
//   ss_ypixel / ss_height    = physical vertical rectangle
// ------------------------------------------------------------
SetSoftwareHiresScreenRect:
    // A = foreground color. Preserve each cell's existing background nibble.
    and #$0f
    asl
    asl
    asl
    asl
    sta ss_color_value
    lda ss_ypixel
    lsr
    lsr
    lsr
    sta ss_color_row
    clc
    lda ss_ypixel
    adc ss_height
    bcc !hsc_bottom_no_overflow+
    lda #199
    jmp !hsc_bottom_ready+
!hsc_bottom_no_overflow:
    beq !hsc_bottom_zero+
    sec
    sbc #1
    cmp #200
    bcc !hsc_bottom_ready+
    lda #199
    jmp !hsc_bottom_ready+
!hsc_bottom_zero:
    lda #0
!hsc_bottom_ready:
    lsr
    lsr
    lsr
    sta ss_color_lastrow
!hsc_row_loop:
    lda ss_color_row
    cmp #25
    bcc !hsc_row_valid+
    rts
!hsc_row_valid:
    tay
    lda screenRowLo,y
    clc
    adc ss_xcell
    sta SS_DST_LO
    lda renderBuffer
    beq !hsc_use_a+
    lda screenRowHiB,y
    jmp !hsc_have_hi+
!hsc_use_a:
    lda screenRowHiA,y
!hsc_have_hi:
    adc #0
    sta SS_DST_HI
    ldy #0
!hsc_col_loop:
    cpy ss_clearbytes
    bcs !hsc_row_done+
    lda (SS_DST_LO),y
    and #$0f
    ora ss_color_value
    sta (SS_DST_LO),y
    iny
    jmp !hsc_col_loop-
!hsc_row_done:
    lda ss_color_row
    cmp ss_color_lastrow
    beq !hsc_done+
    inc ss_color_row
    jmp !hsc_row_loop-
!hsc_done:
    rts

SetSoftwareScreenRect:
    and #$0f
    asl
    asl
    asl
    asl
    ora #SCENE_MC2
    sta ss_color_value

    lda ss_ypixel
    lsr
    lsr
    lsr
    sta ss_color_row

    clc
    lda ss_ypixel
    adc ss_height
    bcc SetScreenBottomNoOverflow
    lda #199
    jmp SetScreenBottomReady
SetScreenBottomNoOverflow:
    beq SetScreenBottomZero
    sec
    sbc #$01
    cmp #200
    bcc SetScreenBottomReady
    lda #199
    jmp SetScreenBottomReady
SetScreenBottomZero:
    lda #$00
SetScreenBottomReady:
    lsr
    lsr
    lsr
    sta ss_color_lastrow

SetScreenRowLoop:
    lda ss_color_row
    cmp #25
    bcc SetScreenRowValid
    rts
SetScreenRowValid:
    tay
    lda screenRowLo,y
    clc
    adc ss_xcell
    sta SS_DST_LO

    lda renderBuffer
    beq SetScreenUseA
    lda screenRowHiB,y
    jmp SetScreenHaveHi
SetScreenUseA:
    lda screenRowHiA,y
SetScreenHaveHi:
    adc #$00
    sta SS_DST_HI

    ldy #$00
SetScreenColumnLoop:
    cpy ss_clearbytes
    bcc SetScreenWrite
    jmp SetScreenRowDone
SetScreenWrite:
    lda ss_color_value
    sta (SS_DST_LO),y
    iny
    jmp SetScreenColumnLoop

SetScreenRowDone:
    lda ss_color_row
    cmp ss_color_lastrow
    beq SetScreenDone
    inc ss_color_row
    jmp SetScreenRowLoop
SetScreenDone:
    rts

// Return the original Room background byte for screen byte X/Y.
// restoreAbsXByte = 0..39, ss_cur_y = 0..199. A returns bitmap byte.
GetRoomBackgroundByte:
    lda restoreAbsXByte
    cmp #40
    bcc GetRoomBGXValid
    lda #$00
    rts
GetRoomBGXValid:
    lda ss_cur_y
    cmp #200
    bcc GetRoomBGYValid
    lda #$00
    rts
GetRoomBGYValid:

    // Tile column from physical X = bitmap byte * 8.
    lda restoreAbsXByte
    cmp #32
    bcc GetRoomBGXPage0
    sec
    sbc #32
    asl
    asl
    asl
    tay
    lda ROOM_XCELL_LO
    sta SS_MASK_LO
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_MASK_HI
    lda (SS_MASK_LO),y
    sta restoreTileCol
    jmp GetRoomBGXCellReady
GetRoomBGXPage0:
    asl
    asl
    asl
    tay
    lda ROOM_XCELL_LO
    sta SS_MASK_LO
    lda ROOM_XCELL_HI
    sta SS_MASK_HI
    lda (SS_MASK_LO),y
    sta restoreTileCol
GetRoomBGXCellReady:

    // Tile row and room-map row offset from Y.
    ldy ss_cur_y
    lda (ROOM_YCELL_LO),y
    sta restoreTileRow
    lda (ROOM_YOFFLO_LO),y
    sta tileMapIndexLo
    lda (ROOM_YOFFHI_LO),y
    sta tileMapIndexHi

    // Map address = room map + row offset + tile column.
    clc
    lda ROOM_MAP_LO
    adc tileMapIndexLo
    sta SS_MASK_LO
    lda ROOM_MAP_HI
    adc tileMapIndexHi
    sta SS_MASK_HI
    clc
    lda SS_MASK_LO
    adc restoreTileCol
    sta SS_MASK_LO
    bcc GetRoomBGMapReady
    inc SS_MASK_HI
GetRoomBGMapReady:
    ldy #$00
    lda (SS_MASK_LO),y
    cmp #$ff
    bne GetRoomBGHaveTile
    lda #$00
    rts

GetRoomBGHaveTile:
    tay
    lda (ROOM_PTRLO_LO),y
    sta SS_IMG_LO
    lda (ROOM_PTRHI_LO),y
    sta SS_IMG_HI

    // within-X byte = absolute bitmap byte - tileCol * tileWidthBytes.
    lda #$00
    sta restoreTemp
    ldx restoreTileCol
GetRoomBGWithinXLoop:
    cpx #$00
    beq GetRoomBGWithinXReady
    clc
    lda restoreTemp
    adc roomTileWidthBytesRT
    sta restoreTemp
    dex
    jmp GetRoomBGWithinXLoop
GetRoomBGWithinXReady:
    sec
    lda restoreAbsXByte
    sbc restoreTemp
    sta restoreWithinX

    // within-Y = y - tileRow * tileHeight.
    lda #$00
    sta restoreTemp
    ldx restoreTileRow
GetRoomBGWithinYLoop:
    cpx #$00
    beq GetRoomBGWithinYReady
    clc
    lda restoreTemp
    adc roomTileHeightRT
    sta restoreTemp
    dex
    jmp GetRoomBGWithinYLoop
GetRoomBGWithinYReady:
    sec
    lda ss_cur_y
    sbc restoreTemp
    sta restoreWithinY

    // Source offset = withinY * widthBytes + withinX.
    lda #$00
    sta restoreOffsetLo
    sta restoreOffsetHi
    ldx restoreWithinY
GetRoomBGOffsetLoop:
    cpx #$00
    beq GetRoomBGOffsetReady
    clc
    lda restoreOffsetLo
    adc roomTileWidthBytesRT
    sta restoreOffsetLo
    bcc GetRoomBGOffsetNoCarry
    inc restoreOffsetHi
GetRoomBGOffsetNoCarry:
    dex
    jmp GetRoomBGOffsetLoop
GetRoomBGOffsetReady:
    clc
    lda restoreOffsetLo
    adc restoreWithinX
    sta restoreOffsetLo
    bcc GetRoomBGOffsetAdded
    inc restoreOffsetHi
GetRoomBGOffsetAdded:

    clc
    lda SS_IMG_LO
    adc restoreOffsetLo
    sta SS_IMG_LO
    lda SS_IMG_HI
    adc restoreOffsetHi
    sta SS_IMG_HI
    ldy #$00
    lda (SS_IMG_LO),y
    rts

RestoreSpriteRect:
    // Restore the back buffer's per-cell local color as well as its bitmap bytes.
    // This writes only the non-visible screen buffer; Color RAM is untouched.
    lda #SCENE_MODE
    beq RestoreRectSkipColor
    lda #SCENE_LOCAL
    jsr SetSoftwareScreenRect
RestoreRectSkipColor:
    // Load Room/tile pointers once for this dirty rectangle.
    lda currentRoom
    jsr FindRoomTileMeta
    bcs RestoreRectHaveMeta
    jmp ClearSpriteRectFallback
RestoreRectHaveMeta:
    jsr LoadRoomTilePointers
    // VER 09.1: A Room can have tile metadata even when it has no tile
    // graphics/pointer tables (for example a plain bitmap/card-game room).
    // The old path still called GetRoomBackgroundByte in that case, causing
    // null-pointer reads through $0000 and bogus tile-row/column loops.  That
    // produced software-sprite trails, corrupted restores, and severe stalls.
    // If no tile pointer table exists, restore as a plain background instead.
    lda ROOM_PTRLO_LO
    ora ROOM_PTRLO_HI
    bne RestoreRectTileDataReady
    jmp ClearSpriteRectFallback
RestoreRectTileDataReady:

    lda ss_xcell
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    lda ss_ypixel
    sta ss_cur_y
    lda ss_height
    sta ss_rows_left

RestoreRectRow:
    lda ss_cur_y
    cmp #200
    bcc RestoreRectRowOkay
    rts
RestoreRectRowOkay:
    jsr SetDestinationFromCurrentRow
    lda #$00
    sta ss_col

RestoreRectByte:
    clc
    lda ss_xcell
    adc ss_col
    sta restoreAbsXByte
    jsr GetRoomBackgroundByte
    ldx ss_col
    ldy offset8,x
    sta (SS_DST_LO),y
    inc ss_col
    lda ss_col
    cmp ss_clearbytes
    bne RestoreRectByte

    inc ss_cur_y
    dec ss_rows_left
    bne RestoreRectRow
    rts

ClearSpriteRectFallback:
    lda ss_xcell
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    lda ss_ypixel
    sta ss_cur_y
    lda ss_height
    sta ss_rows_left
ClearFallbackRow:
    lda ss_cur_y
    cmp #200
    bcs ClearFallbackDone
    jsr SetDestinationFromCurrentRow
    lda #$00
    sta ss_col
ClearFallbackByte:
    ldx ss_col
    ldy offset8,x
    lda #$00
    sta (SS_DST_LO),y
    inc ss_col
    lda ss_col
    cmp ss_clearbytes
    bne ClearFallbackByte
    inc ss_cur_y
    dec ss_rows_left
    bne ClearFallbackRow
ClearFallbackDone:
    rts

// VER 09.1 named path runtime. Each active object moves toward its current
// waypoint, then advances according to Loop / Patrol / Once mode.
pathObjIndex: .byte 0
pathTargetXLo: .byte 0
pathTargetXHi: .byte 0
pathTargetY: .byte 0
pathTempIndex: .byte 0
pathDiffLo: .byte 0

// Move object X toward object Y by A pixels on each axis.
// X=self runtime index, Y=target runtime index, A=speed (1-16).
// Movement is performed as one-pixel steps so it cannot overshoot a target.
MoveIndexTowardIndex:
    sta pathMoveSpeed
    stx pathMoveSelf
    sty pathMoveTarget
!mt_step:
    lda pathMoveSpeed
    beq !mt_done+
    dec pathMoveSpeed
    ldx pathMoveSelf
    ldy pathMoveTarget
    lda objectXHi,x
    cmp objectXHi,y
    bcc !mt_x_right+
    bne !mt_x_left+
    lda objectXLo,x
    cmp objectXLo,y
    bcc !mt_x_right+
    beq !mt_y+
!mt_x_left:
    lda objectXLo,x
    bne !mt_x_left_low+
    dec objectXHi,x
!mt_x_left_low:
    dec objectXLo,x
    jmp !mt_y+
!mt_x_right:
    inc objectXLo,x
    bne !mt_y+
    inc objectXHi,x
!mt_y:
    ldx pathMoveSelf
    ldy pathMoveTarget
    lda objectY,x
    cmp objectY,y
    bcc !mt_y_down+
    beq !mt_next+
    dec objectY,x
    jmp !mt_next+
!mt_y_down:
    inc objectY,x
!mt_next:
    jmp !mt_step-
!mt_done:
    rts

pathMoveSpeed: .byte 1
pathMoveSelf: .byte 0
pathMoveTarget: .byte 0

UpdatePaths:
    ldx #$00
UpdatePathsLoop:
    cpx #OBJ_COUNT
    bne PathHaveObject
    jmp UpdatePathsDone
PathHaveObject:
    stx pathObjIndex
    lda objectActive,x
    bne PathObjectActive
    jmp UpdatePathsNext
PathObjectActive:
    lda objectPathActive,x
    bne PathObjectPathActive
    jmp UpdatePathsNext
PathObjectPathActive:
    lda objectPathId,x
    cmp #$ff
    bne PathHaveId
    jmp UpdatePathsNext
PathHaveId:
    tay
    cpy #PATH_COUNT
    bcc PathIdValid
    jmp UpdatePathsNext
PathIdValid:
    lda pathCount,y
    bne PathCountValid
    jmp UpdatePathsNext
PathCountValid:
    lda pathStart,y
    clc
    adc objectPathPoint,x
    sta pathTempIndex
    tay
    lda pathPointXLo,y
    sta pathTargetXLo
    lda pathPointXHi,y
    sta pathTargetXHi
    lda pathPointY,y
    sta pathTargetY

    // X: determine direction from 9-bit current/target values.
    ldx pathObjIndex
    lda objectXHi,x
    cmp pathTargetXHi
    bcc PathXPositive
    bne PathXNegative
    lda objectXLo,x
    cmp pathTargetXLo
    bcc PathXPositive
    beq PathMoveYStart

PathXNegative:
    // diff = current - target. Clamp when diff <= speed.
    sec
    lda objectXLo,x
    sbc pathTargetXLo
    sta pathDiffLo
    lda objectXHi,x
    sbc pathTargetXHi
    bne PathXNegativeStep
    ldy objectPathId,x
    lda pathDiffLo
    cmp pathSpeed,y
    bcc PathClampX
    beq PathClampX
PathXNegativeStep:
    ldy objectPathId,x
    sec
    lda objectXLo,x
    sbc pathSpeed,y
    sta objectXLo,x
    lda objectXHi,x
    sbc #$00
    and #$01
    sta objectXHi,x
    jmp PathMoveYStart

PathXPositive:
    // diff = target - current. Clamp when diff <= speed.
    sec
    lda pathTargetXLo
    sbc objectXLo,x
    sta pathDiffLo
    lda pathTargetXHi
    sbc objectXHi,x
    bne PathXPositiveStep
    ldy objectPathId,x
    lda pathDiffLo
    cmp pathSpeed,y
    bcc PathClampX
    beq PathClampX
PathXPositiveStep:
    ldy objectPathId,x
    clc
    lda objectXLo,x
    adc pathSpeed,y
    sta objectXLo,x
    lda objectXHi,x
    adc #$00
    and #$01
    sta objectXHi,x
    jmp PathMoveYStart

PathClampX:
    lda pathTargetXLo
    sta objectXLo,x
    lda pathTargetXHi
    sta objectXHi,x

PathMoveYStart:
    lda objectY,x
    cmp pathTargetY
    bcc PathYPositive
    beq PathCheckArrived

PathYNegative:
    sec
    lda objectY,x
    sbc pathTargetY
    sta pathDiffLo
    ldy objectPathId,x
    lda pathDiffLo
    cmp pathSpeed,y
    bcc PathClampY
    beq PathClampY
    sec
    lda objectY,x
    sbc pathSpeed,y
    sta objectY,x
    jmp PathCheckArrived

PathYPositive:
    sec
    lda pathTargetY
    sbc objectY,x
    sta pathDiffLo
    ldy objectPathId,x
    lda pathDiffLo
    cmp pathSpeed,y
    bcc PathClampY
    beq PathClampY
    clc
    lda objectY,x
    adc pathSpeed,y
    sta objectY,x
    jmp PathCheckArrived
PathClampY:
    lda pathTargetY
    sta objectY,x

PathCheckArrived:
    lda objectXHi,x
    cmp pathTargetXHi
    bne UpdatePathsNext
    lda objectXLo,x
    cmp pathTargetXLo
    bne UpdatePathsNext
    lda objectY,x
    cmp pathTargetY
    bne UpdatePathsNext
    jsr AdvancePathWaypoint
UpdatePathsNext:
    ldx pathObjIndex
    inx
    jmp UpdatePathsLoop
UpdatePathsDone:
    rts

AdvancePathWaypoint:
    ldx pathObjIndex
    ldy objectPathId,x
    lda pathCount,y
    cmp #$02
    bcs PathAdvanceMulti
    lda pathMode,y
    cmp #$02
    bne PathAdvanceDone
    lda #$00
    sta objectPathActive,x
    lda #$01
    sta objectPathDone,x
PathAdvanceDone:
    rts
PathAdvanceMulti:
    lda pathMode,y
    cmp #$01
    beq PathAdvancePatrol
    cmp #$02
    beq PathAdvanceOnce
    // Loop
    inc objectPathPoint,x
    lda objectPathPoint,x
    cmp pathCount,y
    bcc PathAdvanceDone
    lda #$00
    sta objectPathPoint,x
    rts
PathAdvanceOnce:
    inc objectPathPoint,x
    lda objectPathPoint,x
    cmp pathCount,y
    bcc PathAdvanceDone
    lda pathCount,y
    sec
    sbc #$01
    sta objectPathPoint,x
    lda #$00
    sta objectPathActive,x
    lda #$01
    sta objectPathDone,x
    rts
PathAdvancePatrol:
    lda objectPathDir,x
    bmi PathPatrolBackward
    inc objectPathPoint,x
    lda objectPathPoint,x
    cmp pathCount,y
    bcc PathAdvanceDone
    lda pathCount,y
    sec
    sbc #$02
    sta objectPathPoint,x
    lda #$ff
    sta objectPathDir,x
    rts
PathPatrolBackward:
    lda objectPathPoint,x
    beq PathPatrolTurnForward
    dec objectPathPoint,x
    rts
PathPatrolTurnForward:
    lda #$01
    sta objectPathDir,x
    sta objectPathPoint,x
    rts

SaveLogicPositions:
    ldx #$00
SaveLogicPositionLoop:
    cpx #OBJ_COUNT
    beq SaveLogicPositionsDone
    lda objectXLo,x
    sta objectLastXLo,x
    lda objectXHi,x
    sta objectLastXHi,x
    lda objectY,x
    sta objectLastY,x
    inx
    jmp SaveLogicPositionLoop
SaveLogicPositionsDone:
    rts

UpdateAnimations:
    ldx #$00
UpdateAnimLoop:
    cpx #OBJ_COUNT
    bne UpdateAnimContinue
    jmp UpdateAnimDone
UpdateAnimContinue:
    lda objectActive,x
    beq UpdateAnimNext
    lda objectAutoAnimate,x
    beq UpdateAnimNext
    lda objectFrameCount,x
    cmp #2
    bcc UpdateAnimNext
    lda objectAnimLoop,x
    bne UpdateAnimAdvance
    lda objectFrame,x
    clc
    adc #1
    cmp objectFrameCount,x
    bcs UpdateAnimNext
UpdateAnimAdvance:
    inc objectAnimTimer,x
    lda objectAnimTimer,x
    cmp objectAnimDuration,x
    bcc UpdateAnimNext
    lda #$00
    sta objectAnimTimer,x
    inc objectFrame,x
    lda objectFrame,x
    cmp objectFrameCount,x
    bcc UpdateAnimNext
    lda objectAnimLoop,x
    beq UpdateAnimClampLast
    lda #$00
    sta objectFrame,x
    jmp UpdateAnimNext
UpdateAnimClampLast:
    lda objectFrameCount,x
    sec
    sbc #1
    sta objectFrame,x
UpdateAnimNext:
    inx
    jmp UpdateAnimLoop
UpdateAnimDone:
    rts

DrawAllObjects:
    lda #$00
    sta drawOrderPos
DrawObjectLoop:
    ldy drawOrderPos
    cpy #OBJ_COUNT
    bne DrawObjectContinue
    jmp DrawObjectDone
DrawObjectContinue:
    ldx objectDrawOrder,y
    stx drawIndex
    lda objectRenderer,x
    beq DrawObjectContinueSoftware
    jmp DrawObjectNext
DrawObjectContinueSoftware:
    lda objectRoom,x
    cmp currentRoom
    beq DrawObjectContinueSoftwareRoomOkay
    jmp DrawObjectNext
DrawObjectContinueSoftwareRoomOkay:
    lda objectActive,x
    bne DrawActiveOkay
    jmp DrawObjectNext
DrawActiveOkay:
    lda objectMode,x
    cmp #SCENE_MODE
    beq DrawModeOkay
    jmp DrawObjectNext
DrawModeOkay:
    lda objectY,x
    cmp #200
    bcc DrawYOkay
    jmp DrawObjectNext
DrawYOkay:

    lda objectXLo,x
    sta ss_img_temp
    lda objectMode,x
    beq DrawShiftHires
    lda ss_img_temp
    and #$06
    sta ss_xshift
    jmp DrawShiftDone
DrawShiftHires:
    lda ss_img_temp
    and #$07
    sta ss_xshift
DrawShiftDone:
    lda ss_img_temp
    lsr
    lsr
    lsr
    sta ss_xcell
    lda objectXHi,x
    beq DrawXHiDone
    lda ss_xcell
    clc
    adc #32
    sta ss_xcell
DrawXHiDone:
    lda ss_xcell
    cmp #40
    bcc DrawXInBounds
    jmp DrawObjectNext
DrawXInBounds:

    lda objectWidthBytes,x
    sta ss_widthbytes
    sta ss_clearbytes
    lda ss_xshift
    beq DrawWidthReady
    inc ss_clearbytes
DrawWidthReady:
    lda ss_xcell
    clc
    adc ss_clearbytes
    cmp #41
    bcc DrawWidthInBounds
    jmp DrawObjectNext
DrawWidthInBounds:

    lda objectDataLo,x
    sta SS_IMG_LO
    lda objectDataHi,x
    sta SS_IMG_HI

    lda objectFrame,x
    sta ss_count
    beq DrawFrameReady
DrawFrameAdvance:
    clc
    lda SS_IMG_LO
    adc objectFrameSizeLo,x
    sta SS_IMG_LO
    lda SS_IMG_HI
    adc objectFrameSizeHi,x
    sta SS_IMG_HI
    dec ss_count
    bne DrawFrameAdvance

DrawFrameReady:
    clc
    lda SS_IMG_LO
    adc objectImageBytesLo,x
    sta SS_MASK_LO
    lda SS_IMG_HI
    adc objectImageBytesHi,x
    sta SS_MASK_HI

    lda objectY,x
    sta ss_ypixel
    lda objectHeight,x
    sta ss_height
    lda objectMode,x
    beq DrawHiresObject
    lda objectUsesLocal,x
    beq DrawMulticolorPixels
    lda objectVICColor,x
    jsr SetSoftwareScreenRect
DrawMulticolorPixels:
    jsr BlitMulticolorShifted
    jmp DrawObjectNext
DrawHiresObject:
    // Hires bitmap pixels take their foreground color from the screen-RAM
    // high nibble.  Previously software hires sprites changed bitmap bits but
    // never supplied their sprite color, so they appeared white/black.
    lda objectVICColor,x
    jsr SetSoftwareHiresScreenRect
    jsr BlitHiresShifted

DrawObjectNext:
    inc drawOrderPos
    jmp DrawObjectLoop
DrawObjectDone:
    rts

// ------------------------------------------------------------
// VIC-II hardware sprite renderer.
// First eight active VIC-rendered object-table entries get hardware slots 0-7.
// X/Y are game coordinates; VIC register coordinates add the visible-area
// offsets (24,50). Pointer bytes are mirrored to both screen buffers.
// ------------------------------------------------------------
// ------------------------------------------------------------
// VIC-II raster multiplexer - VER 07.0
//
// Up to 16 active VIC-rendered object-table entries are collected and sorted
// by Y each frame. The first eight occupy hardware slots 0-7. Later sprites
// reuse a slot only after that slot's previous 21-line sprite has cleared.
// Reuse is scheduled by raster IRQ shortly before the next sprite begins.
// ------------------------------------------------------------
UpdateVICSprites:
    // VER 09.12: keep VIC slot collection/sort/register commit atomic.
    // A KERNAL IRQ in the middle of the update used to be allowed after the
    // old mux chain was disabled; keeping the caller's IRQ state preserved
    // ensures live object X/Y and slot assignment are committed as one unit.
    php
    sei
    lda #$00
    sta $d01a
    lda #$01
    sta $d019

    lda #$00
    sta vicEnableMask
    sta vicMulticolorMask
    sta vicXHighMask
    sta vicSortedCount
    sta muxEventCount
    sta muxEventPos

    // Collect up to 16 active VIC objects in the current room.
    ldx #$00
VICCollectLoop:
    cpx #OBJ_COUNT
    bne VICCollectContinue
    jmp VICCollectDone
VICCollectContinue:
    stx vicObjectIndex
    lda objectRenderer,x
    cmp #$01
    bne VICCollectNext
    lda objectActive,x
    beq VICCollectNext
    lda objectRoom,x
    cmp currentRoom
    bne VICCollectNext
    ldy vicSortedCount
    cpy #$10
    bcs VICCollectDone
    txa
    sta vicSortedObjects,y
    inc vicSortedCount
VICCollectNext:
    ldx vicObjectIndex
    inx
    jmp VICCollectLoop

VICCollectDone:
    jsr VICSortByY

    // Mark every slot free. slotEndY is the earliest game-Y at which it can
    // safely be reused.
    ldx #$00
VICClearSlotEnds:
    lda #$00
    sta vicSlotEndY,x
    inx
    cpx #$08
    bne VICClearSlotEnds

    // Draw first eight sorted sprites directly.
    lda #$00
    sta vicSortPos
VICInitialLoop:
    lda vicSortPos
    cmp vicSortedCount
    bcc VICInitialHasObject
    jmp VICInitialDone
VICInitialHasObject:
    cmp #$08
    bcc VICInitialUseSlot
    jmp VICInitialDone
VICInitialUseSlot:
    tay
    lda vicSortedObjects,y
    tax
    sty vicSlot
    jsr VICWriteObjectToSlot

    // This slot may be reused once Y + 22 has been reached.
    ldx vicObjectIndex
    lda objectY,x
    clc
    adc #22
    bcc VICInitialEndOkay
    lda #$ff
VICInitialEndOkay:
    ldy vicSlot
    sta vicSlotEndY,y

    inc vicSortPos
    jmp VICInitialLoop

VICInitialDone:
    // Remaining sorted objects become raster reuse events when a slot is free.
    lda #$08
    sta vicSortPos
VICSchedObjectLoop:
    lda vicSortPos
    cmp vicSortedCount
    bcc VICSchedHaveObject
    jmp VICSchedDone
VICSchedHaveObject:
    tay
    lda vicSortedObjects,y
    sta muxCandidateObject
    tax
    lda objectY,x
    sta muxCandidateY

    lda #$00
    sta muxSearchSlot
VICSchedSlotLoop:
    lda muxSearchSlot
    cmp #$08
    bcc VICSchedCheckSlot
    jmp VICSchedObjectNext
VICSchedCheckSlot:
    // A reused VIC slot needs enough vertical blank time to rewrite its
    // registers before the next sprite DMA starts.  The previous test only
    // required candidateY >= slotEndY and then scheduled the IRQ two lines
    // before the new sprite.  On a KERNAL-vectored IRQ that margin is too
    // small and produced intermittent old-slot contents (visible flashing).
    // Require at least an 8-line game-coordinate gap beyond slotEndY.
    tay
    lda vicSlotEndY,y
    clc
    adc #8
    bcs VICSchedSlotTooClose
    cmp muxCandidateY
    bcc VICSchedSlotFound
    beq VICSchedSlotFound
VICSchedSlotTooClose:
    inc muxSearchSlot
    jmp VICSchedSlotLoop

VICSchedSlotFound:
    ldx muxEventCount
    cpx #$08
    bcc VICSchedStore
    jmp VICSchedDone
VICSchedStore:
    lda muxCandidateObject
    sta muxEventObject,x
    lda muxSearchSlot
    sta muxEventSlot,x

    // VIC Y register is game Y + 50.  Schedule the reuse IRQ eight raster
    // lines before sprite start, giving the KERNAL-vector path ample time to
    // rewrite X/Y/pointer/color/mode before sprite DMA begins.
    lda muxCandidateY
    clc
    adc #42
    sta muxEventRaster,x
    inc muxEventCount

    // Update availability for a possible later reuse of the same slot.
    lda muxCandidateY
    clc
    adc #22
    bcc VICSchedEndOkay
    lda #$ff
VICSchedEndOkay:
    ldy muxSearchSlot
    sta vicSlotEndY,y

VICSchedObjectNext:
    inc vicSortPos
    jmp VICSchedObjectLoop

VICSchedDone:
    jsr VICCommitMasks

    // Arm the raster IRQ chain only when reuse events exist.
    lda muxEventCount
    beq VICDisableMuxIRQ
    lda #$00
    sta muxEventPos
    tay
    lda muxEventRaster,y
    sta $d012
    lda $d011
    and #$7f
    sta $d011
    lda #$01
    sta $d019
    sta $d01a
    plp
    rts
VICDisableMuxIRQ:
    lda #$00
    sta $d01a
    plp
    rts

// Bubble-sort collected object indexes by objectY (maximum 16 entries).
VICSortByY:
    lda vicSortedCount
    cmp #$02
    bcs VICSortStart
    rts
VICSortStart:
    lda #$00
    sta vicSortPass
VICSortOuter:
    lda #$00
    sta vicSortPos
VICSortInner:
    lda vicSortPos
    clc
    adc #$01
    cmp vicSortedCount
    bcc VICSortPair
    inc vicSortPass
    lda vicSortPass
    cmp vicSortedCount
    bcc VICSortOuter
    rts
VICSortPair:
    ldx vicSortPos
    lda vicSortedObjects,x
    sta vicSortObjA
    tay
    lda objectY,y
    sta vicSortYA
    inx
    lda vicSortedObjects,x
    sta vicSortObjB
    tay
    lda objectY,y
    cmp vicSortYA
    bcs VICSortNoSwap
    ldx vicSortPos
    lda vicSortObjB
    sta vicSortedObjects,x
    inx
    lda vicSortObjA
    sta vicSortedObjects,x
VICSortNoSwap:
    inc vicSortPos
    jmp VICSortInner

// X = object index, vicSlot = hardware slot.
VICWriteObjectToSlot:
    stx vicObjectIndex
    ldy vicSlot

    // Enable the slot.
    lda bitTable,y
    ora vicEnableMask
    sta vicEnableMask

    // Clear this slot's previous X-high and multicolor state.
    lda bitTable,y
    eor #$ff
    and vicXHighMask
    sta vicXHighMask
    lda bitTable,y
    eor #$ff
    and vicMulticolorMask
    sta vicMulticolorMask

    // X = object X + 24.
    ldx vicObjectIndex
    clc
    lda objectXLo,x
    adc #24
    sta vicTempXLo
    lda objectXHi,x
    adc #0
    sta vicTempXHi

    ldy vicSlot
    tya
    asl
    tay
    lda vicTempXLo
    sta $d000,y

    // Y = object Y + 50.
    ldx vicObjectIndex
    clc
    lda objectY,x
    adc #50
    iny
    sta $d000,y

    // X high bit.
    lda vicTempXHi
    beq VICWriteNoXHigh
    ldy vicSlot
    lda bitTable,y
    ora vicXHighMask
    sta vicXHighMask
VICWriteNoXHigh:

    // Multicolor bit.
    ldx vicObjectIndex
    lda objectMode,x
    beq VICWriteHires
    ldy vicSlot
    lda bitTable,y
    ora vicMulticolorMask
    sta vicMulticolorMask
VICWriteHires:

    // Local color and frame pointer.
    ldy vicSlot
    lda objectVICColor,x
    sta $d027,y
    clc
    lda objectVICBasePtr,x
    adc objectFrame,x
    sta $07f8,y
    sta $47f8,y
    rts

VICCommitMasks:
    lda vicXHighMask
    sta $d010
    lda vicMulticolorMask
    sta $d01c
    lda vicEnableMask
    sta $d015
    rts

// Raster IRQ: reuse slots for scheduled lower-screen sprites. Events with the
// same raster line are processed in one interrupt.
RasterMuxIRQ:
    // This handler is installed through $0314/$0315. The KERNAL entry at
    // $FF48 has ALREADY pushed A, X and Y before jumping here. Do not push
    // another copy and do not RTI directly; finish custom raster work via
    // the KERNAL register-restore/RTI exit at $EA81.
    lda $d019
    and #$01
    bne RasterMuxIsRaster
    jmp (oldIRQVector)

RasterMuxIsRaster:
    lda #$01
    sta $d019

RasterMuxEventLoop:
    ldx muxEventPos
    cpx muxEventCount
    bcc RasterMuxHaveEvent
    jmp RasterMuxFinishFrame
RasterMuxHaveEvent:
    lda muxEventObject,x
    sta vicObjectIndex
    lda muxEventSlot,x
    sta vicSlot
    ldx vicObjectIndex
    jsr VICWriteObjectToSlot
    jsr VICCommitMasks

    inc muxEventPos
    ldx muxEventPos
    cpx muxEventCount
    bcc RasterMuxCheckNext
    jmp RasterMuxFinishFrame
RasterMuxCheckNext:
    lda muxEventRaster,x
    cmp $d012
    beq RasterMuxEventLoop
    sta $d012
    jmp $ea81

RasterMuxFinishFrame:
    lda #$00
    sta $d01a
    jmp $ea81

InitRasterMultiplexer:
    sei
    lda $0314
    sta oldIRQVector
    lda $0315
    sta oldIRQVector+1
    lda #<RasterMuxIRQ
    sta $0314
    lda #>RasterMuxIRQ
    sta $0315
    lda #$01
    sta $d019
    lda #$00
    sta $d01a
    cli
    rts

oldIRQVector: .word 0
vicTempXLo: .byte 0
vicTempXHi: .byte 0
vicSortedCount: .byte 0
vicSortPass: .byte 0
vicSortPos: .byte 0
vicSortObjA: .byte 0
vicSortObjB: .byte 0
vicSortYA: .byte 0
muxCandidateObject: .byte 0
muxCandidateY: .byte 0
muxSearchSlot: .byte 0
muxEventCount: .byte 0
muxEventPos: .byte 0
vicSortedObjects:
    .fill 16,0
vicSlotEndY:
    .fill 8,0
muxEventObject:
    .fill 8,0
muxEventSlot:
    .fill 8,0
muxEventRaster:
    .fill 8,0
bitTable:
    .byte $01,$02,$04,$08,$10,$20,$40,$80

BlitHiresShifted:
    lda ss_xcell
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi

    lda ss_ypixel
    sta ss_cur_y
    lda ss_height
    sta ss_rows_left

ShiftBlitRow:
    lda ss_cur_y
    cmp #200
    bcc ShiftBlitRowInBounds
    jmp ShiftBlitDone
ShiftBlitRowInBounds:
    jsr SetDestinationFromCurrentRow
    lda #$00
    sta ss_col

ShiftBlitByte:
    ldy #$00
    lda (SS_IMG_LO),y
    sta ss_img_temp
    lda #$00
    sta ss_spill_temp
    // Hires shifts are 0..7. Use fall-through unrolled shifts instead of
    // a DEC/BNE loop for every image byte.
    lda ss_xshift
    beq ShiftReady
    cmp #$01
    beq ShiftOne
    cmp #$02
    beq ShiftTwo
    cmp #$03
    beq ShiftThree
    cmp #$04
    beq ShiftFour
    cmp #$05
    beq ShiftFive
    cmp #$06
    beq ShiftSix
    // 7 falls through all seven single-bit shifts.
ShiftSeven:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftSix:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftFive:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftFour:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftThree:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftTwo:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftOne:
    lsr ss_img_temp
    ror ss_spill_temp
ShiftReady:
    ldx ss_col
    ldy offset8,x
    lda (SS_DST_LO),y
    ora ss_img_temp
    sta (SS_DST_LO),y

    lda ss_xshift
    beq NoSpill
    inx
    ldy offset8,x
    lda (SS_DST_LO),y
    ora ss_spill_temp
    sta (SS_DST_LO),y
NoSpill:
    inc SS_IMG_LO
    bne ImgPtrDone
    inc SS_IMG_HI
ImgPtrDone:
    inc ss_col
    lda ss_col
    cmp ss_widthbytes
    beq ShiftBlitRowFinished
    jmp ShiftBlitByte
ShiftBlitRowFinished:
    inc ss_cur_y
    dec ss_rows_left
    beq ShiftBlitDone
    jmp ShiftBlitRow
ShiftBlitDone:
    rts

// ------------------------------------------------------------
// BlitMulticolorShifted
// 2-bit multicolor image + compact 1-bit logical occupancy mask.
// Odd physical X is rounded down because MC pixels are two pixels wide.
// ------------------------------------------------------------
BlitMulticolorShifted:
    lda ss_xcell
    sta ss_xoff_lo
    lda #$00
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    lda ss_xshift
    lsr
    sta ss_mc_shift
    lda ss_ypixel
    sta ss_cur_y
    lda ss_height
    sta ss_rows_left
MCRowLoop:
    lda ss_cur_y
    cmp #200
    bcc MCRowInBounds
    jmp MCDone
MCRowInBounds:
    jsr SetDestinationFromCurrentRow
    lda #$00
    sta ss_col
MCByteLoop:
    lda ss_col
    and #$01
    bne MCUseLowMask
    ldy #$00
    lda (SS_MASK_LO),y
    sta ss_mc_maskbyte
    inc SS_MASK_LO
    bne MCMaskPtrReady
    inc SS_MASK_HI
MCMaskPtrReady:
    lda ss_mc_maskbyte
    lsr
    lsr
    lsr
    lsr
    tax
    lda mcMaskExpand,x
    sta ss_mask_temp
    jmp MCMaskReady
MCUseLowMask:
    lda ss_mc_maskbyte
    and #$0f
    tax
    lda mcMaskExpand,x
    sta ss_mask_temp
MCMaskReady:
    ldy #$00
    lda (SS_IMG_LO),y
    sta ss_img_temp
    lda #$00
    sta ss_spill_temp
    sta ss_mask_spill
    // ss_mc_shift is only 0..3. Unroll the variable-count loop so every
    // sprite byte avoids DEC/BNE loop overhead in this hot path.
    lda ss_mc_shift
    beq MCShiftReady
    cmp #$01
    beq MCShiftOne
    cmp #$02
    beq MCShiftTwo
    // Shift three logical multicolor pixels = six physical bits.
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_mask_temp
    ror ss_mask_spill
    lsr ss_mask_temp
    ror ss_mask_spill
MCShiftTwo:
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_mask_temp
    ror ss_mask_spill
    lsr ss_mask_temp
    ror ss_mask_spill
MCShiftOne:
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_img_temp
    ror ss_spill_temp
    lsr ss_mask_temp
    ror ss_mask_spill
    lsr ss_mask_temp
    ror ss_mask_spill
MCShiftReady:
    ldx ss_col
    ldy offset8,x
    lda ss_mask_temp
    eor #$ff
    and (SS_DST_LO),y
    ora ss_img_temp
    sta (SS_DST_LO),y
    lda ss_mc_shift
    beq MCNoSpill
    inx
    ldy offset8,x
    lda ss_mask_spill
    eor #$ff
    and (SS_DST_LO),y
    ora ss_spill_temp
    sta (SS_DST_LO),y
MCNoSpill:
    inc SS_IMG_LO
    bne MCImgPtrReady
    inc SS_IMG_HI
MCImgPtrReady:
    inc ss_col
    lda ss_col
    cmp ss_widthbytes
    beq MCRowFinished
    jmp MCByteLoop
MCRowFinished:
    inc ss_cur_y
    dec ss_rows_left
    beq MCDone
    jmp MCRowLoop
MCDone:
    rts

// ------------------------------------------------------------
// Axis-aligned object collision support.
// Software sprites collide using their physical rectangular bounds.
// Width is objectWidthBytes * 8 physical pixels for both hires and MC.
// ------------------------------------------------------------
collisionSourceIndex: .byte 0
collisionCandidateIndex: .byte 0
collisionOtherIndex: .byte $ff
collisionTargetSprite: .byte 0
colAXLo: .byte 0
colAXHi: .byte 0
colBXLo: .byte 0
colBXHi: .byte 0
colARightLo: .byte 0
colARightHi: .byte 0
colBRightLo: .byte 0
colBRightHi: .byte 0
colABottomLo: .byte 0
colABottomHi: .byte 0
colBBottomLo: .byte 0
colBBottomHi: .byte 0
colWidthLo: .byte 0
colWidthHi: .byte 0

// ------------------------------------------------------------
// Live reusable-instance slot helpers.
// ------------------------------------------------------------
FindInactiveTemplateSlot:
    // A = template ID. Returns C=1 and X=matching inactive live slot.
    sta slotTargetTemplate
    ldx #$00
FindInactiveSlotLoop:
    cpx #OBJ_COUNT
    beq FindInactiveSlotNone
    lda objectId,x
    cmp slotTargetTemplate
    bne FindInactiveSlotNext
    lda objectActive,x
    beq FindInactiveSlotFound
FindInactiveSlotNext:
    inx
    jmp FindInactiveSlotLoop
FindInactiveSlotFound:
    sec
    rts
FindInactiveSlotNone:
    clc
    rts

FindFirstTemplateSlot:
    // A = template ID. Returns C=1 and X=first matching live slot.
    sta slotTargetTemplate
    ldx #$00
FindFirstSlotLoop:
    cpx #OBJ_COUNT
    beq FindFirstSlotNone
    lda objectId,x
    cmp slotTargetTemplate
    beq FindFirstSlotFound
    inx
    jmp FindFirstSlotLoop
FindFirstSlotFound:
    sec
    rts
FindFirstSlotNone:
    clc
    rts

LoadCurrentRoomSlots:
    // VER 08.1 persistent Room state:
    // reusable live slots retain X/Y/Active/frame/timer exactly as modified.
    // Only Object 0 is unique and follows currentRoom.
    ldx #$00
LoadRoomPersistentLoop:
    cpx #OBJ_COUNT
    beq LoadRoomSlotsDone
    lda objectId,x
    bne LoadRoomPersistentNext
    lda currentRoom
    sta objectRoom,x
    lda #$01
    sta objectActive,x
LoadRoomPersistentNext:
    inx
    jmp LoadRoomPersistentLoop
LoadRoomSlotsDone:
    rts

slotTargetTemplate: .byte 0\nspawnTargetSlot: .byte 0

// ------------------------------------------------------------
// Tile collision. A=0 Any, 1 Solid, 2 Hazard; X=live object slot.
// Returns C=1 when the object's physical rectangle overlaps a matching tile.
// ------------------------------------------------------------
CheckObjectTileProperty:
    stx tileCollisionSource
    lda #$01
    sta tilePropertyMode
    lda tilePropertyWanted
    sta tileCollisionWanted

    lda objectRoom,x
    jsr FindRoomTileMeta
    bcs TilePropertyMetaFound
    ldx tileCollisionSource
    clc
    rts
TilePropertyMetaFound:
    jsr LoadRoomTilePointers
    ldx roomMetaIndex
    lda tilePropertyIndex
    and #$03
    beq TilePropertyUse0
    cmp #$01
    beq TilePropertyUse1
    cmp #$02
    beq TilePropertyUse2
TilePropertyUse3:
    lda roomTileProp3Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp3Hi,x
    sta ROOM_COLL_HI
    jmp TileCollisionHaveData
TilePropertyUse2:
    lda roomTileProp2Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp2Hi,x
    sta ROOM_COLL_HI
    jmp TileCollisionHaveData
TilePropertyUse1:
    lda roomTileProp1Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp1Hi,x
    sta ROOM_COLL_HI
    jmp TileCollisionHaveData
TilePropertyUse0:
    lda roomTileProp0Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp0Hi,x
    sta ROOM_COLL_HI
    jmp TileCollisionHaveData

CheckObjectCenterTileProperty:
    // X=self, tilePropertyIndex/tilePropertyWanted set by caller. Center cell only.
    stx tileCollisionSource
    jsr LoadObjectRoomTileGeometry
    bcs !cctp_have_geometry+
    jmp !cctp_no+
!cctp_have_geometry:
    ldx roomMetaIndex
    lda tilePropertyIndex
    and #$03
    beq !cctp_p0+
    cmp #1
    beq !cctp_p1+
    cmp #2
    beq !cctp_p2+
    lda roomTileProp3Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp3Hi,x
    sta ROOM_COLL_HI
    jmp !cctp_prop_ready+
!cctp_p2:
    lda roomTileProp2Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp2Hi,x
    sta ROOM_COLL_HI
    jmp !cctp_prop_ready+
!cctp_p1:
    lda roomTileProp1Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp1Hi,x
    sta ROOM_COLL_HI
    jmp !cctp_prop_ready+
!cctp_p0:
    lda roomTileProp0Lo,x
    sta ROOM_COLL_LO
    lda roomTileProp0Hi,x
    sta ROOM_COLL_HI
!cctp_prop_ready:
    lda ROOM_COLL_LO
    ora ROOM_COLL_HI
    beq !cctp_no+
    ldx tileCollisionSource
    lda objectWidthBytes,x
    asl
    asl
    clc
    adc objectXLo,x
    tay
    lda objectXHi,x
    beq !cctp_xlow+
    lda ROOM_XCELL_HI
    clc
    adc #1
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda (SS_IMG_LO),y
    jmp !cctp_xready+
!cctp_xlow:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    lda (SS_IMG_LO),y
!cctp_xready:
    sta tileWriteCol
    ldx tileCollisionSource
    lda objectHeight,x
    lsr
    clc
    adc objectY,x
    cmp #200
    bcc !cctp_yok+
    lda #199
!cctp_yok:
    tay
    lda (ROOM_YOFFLO_LO),y
    sta SS_DST_LO
    lda (ROOM_YOFFHI_LO),y
    sta SS_DST_HI
    clc
    lda ROOM_MAP_LO
    adc SS_DST_LO
    sta SS_DST_LO
    lda ROOM_MAP_HI
    adc SS_DST_HI
    sta SS_DST_HI
    clc
    lda SS_DST_LO
    adc tileWriteCol
    sta SS_DST_LO
    bcc !cctp_addr+
    inc SS_DST_HI
!cctp_addr:
    ldy #0
    lda (SS_DST_LO),y
    cmp #$ff
    beq !cctp_no+
    tay
    lda (ROOM_COLL_LO),y
    cmp tilePropertyWanted
    bne !cctp_no+
    ldx tileCollisionSource
    sec
    rts
!cctp_no:
    ldx tileCollisionSource
    clc
    rts

CheckObjectTileCollision:
    sta tileCollisionWanted
    stx tileCollisionSource
    lda #$00
    sta tilePropertyMode

    lda objectRoom,x
    jsr FindRoomTileMeta
    bcs TileCollisionMetaFound
    ldx tileCollisionSource
    clc
    rts

TileCollisionMetaFound:
    jsr LoadRoomTilePointers

    lda ROOM_COLL_LO
    ora ROOM_COLL_HI
    bne TileCollisionHaveData
    ldx tileCollisionSource
    clc
    rts
TileCollisionHaveData:

    ldx tileCollisionSource

    // Objects starting beyond the 320-pixel room width do not collide.
    lda objectXHi,x
    beq TileLeftLowPage
    cmp #$01
    beq TileCollisionXHiOne
    jmp TileCollisionNoHit
TileCollisionXHiOne:
    lda objectXLo,x
    cmp #64
    bcc TileLeftHighPageOkay
    jmp TileCollisionNoHit
TileLeftHighPageOkay:
    lda objectXHi,x
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    ldy objectXLo,x
    lda (SS_IMG_LO),y
    sta tileLeftCell
    jmp TileLeftReady
TileLeftLowPage:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    ldy objectXLo,x
    lda (SS_IMG_LO),y
    sta tileLeftCell
TileLeftReady:

    // Right physical X = left + widthBytes*8 - 1, clamped to 319.
    lda objectWidthBytes,x
    sta tileRightXLo
    lda #$00
    sta tileRightXHi
    asl tileRightXLo
    rol tileRightXHi
    asl tileRightXLo
    rol tileRightXHi
    asl tileRightXLo
    rol tileRightXHi
    sec
    lda tileRightXLo
    sbc #$01
    sta tileRightXLo
    lda tileRightXHi
    sbc #$00
    sta tileRightXHi

    clc
    lda objectXLo,x
    adc tileRightXLo
    sta tileRightXLo
    lda objectXHi,x
    adc tileRightXHi
    sta tileRightXHi

    lda tileRightXHi
    cmp #$01
    bcc TileRightNotClamped
    bne TileRightClamp
    lda tileRightXLo
    cmp #64
    bcc TileRightNotClamped
TileRightClamp:
    lda #63
    sta tileRightXLo
    lda #$01
    sta tileRightXHi
TileRightNotClamped:

    lda tileRightXHi
    beq TileRightLowPage
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    ldy tileRightXLo
    lda (SS_IMG_LO),y
    sta tileRightCell
    jmp TileRightReady
TileRightLowPage:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    ldy tileRightXLo
    lda (SS_IMG_LO),y
    sta tileRightCell
TileRightReady:

    // Top/bottom cell.
    ldx tileCollisionSource
    lda objectY,x
    cmp #200
    bcc TileTopInRange
    clc
    rts
TileTopInRange:
    tay
    lda (ROOM_YCELL_LO),y
    sta tileTopCell

    clc
    lda objectY,x
    adc objectHeight,x
    bcc TileBottomNoOverflow
    lda #199
    jmp TileBottomReady
TileBottomNoOverflow:
    beq TileBottomZero
    sec
    sbc #$01
    cmp #200
    bcc TileBottomReady
    lda #199
    jmp TileBottomReady
TileBottomZero:
    lda #$00
TileBottomReady:
    sta tileBottomY
    tay
    lda (ROOM_YCELL_LO),y
    sta tileBottomCell

    // Initial row offset from top pixel.
    ldx tileCollisionSource
    ldy objectY,x
    lda (ROOM_YOFFLO_LO),y
    sta tileRowOffLo
    lda (ROOM_YOFFHI_LO),y
    sta tileRowOffHi
    lda tileTopCell
    sta tileCurrentRow

TileCollisionRowLoop:
    lda tileCurrentRow
    cmp tileBottomCell
    bcc TileCollisionRowActive
    beq TileCollisionRowActive
    ldx tileCollisionSource
    clc
    rts

TileCollisionRowActive:
    lda tileLeftCell
    sta roomDrawCol

TileCollisionColLoop:
    lda roomDrawCol
    cmp tileRightCell
    bcc TileCollisionCheckCell
    beq TileCollisionCheckCell
    jmp TileCollisionNextRow

TileCollisionCheckCell:
    // Address room map cell = map base + row offset + column.
    clc
    lda ROOM_MAP_LO
    adc tileRowOffLo
    sta SS_DST_LO
    lda ROOM_MAP_HI
    adc tileRowOffHi
    sta SS_DST_HI
    clc
    lda SS_DST_LO
    adc roomDrawCol
    sta SS_DST_LO
    bcc TileCollisionMapAddrReady
    inc SS_DST_HI
TileCollisionMapAddrReady:
    ldy #$00
    lda (SS_DST_LO),y
    cmp #$ff
    beq TileCollisionNextCol

    tay
    lda (ROOM_COLL_LO),y
    sta roomTileIdTemp
    lda tilePropertyMode
    bne TilePropertyCompareValue
    lda roomTileIdTemp
    beq TileCollisionNextCol
    lda tileCollisionWanted
    beq TileCollisionHit
    cmp roomTileIdTemp
    beq TileCollisionHit
    jmp TileCollisionNextCol
TilePropertyCompareValue:
    lda roomTileIdTemp
    cmp tileCollisionWanted
    beq TileCollisionHit

TileCollisionNextCol:
    inc roomDrawCol
    jmp TileCollisionColLoop

TileCollisionNextRow:
    clc
    lda tileRowOffLo
    adc roomCols
    sta tileRowOffLo
    bcc TileCollisionRowOffsetReady
    inc tileRowOffHi
TileCollisionRowOffsetReady:
    inc tileCurrentRow
    jmp TileCollisionRowLoop

TileCollisionNoHit:
    ldx tileCollisionSource
    clc
    rts

TileCollisionHit:
    ldx tileCollisionSource
    sec
    rts

// ------------------------------------------------------------
// VER 09.4 generic grid / maze helpers.
// Direction codes: 0=Up, 1=Right, 2=Down, 3=Left.
// ------------------------------------------------------------
CheckObjectTileAhead:
    // X=self, A=collision wanted (0 Any/1 Solid/2 Hazard), direction in tileAheadDirection.
    sta tileAheadWanted
    stx tileCollisionSource
    lda objectXLo,x
    sta compareOtherTemp
    lda objectXHi,x
    sta pathDiffHi
    lda objectY,x
    sta pathDiffLo
    lda tileAheadDirection
    and #$03
    beq !ta_up+
    cmp #$01
    beq !ta_right+
    cmp #$02
    beq !ta_down+
!ta_left:
    lda objectXLo,x
    bne !ta_left_dec+
    dec objectXHi,x
!ta_left_dec:
    dec objectXLo,x
    jmp !ta_check+
!ta_up:
    dec objectY,x
    jmp !ta_check+
!ta_right:
    inc objectXLo,x
    bne !ta_check+
    inc objectXHi,x
    jmp !ta_check+
!ta_down:
    inc objectY,x
!ta_check:
    lda tileAheadWanted
    jsr CheckObjectTileCollision
    php
    ldx tileCollisionSource
    lda compareOtherTemp
    sta objectXLo,x
    lda pathDiffHi
    sta objectXHi,x
    lda pathDiffLo
    sta objectY,x
    plp
    rts

// VER 09.12: grid-turn probe used by Apply Queued Direction.
// Unlike the generic one-pixel Tile Ahead test, this samples the CENTER of
// the immediately adjacent grid cell. This makes queued turns deterministic
// at intersections and avoids a moving object's current bounding box from
// influencing the turn decision. Returns C=1 when the adjacent cell is Solid
// or outside the room; C=0 when it is open. X=self, A=direction.
CheckQueuedGridDirectionBlocked:
    and #$03
    sta tileAheadDirection
    stx tileCollisionSource
    jsr LoadObjectRoomTileGeometry
    bcs !qgd_have_geometry+
    ldx tileCollisionSource
    clc
    rts
!qgd_have_geometry:
    ldx tileCollisionSource

    // Object center X = object X + half object width in pixels.
    lda objectWidthBytes,x
    asl
    asl
    clc
    adc objectXLo,x
    sta tileProbeXLo
    lda objectXHi,x
    adc #$00
    sta tileProbeXHi

    // Object center Y = object Y + half object height.
    lda objectHeight,x
    lsr
    clc
    adc objectY,x
    sta tileProbeY

    lda tileAheadDirection
    beq !qgd_up+
    cmp #$01
    beq !qgd_right+
    cmp #$02
    beq !qgd_down+

!qgd_left:
    jsr ComputeTilePixelWidth
    lda tileProbeXHi
    bne !qgd_left_sub+
    lda tileProbeXLo
    cmp tileGridSize
    bcs !qgd_left_sub+
    jmp !qgd_blocked+
!qgd_left_sub:
    sec
    lda tileProbeXLo
    sbc tileGridSize
    sta tileProbeXLo
    lda tileProbeXHi
    sbc #$00
    sta tileProbeXHi
    jmp !qgd_lookup+

!qgd_right:
    jsr ComputeTilePixelWidth
    clc
    lda tileProbeXLo
    adc tileGridSize
    sta tileProbeXLo
    lda tileProbeXHi
    adc #$00
    sta tileProbeXHi
    lda tileProbeXHi
    cmp #$01
    bcc !qgd_lookup+
    beq !qgd_right_hi_one+
    jmp !qgd_blocked+
!qgd_right_hi_one:
    lda tileProbeXLo
    cmp #64
    bcc !qgd_lookup+
    jmp !qgd_blocked+

!qgd_up:
    lda tileProbeY
    cmp roomTileHeightRT
    bcs !qgd_up_ok+
    jmp !qgd_blocked+
!qgd_up_ok:
    sec
    sbc roomTileHeightRT
    sta tileProbeY
    jmp !qgd_lookup+

!qgd_down:
    clc
    lda tileProbeY
    adc roomTileHeightRT
    bcc !qgd_down_no_carry+
    jmp !qgd_blocked+
!qgd_down_no_carry:
    cmp #200
    bcc !qgd_down_in_range+
    jmp !qgd_blocked+
!qgd_down_in_range:
    sta tileProbeY

!qgd_lookup:
    // Convert target center X to map column.
    lda tileProbeXHi
    beq !qgd_xlow+
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    ldy tileProbeXLo
    lda (SS_IMG_LO),y
    sta tileProbeCol
    jmp !qgd_ylookup+
!qgd_xlow:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    ldy tileProbeXLo
    lda (SS_IMG_LO),y
    sta tileProbeCol

!qgd_ylookup:
    // Y offset table directly gives row*roomCols for the target pixel.
    ldy tileProbeY
    lda (ROOM_YOFFLO_LO),y
    sta tileProbeRowOffLo
    lda (ROOM_YOFFHI_LO),y
    sta tileProbeRowOffHi

    clc
    lda ROOM_MAP_LO
    adc tileProbeRowOffLo
    sta SS_DST_LO
    lda ROOM_MAP_HI
    adc tileProbeRowOffHi
    sta SS_DST_HI
    clc
    lda SS_DST_LO
    adc tileProbeCol
    sta SS_DST_LO
    bcc !qgd_addr_ready+
    inc SS_DST_HI
!qgd_addr_ready:
    ldy #$00
    lda (SS_DST_LO),y
    cmp #$ff
    beq !qgd_open+
    tay
    lda (ROOM_COLL_LO),y
    cmp #$01
    beq !qgd_blocked+
!qgd_open:
    ldx tileCollisionSource
    clc
    rts
!qgd_blocked:
    ldx tileCollisionSource
    sec
    rts

LoadObjectRoomTileGeometry:
    // X=self. Returns C=1 and room tile pointers loaded.
    stx tileCollisionSource
    lda objectRoom,x
    jsr FindRoomTileMeta
    bcc !lrtg_no+
    jsr LoadRoomTilePointers
    ldx tileCollisionSource
    sec
    rts
!lrtg_no:
    ldx tileCollisionSource
    clc
    rts

ComputeTilePixelWidth:
    lda roomTileWidthBytesRT
    asl
    asl
    asl
    sta tileGridSize
    rts

CheckObjectTileAligned:
    // A: 0 Both, 1 X, 2 Y. X=self.
    sta tileAlignAxis
    jsr LoadObjectRoomTileGeometry
    bcc !align_no+
    lda tileAlignAxis
    cmp #$02
    beq !align_y+
    jsr ComputeTilePixelWidth
    lda objectXLo,x
!align_x_mod:
    cmp tileGridSize
    bcc !align_x_done+
    sec
    sbc tileGridSize
    jmp !align_x_mod-
!align_x_done:
    bne !align_no+
    lda tileAlignAxis
    cmp #$01
    beq !align_yes+
!align_y:
    lda roomTileHeightRT
    sta tileGridSize
    lda objectY,x
!align_y_mod:
    cmp tileGridSize
    bcc !align_y_done+
    sec
    sbc tileGridSize
    jmp !align_y_mod-
!align_y_done:
    bne !align_no+
!align_yes:
    sec
    rts
!align_no:
    clc
    rts

SnapObjectToTile:
    // A: 0 Both, 1 X, 2 Y. X=self. Nearest grid origin.
    sta tileAlignAxis
    jsr LoadObjectRoomTileGeometry
    bcc !snap_done+
    lda tileAlignAxis
    cmp #$02
    beq !snap_y+
    jsr ComputeTilePixelWidth
    lda objectXLo,x
    sta tileGridRemainder
!snap_x_mod:
    lda tileGridRemainder
    cmp tileGridSize
    bcc !snap_x_have+
    sec
    sbc tileGridSize
    sta tileGridRemainder
    jmp !snap_x_mod-
!snap_x_have:
    lda objectXLo,x
    sec
    sbc tileGridRemainder
    sta objectXLo,x
    lda tileAlignAxis
    cmp #$01
    beq !snap_done+
!snap_y:
    lda roomTileHeightRT
    sta tileGridSize
    lda objectY,x
    sta tileGridRemainder
!snap_y_mod:
    lda tileGridRemainder
    cmp tileGridSize
    bcc !snap_y_have+
    sec
    sbc tileGridSize
    sta tileGridRemainder
    jmp !snap_y_mod-
!snap_y_have:
    lda objectY,x
    sec
    sbc tileGridRemainder
    sta objectY,x
!snap_done:
    rts

MoveObjectInDirection:
    // X=self, A=direction, Y=speed.
    and #$03
    sta directionCandidate
!move_dir_step:
    cpy #$00
    beq !move_dir_done+
    lda directionCandidate
    beq !mdi_up+
    cmp #$01
    beq !mdi_right+
    cmp #$02
    beq !mdi_down+
!mdi_left:
    lda objectXLo,x
    bne !mdi_left_dec+
    dec objectXHi,x
!mdi_left_dec:
    dec objectXLo,x
    jmp !mdi_next+
!mdi_up:
    dec objectY,x
    jmp !mdi_next+
!mdi_right:
    inc objectXLo,x
    bne !mdi_next+
    inc objectXHi,x
    jmp !mdi_next+
!mdi_down:
    inc objectY,x
!mdi_next:
    dey
    jmp !move_dir_step-
!move_dir_done:
    rts

ReadDirectionProperty:
    lda directionPropertyIndex
    beq !rdp0+
    cmp #1
    beq !rdp1+
    cmp #2
    beq !rdp2+
    cmp #3
    beq !rdp3+
    cmp #4
    beq !rdp4+
    cmp #5
    beq !rdp5+
    cmp #6
    beq !rdp6+
    lda objectP7,x
    rts
!rdp0: lda objectP0,x
    rts
!rdp1: lda objectP1,x
    rts
!rdp2: lda objectP2,x
    rts
!rdp3: lda objectP3,x
    rts
!rdp4: lda objectP4,x
    rts
!rdp5: lda objectP5,x
    rts
!rdp6: lda objectP6,x
    rts

WriteDirectionProperty:
    sta directionCandidate
    lda directionPropertyIndex
    beq !wdp0+
    cmp #1
    beq !wdp1+
    cmp #2
    beq !wdp2+
    cmp #3
    beq !wdp3+
    cmp #4
    beq !wdp4+
    cmp #5
    beq !wdp5+
    cmp #6
    beq !wdp6+
    lda directionCandidate
    sta objectP7,x
    rts
!wdp0: lda directionCandidate
    sta objectP0,x
    rts
!wdp1: lda directionCandidate
    sta objectP1,x
    rts
!wdp2: lda directionCandidate
    sta objectP2,x
    rts
!wdp3: lda directionCandidate
    sta objectP3,x
    rts
!wdp4: lda directionCandidate
    sta objectP4,x
    rts
!wdp5: lda directionCandidate
    sta objectP5,x
    rts
!wdp6: lda directionCandidate
    sta objectP6,x
    rts

ChooseObjectAvailableDirection:
    // X=self. directionPropertyIndex selects P0-P7.
    stx tileCollisionSource
    jsr ReadDirectionProperty
    and #$03
    sta directionOriginal
    lda #$00
    sta directionMask
    lda #$00
    sta tileAheadDirection
!cad_scan:
    ldx tileCollisionSource
    lda #$01
    jsr CheckObjectTileAhead
    bcs !cad_blocked+
    lda #$01
    ldy tileAheadDirection
!cad_shift:
    cpy #$00
    beq !cad_add+
    asl
    dey
    jmp !cad_shift-
!cad_add:
    ora directionMask
    sta directionMask
!cad_blocked:
    inc tileAheadDirection
    lda tileAheadDirection
    cmp #$04
    bcc !cad_scan-
    lda directionMask
    beq !cad_done+
    lda directionAvoidReverse
    beq !cad_pick+
    // If more than one direction exists, remove reverse of current direction.
    lda directionMask
    sta pathDiffLo
    sec
    sbc #$01
    and pathDiffLo
    beq !cad_pick+
    lda directionOriginal
    clc
    adc #$02
    and #$03
    tay
    lda #$01
!cad_rev_shift:
    cpy #$00
    beq !cad_have_rev+
    asl
    dey
    jmp !cad_rev_shift-
!cad_have_rev:
    eor #$ff
    and directionMask
    sta directionMask
!cad_pick:
    // Pick one random starting direction, then scan all four at most once.
    // The old code generated another random value after every miss and could
    // become trapped forever on a blocked direction at some RNG states.
    lda #$03
    jsr RandomInclusive
    and #$03
    sta directionCandidate
    lda #$04
    sta directionTryCount
!cad_try:
    lda #$01
    ldy directionCandidate
!cad_pick_shift:
    cpy #$00
    beq !cad_test+
    asl
    dey
    jmp !cad_pick_shift-
!cad_test:
    and directionMask
    bne !cad_store+
    inc directionCandidate
    lda directionCandidate
    and #$03
    sta directionCandidate
    dec directionTryCount
    bne !cad_try-
    jmp !cad_done+
!cad_store:
    ldx tileCollisionSource
    lda directionCandidate
    jsr WriteDirectionProperty
!cad_done:
    ldx tileCollisionSource
    rts

// ------------------------------------------------------------
// VER 11.0 persistent tile-based inventory.
// ------------------------------------------------------------
inventoryTargetItem: .byte $ff
inventoryAmount: .byte 0
inventoryRemaining: .byte 0
inventoryMaxStack: .byte 1
inventoryTotal: .byte 0
inventorySourceSlot: .byte 0
inventoryDestSlot: .byte 0
inventoryRenderRoom: .byte 0
inventoryRenderCol: .byte 0
inventoryRenderRow: .byte 0
inventoryColumnCounter: .byte 0
inventoryDestLo: .byte 0
inventoryDestHi: .byte 0

InventoryFindDefinition:
    // A=item ID. Returns C=1, Y=definition index.
    sta inventoryTargetItem
    ldy #$00
!ifd_loop:
    cpy #INVENTORY_ITEM_COUNT
    beq !ifd_no+
    lda inventoryDefinitionIds,y
    cmp inventoryTargetItem
    beq !ifd_yes+
    iny
    jmp !ifd_loop-
!ifd_yes:
    sec
    rts
!ifd_no:
    clc
    rts

InventoryHasAtLeast:
    // A=item ID, Y=required quantity. C=1 when total quantity is sufficient.
    sta inventoryTargetItem
    sty inventoryAmount
    lda #$00
    sta inventoryTotal
    ldx #$00
!iha_loop:
    cpx #INVENTORY_SLOT_COUNT
    beq !iha_done+
    lda inventoryItems,x
    cmp inventoryTargetItem
    bne !iha_next+
    lda inventoryTotal
    clc
    adc inventoryQuantities,x
    bcc !iha_store+
    lda #$ff
!iha_store:
    sta inventoryTotal
    cmp inventoryAmount
    bcs !iha_yes+
!iha_next:
    inx
    jmp !iha_loop-
!iha_done:
    lda inventoryTotal
    cmp inventoryAmount
    bcs !iha_yes+
    clc
    rts
!iha_yes:
    sec
    rts

InventoryAddItem:
    // A=item ID, Y=quantity. Stacks first, then fills empty slots. C=1 if all added.
    sta inventoryTargetItem
    sty inventoryRemaining
    jsr InventoryFindDefinition
    bcs !iai_definition+
    jmp !iai_fail+
!iai_definition:
    lda inventoryDefinitionMax,y
    sta inventoryMaxStack
    ldx #$00
!iai_stack_loop:
    cpx #INVENTORY_SLOT_COUNT
    beq !iai_empty_start+
    lda inventoryItems,x
    cmp inventoryTargetItem
    bne !iai_stack_next+
!iai_fill_existing:
    lda inventoryRemaining
    beq !iai_success+
    lda inventoryQuantities,x
    cmp inventoryMaxStack
    bcs !iai_stack_next+
    inc inventoryQuantities,x
    dec inventoryRemaining
    jmp !iai_fill_existing-
!iai_stack_next:
    inx
    jmp !iai_stack_loop-
!iai_empty_start:
    ldx #$00
!iai_empty_loop:
    lda inventoryRemaining
    beq !iai_success+
    cpx #INVENTORY_SLOT_COUNT
    beq !iai_fail+
    lda inventoryItems,x
    cmp #$ff
    bne !iai_empty_next+
    lda inventoryTargetItem
    sta inventoryItems,x
    lda #$00
    sta inventoryQuantities,x
!iai_fill_empty:
    lda inventoryRemaining
    beq !iai_success+
    lda inventoryQuantities,x
    cmp inventoryMaxStack
    bcs !iai_empty_next+
    inc inventoryQuantities,x
    dec inventoryRemaining
    jmp !iai_fill_empty-
!iai_empty_next:
    inx
    jmp !iai_empty_loop-
!iai_success:
    sec
    rts
!iai_fail:
    clc
    rts

InventoryRemoveItem:
    // A=item ID, Y=quantity. Removes only when the full quantity exists.
    sta inventoryTargetItem
    sty inventoryAmount
    jsr InventoryHasAtLeast
    bcc !iri_fail+
    lda inventoryAmount
    sta inventoryRemaining
    ldx #$00
!iri_loop:
    lda inventoryRemaining
    beq !iri_success+
    cpx #INVENTORY_SLOT_COUNT
    beq !iri_fail+
    lda inventoryItems,x
    cmp inventoryTargetItem
    bne !iri_next+
!iri_take:
    lda inventoryRemaining
    beq !iri_success+
    lda inventoryQuantities,x
    beq !iri_clear+
    dec inventoryQuantities,x
    dec inventoryRemaining
    jmp !iri_take-
!iri_clear:
    lda #$ff
    sta inventoryItems,x
!iri_next:
    inx
    jmp !iri_loop-
!iri_success:
    // Clear any slot whose last item was removed.
    ldx #$00
!iri_clean:
    cpx #INVENTORY_SLOT_COUNT
    beq !iri_yes+
    lda inventoryQuantities,x
    bne !iri_clean_next+
    lda #$ff
    sta inventoryItems,x
!iri_clean_next:
    inx
    jmp !iri_clean-
!iri_yes:
    sec
    rts
!iri_fail:
    clc
    rts

InventoryMoveSlot:
    // X=source, Y=destination. Swaps complete item/quantity slots.
    stx inventorySourceSlot
    sty inventoryDestSlot
    lda inventoryItems,x
    pha
    lda inventoryQuantities,x
    pha
    tya
    tax
    lda inventoryItems,x
    ldy inventorySourceSlot
    sta inventoryItems,y
    lda inventoryQuantities,x
    sta inventoryQuantities,y
    pla
    sta inventoryQuantities,x
    pla
    sta inventoryItems,x
    ldx inventorySourceSlot
    ldy inventoryDestSlot
    rts

InventoryTileForItem:
    cmp #$ff
    bne !itfi_find+
    lda #INVENTORY_EMPTY_TILE
    rts
!itfi_find:
    jsr InventoryFindDefinition
    bcc !itfi_empty+
    lda inventoryDefinitionTiles,y
    rts
!itfi_empty:
    lda #INVENTORY_EMPTY_TILE
    rts

RenderInventoryTiles:
    // A=room ID. Writes icon tile IDs into the configured grid and redraws them.
    sta inventoryRenderRoom
    jsr FindRoomTileMeta
    bcs !rit_have_room+
    rts
!rit_have_room:
    jsr LoadRoomTilePointers
    lda #INVENTORY_X
    sta inventoryRenderCol
    lda #INVENTORY_Y
    sta inventoryRenderRow
    lda #$00
    sta inventoryColumnCounter
    // Destination = room map + Y*columns + X.
    lda ROOM_MAP_LO
    sta inventoryDestLo
    lda ROOM_MAP_HI
    sta inventoryDestHi
    ldy #INVENTORY_Y
!rit_yadd:
    cpy #$00
    beq !rit_xadd+
    clc
    lda inventoryDestLo
    adc roomCols
    sta inventoryDestLo
    bcc !rit_ynocarry+
    inc inventoryDestHi
!rit_ynocarry:
    dey
    jmp !rit_yadd-
!rit_xadd:
    clc
    lda inventoryDestLo
    adc #INVENTORY_X
    sta inventoryDestLo
    bcc !rit_start+
    inc inventoryDestHi
!rit_start:
    ldx #$00
!rit_loop:
    cpx #INVENTORY_SLOT_COUNT
    bne !rit_active+
    jmp !rit_done+
!rit_active:
    lda inventoryItems,x
    jsr InventoryTileForItem
    sta tileWriteId
    lda inventoryDestLo
    sta SS_DST_LO
    lda inventoryDestHi
    sta SS_DST_HI
    lda tileWriteId
    ldy #$00
    sta (SS_DST_LO),y
    stx inventorySourceSlot
    lda inventoryRenderCol
    sta tileWriteCol
    lda inventoryRenderRow
    sta tileWriteRow
    jsr DrawChangedRoomTile
    ldx inventorySourceSlot
    inc inventoryDestLo
    bne !rit_ptr_ok+
    inc inventoryDestHi
!rit_ptr_ok:
    inc inventoryRenderCol
    inc inventoryColumnCounter
    lda inventoryColumnCounter
    cmp #INVENTORY_COLUMNS
    bcc !rit_next+
    lda #$00
    sta inventoryColumnCounter
    lda #INVENTORY_X
    sta inventoryRenderCol
    inc inventoryRenderRow
    // Pointer already advanced by INVENTORY_COLUMNS; skip remaining room columns.
    sec
    lda roomCols
    sbc #INVENTORY_COLUMNS
    clc
    adc inventoryDestLo
    sta inventoryDestLo
    bcc !rit_next+
    inc inventoryDestHi
!rit_next:
    inx
    jmp !rit_loop-
!rit_done:
    rts

SetTileUnderObject:
    // X=self, A=new room tile ID. Mutates the room map cell under object center.
    sta tileWriteId
    stx tileCollisionSource
    jsr LoadObjectRoomTileGeometry
    bcc !stu_done+
    // center X into pixel->cell table
    ldx tileCollisionSource
    lda objectWidthBytes,x
    asl
    asl
    clc
    adc objectXLo,x
    tay
    lda objectXHi,x
    beq !stu_x_low+
    lda ROOM_XCELL_HI
    clc
    adc #$01
    sta SS_IMG_HI
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda (SS_IMG_LO),y
    jmp !stu_x_ready+
!stu_x_low:
    lda ROOM_XCELL_LO
    sta SS_IMG_LO
    lda ROOM_XCELL_HI
    sta SS_IMG_HI
    lda (SS_IMG_LO),y
!stu_x_ready:
    sta tileWriteCol
    // center Y into cell and row-offset tables
    ldx tileCollisionSource
    lda objectHeight,x
    lsr
    clc
    adc objectY,x
    cmp #200
    bcc !stu_y_ok+
    lda #199
!stu_y_ok:
    tay
    lda (ROOM_YCELL_LO),y
    sta tileWriteRow
    lda (ROOM_YOFFLO_LO),y
    sta SS_DST_LO
    lda (ROOM_YOFFHI_LO),y
    sta SS_DST_HI
    clc
    lda ROOM_MAP_LO
    adc SS_DST_LO
    sta SS_DST_LO
    lda ROOM_MAP_HI
    adc SS_DST_HI
    sta SS_DST_HI
    clc
    lda SS_DST_LO
    adc tileWriteCol
    sta SS_DST_LO
    bcc !stu_addr+
    inc SS_DST_HI
!stu_addr:
    ldy #0
    lda tileWriteId
    sta (SS_DST_LO),y
    // Redraw only the changed tile into both bitmap buffers.
    jsr DrawChangedRoomTile
!stu_done:
    ldx tileCollisionSource
    rts

DrawChangedRoomTile:
    // Convert tile column to bitmap-cell byte index.
    lda #0
    sta tileWriteXByte
    ldy tileWriteCol
!dct_x_loop:
    cpy #0
    beq !dct_x_done+
    clc
    lda tileWriteXByte
    adc roomTileWidthBytesRT
    sta tileWriteXByte
    dey
    jmp !dct_x_loop-
!dct_x_done:
    lda tileWriteXByte
    sta ss_xoff_lo
    lda #0
    sta ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    asl ss_xoff_lo
    rol ss_xoff_hi
    // Convert tile row to pixel Y.
    lda #0
    sta tileWriteY
    ldy tileWriteRow
!dct_y_loop:
    cpy #0
    beq !dct_y_done+
    clc
    lda tileWriteY
    adc roomTileHeightRT
    sta tileWriteY
    dey
    jmp !dct_y_loop-
!dct_y_done:
    // Resolve source tile pointer; $ff/no graphics draws blank.
    lda #0
    sta SS_IMG_LO
    sta SS_IMG_HI
    lda tileWriteId
    cmp #$ff
    beq !dct_source_ready+
    lda ROOM_PTRLO_LO
    ora ROOM_PTRLO_HI
    beq !dct_source_ready+
    ldy tileWriteId
    lda (ROOM_PTRLO_LO),y
    sta SS_IMG_LO
    lda (ROOM_PTRHI_LO),y
    sta SS_IMG_HI
!dct_source_ready:
    lda #0
    sta roomTileRow
!dct_row_loop:
    lda roomTileRow
    cmp roomTileHeightRT
    bcs !dct_done+
    clc
    adc tileWriteY
    tax
    cpx #200
    bcs !dct_done+
    lda bitmapRowLo,x
    clc
    adc ss_xoff_lo
    sta SS_DST_LO
    lda bitmapRowHi,x
    adc ss_xoff_hi
    sta SS_DST_HI
    lda #0
    sta roomTileByte
!dct_byte_loop:
    lda roomTileByte
    cmp roomTileWidthBytesRT
    bcs !dct_row_done+
    tax
    lda SS_IMG_LO
    ora SS_IMG_HI
    beq !dct_blank+
    ldy roomTileByte
    lda (SS_IMG_LO),y
    jmp !dct_have_byte+
!dct_blank:
    lda #0
!dct_have_byte:
    sta roomTileIdTemp
    ldx roomTileByte
    ldy offset8,x
    lda roomTileIdTemp
    sta (SS_DST_LO),y
    lda SS_DST_HI
    clc
    adc #$40
    sta SS_MASK_HI
    lda SS_DST_LO
    sta SS_MASK_LO
    lda roomTileIdTemp
    sta (SS_MASK_LO),y
    inc roomTileByte
    jmp !dct_byte_loop-
!dct_row_done:
    lda SS_IMG_LO
    ora SS_IMG_HI
    beq !dct_no_src_advance+
    clc
    lda SS_IMG_LO
    adc roomTileWidthBytesRT
    sta SS_IMG_LO
    bcc !dct_no_src_advance+
    inc SS_IMG_HI
!dct_no_src_advance:
    inc roomTileRow
    jmp !dct_row_loop-
!dct_done:
    rts

BringIndexToFront:
    stx zTargetIndex
    lda #$00
    sta zExtreme
    ldy #$00
!zfscan:
    cpy #OBJ_COUNT
    beq !zforder+
    lda objectActive,y
    beq !zfnext+
    lda objectZ,y
    cmp zExtreme
    bcc !zfnext+
    sta zExtreme
!zfnext:
    iny
    jmp !zfscan-
!zforder:
    // Remove target from draw order and append it at the end.
    ldy #$00
    ldx #$00
!zffind:
    cpy #OBJ_COUNT
    beq !zfsetz+
    lda objectDrawOrder,y
    cmp zTargetIndex
    beq !zfshift+
    iny
    jmp !zffind-
!zfshift:
    sty zOrderPos
!zfshiftloop:
    tya
    clc
    adc #1
    tax
    cpx #OBJ_COUNT
    beq !zfappend+
    lda objectDrawOrder,x
    sta objectDrawOrder,y
    iny
    jmp !zfshiftloop-
!zfappend:
    ldy #OBJ_COUNT-1
    lda zTargetIndex
    sta objectDrawOrder,y
!zfsetz:
    ldx zTargetIndex
    lda zExtreme
    clc
    adc #1
    sta objectZ,x
    rts

SendIndexToBack:
    stx zTargetIndex
    lda #$ff
    sta zExtreme
    ldy #$00
!zbscan:
    cpy #OBJ_COUNT
    beq !zborder+
    lda objectActive,y
    beq !zbnext+
    lda objectZ,y
    cmp zExtreme
    bcs !zbnext+
    sta zExtreme
!zbnext:
    iny
    jmp !zbscan-
!zborder:
    // Remove target and insert it at the beginning of draw order.
    ldy #$00
!zbfind:
    cpy #OBJ_COUNT
    beq !zbsetz+
    lda objectDrawOrder,y
    cmp zTargetIndex
    beq !zbshift+
    iny
    jmp !zbfind-
!zbshift:
    sty zOrderPos
!zbshiftloop:
    cpy #$00
    beq !zbinsert+
    tya
    tax
    dey
    lda objectDrawOrder,y
    sta objectDrawOrder,x
    jmp !zbshiftloop-
!zbinsert:
    lda zTargetIndex
    sta objectDrawOrder
!zbsetz:
    ldx zTargetIndex
    lda zExtreme
    sec
    sbc #1
    sta objectZ,x
    rts

NextRandomByte:
    lda randomSeed
    asl
    bcc !rno+
    eor #$1d
!rno:
    clc
    adc frameCounter
    sta randomSeed
    rts

// A = inclusive maximum (0..255). Returns A in 0..maximum.
RandomInclusive:
    sta randomMax
    cmp #$ff
    beq !rfull+
    clc
    adc #1
    sta randomRange
    jsr NextRandomByte
!rmod:
    cmp randomRange
    bcc !rdone+
    sec
    sbc randomRange
    jmp !rmod-
!rdone:
    rts
!rfull:
    jsr NextRandomByte
    rts

randomSeed: .byte $a7
randomMax: .byte $ff
randomRange: .byte 1
zTargetIndex: .byte 0
zExtreme: .byte 0
zOrderPos: .byte 0

CheckCollisionWithTemplate:
    sta collisionTargetTemplate
    stx collisionSourceIndex
    ldy #$00
CollisionTemplateLoop:
    cpy #OBJ_COUNT
    beq CollisionTemplateNo
    tya
    cmp collisionSourceIndex
    beq CollisionTemplateNext
    lda objectActive,y
    beq CollisionTemplateNext
    lda objectId,y
    cmp collisionTargetTemplate
    bne CollisionTemplateNext
    sty collisionCandidateIndex
    ldx collisionSourceIndex
    jsr CheckAABBCollision
    bcs CollisionTemplateFound
    ldy collisionCandidateIndex
CollisionTemplateNext:
    iny
    jmp CollisionTemplateLoop
CollisionTemplateFound:
    ldy collisionCandidateIndex
    sty collisionOtherIndex
    ldx collisionSourceIndex
    sec
    rts
CollisionTemplateNo:
    ldx collisionSourceIndex
    clc
    rts

collisionTargetTemplate: .byte 0

// Find the highest stack-order overlapping object in the same room.
// Generic selection helper for card games, inventory stacks, menus, etc.
// X = source slot. Returns C=1 and collisionOtherIndex = highest objectZ overlap.
CheckCollisionTopmost:
    stx collisionSourceIndex
    lda #$ff
    sta collisionBestIndex
    lda #$00
    sta collisionBestZ
    ldy #$00
CollisionTopmostLoop:
    cpy #OBJ_COUNT
    beq CollisionTopmostDoneScan
    tya
    cmp collisionSourceIndex
    beq CollisionTopmostNext
    lda objectActive,y
    beq CollisionTopmostNext
    sty collisionCandidateIndex
    ldx collisionSourceIndex
    jsr CheckAABBCollision
    bcc CollisionTopmostRestoreY
    ldy collisionCandidateIndex
    lda collisionBestIndex
    cmp #$ff
    beq CollisionTopmostTake
    lda objectZ,y
    cmp collisionBestZ
    bcc CollisionTopmostRestoreY
CollisionTopmostTake:
    tya
    sta collisionBestIndex
    lda objectZ,y
    sta collisionBestZ
CollisionTopmostRestoreY:
    ldy collisionCandidateIndex
CollisionTopmostNext:
    iny
    jmp CollisionTopmostLoop
CollisionTopmostDoneScan:
    lda collisionBestIndex
    cmp #$ff
    beq CollisionTopmostNo
    sta collisionOtherIndex
    ldx collisionSourceIndex
    sec
    rts
CollisionTopmostNo:
    lda #$ff
    sta collisionOtherIndex
    ldx collisionSourceIndex
    clc
    rts

collisionBestIndex: .byte $ff
collisionBestZ: .byte 0

CheckCollisionWithObject:
    sta collisionCandidateIndex
    stx collisionSourceIndex
    cmp collisionSourceIndex
    bne CollisionObjectDifferent
    jmp CollisionNo
CollisionObjectDifferent:
    ldy collisionCandidateIndex
    jsr CheckAABBCollision
    rts

CheckCollisionWithSprite:
    sta collisionTargetSprite
    stx collisionSourceIndex
    ldy #$00
CollisionSpriteLoop:
    cpy #OBJ_COUNT
    bne CollisionSpriteHaveCandidate
    jmp CollisionNo
CollisionSpriteHaveCandidate:
    tya
    cmp collisionSourceIndex
    beq CollisionSpriteNext
    lda objectActive,y
    beq CollisionSpriteNext
    lda objectSpriteId,y
    cmp collisionTargetSprite
    bne CollisionSpriteNext
    sty collisionCandidateIndex
    ldx collisionSourceIndex
    jsr CheckAABBCollision
    bcs CollisionSpriteFound
    ldy collisionCandidateIndex
CollisionSpriteNext:
    iny
    jmp CollisionSpriteLoop
CollisionSpriteFound:
    ldy collisionCandidateIndex
    sty collisionOtherIndex
    ldx collisionSourceIndex
    sec
    rts

CheckAABBCollision:
    stx collisionSourceIndex
    sty collisionCandidateIndex

    lda objectActive,x
    bne CollisionAActive
    jmp CollisionNoRestore
CollisionAActive:
    lda objectActive,y
    bne CollisionBActive
    jmp CollisionNoRestore
CollisionBActive:

    lda objectRoom,x
    cmp objectRoom,y
    beq CollisionSameRoom
    jmp CollisionNoRestore
CollisionSameRoom:

    // A left X
    lda objectXLo,x
    sta colAXLo
    lda objectXHi,x
    and #$01
    sta colAXHi

    // A width = widthBytes * 8, 16-bit
    lda objectWidthBytes,x
    sta colWidthLo
    lda #$00
    sta colWidthHi
    asl colWidthLo
    rol colWidthHi
    asl colWidthLo
    rol colWidthHi
    asl colWidthLo
    rol colWidthHi
    clc
    lda colAXLo
    adc colWidthLo
    sta colARightLo
    lda colAXHi
    adc colWidthHi
    sta colARightHi

    // A bottom
    lda objectY,x
    clc
    adc objectHeight,x
    sta colABottomLo
    lda #$00
    adc #$00
    sta colABottomHi

    // Load B
    ldx collisionCandidateIndex
    lda objectXLo,x
    sta colBXLo
    lda objectXHi,x
    and #$01
    sta colBXHi

    lda objectWidthBytes,x
    sta colWidthLo
    lda #$00
    sta colWidthHi
    asl colWidthLo
    rol colWidthHi
    asl colWidthLo
    rol colWidthHi
    asl colWidthLo
    rol colWidthHi
    clc
    lda colBXLo
    adc colWidthLo
    sta colBRightLo
    lda colBXHi
    adc colWidthHi
    sta colBRightHi

    lda objectY,x
    clc
    adc objectHeight,x
    sta colBBottomLo
    lda #$00
    adc #$00
    sta colBBottomHi

    // A.left < B.right
    lda colAXHi
    cmp colBRightHi
    bcc CollisionX1Pass
    beq CollisionX1CompareLow
    jmp CollisionNoRestore
CollisionX1CompareLow:
    lda colAXLo
    cmp colBRightLo
    bcc CollisionX1Pass
    jmp CollisionNoRestore
CollisionX1Pass:

    // B.left < A.right
    lda colBXHi
    cmp colARightHi
    bcc CollisionX2Pass
    beq CollisionX2CompareLow
    jmp CollisionNoRestore
CollisionX2CompareLow:
    lda colBXLo
    cmp colARightLo
    bcc CollisionX2Pass
    jmp CollisionNoRestore
CollisionX2Pass:

    // A.top < B.bottom
    ldx collisionSourceIndex
    lda objectY,x
    cmp colBBottomLo
    bcc CollisionY1Pass
    lda colBBottomHi
    bne CollisionY1Pass
    jmp CollisionNoRestore
CollisionY1Pass:

    // B.top < A.bottom
    ldx collisionCandidateIndex
    lda objectY,x
    cmp colABottomLo
    bcc CollisionHit
    lda colABottomHi
    bne CollisionHit
    jmp CollisionNoRestore

CollisionHit:
    lda collisionCandidateIndex
    sta collisionOtherIndex
    ldx collisionSourceIndex
    sec
    rts

CollisionNoRestore:
    ldx collisionSourceIndex
CollisionNo:
    clc
    rts

mcMaskExpand:
    .byte $00,$03,$0c,$0f,$30,$33,$3c,$3f,$c0,$c3,$cc,$cf,$f0,$f3,$fc,$ff

offset8:
""" + asm_bytes([i*8 for i in range(24)]) + """

bitmapRowLo:
""" + asm_bytes(row_lo) + """

bitmapRowHi:
""" + asm_bytes(row_hi) + """

screenRowLo:
""" + asm_bytes(screen_row_lo) + """

screenRowHiA:
""" + asm_bytes(screen_row_hi_a) + """

screenRowHiB:
""" + asm_bytes(screen_row_hi_b) + "\n"

        (d/"generated_runtime.asm").write_text(runtime,encoding="utf-8")

        # ------------------------------------------------------------
        # Main generated program.
        # ------------------------------------------------------------
        calls="\n".join(f"    jsr events_slot_{i:03d}" for i in range(len(runtime_slots)))
        stubs="\n".join(f"{lab}:\n    rts\n" for lab in sorted(custom_calls))

        main = (
            "// Next64 Studios C64 Game Creator generated game\n"
            f"// Project: {self.project.title}\n"
            "// Hybrid renderer: software bitmap sprites + VIC-II raster-multiplexed hardware sprites\n\n"
            '.import source "generated_defs.asm"\n\n'
            "BasicUpstart2(start)\n\n"
            '* = $8000 "Main"\n\n'
            "frameCounter: .byte 0\n"
            "lastKey: .byte 0\n\n"
            "start:\n"
            "    sei\n"
            "    // $36: BASIC ROM out, KERNAL ROM + I/O remain visible.\n"
            "    // Main engine/data can safely use $8000-$CFFF without the bitmap banks.\n"
            "    lda #$36\n"
            "    sta $01\n"
            "    jsr InitSoftwareDisplay\n"
            "    cli\n"
            "    jsr SelectBackBuffer\n"
            "    jsr DrawAllObjects\n"
            "    jsr SaveCurrentObjectState\n"
            "    jsr WaitFrame\n"
            "    jsr UpdateVICSprites\n"
            "    jsr SwapDisplayBuffer\n\n"
            "mainLoop:\n"
            "    jsr SelectBackBuffer\n"
            "    jsr ErasePreviousObjects\n"
            "    jsr EraseCurrentObjectRects\n"
            "    jsr SaveLogicPositions\n"
            "    inc frameCounter\n"
            "    jsr ReadLastKey\n"
            "    jsr ScanKeyboardMatrix\n"
            + calls + "\n"
            "    jsr CommitKeyboardMatrix\n"
            "    jsr UpdatePaths\n"
            "    jsr UpdateAnimations\n"
            "    jsr DrawAllObjects\n"
            "    jsr SaveCurrentObjectState\n"
            "    jsr WaitFrame\n"
            "    jsr UpdateVICSprites\n"
            "    jsr SwapDisplayBuffer\n"
            "    jmp mainLoop\n\n"
            "ReadLastKey:\n"
            "    jsr $ffe4\n"
            "    sta lastKey\n"
            "    rts\n\n"
            "WaitFrame:\n"
            "WaitFrame1:\n"
            "    lda $d012\n"
            "    cmp #$fc\n"
            "    bne WaitFrame1\n"
            "WaitFrame2:\n"
            "    lda $d012\n"
            "    cmp #$fc\n"
            "    beq WaitFrame2\n"
            "    rts\n\n"
            '.import source "generated_room_tiles.asm"\n'
            '.import source "generated_paths.asm"\n'
            '.import source "generated_runtime.asm"\n'
            '.import source "generated_rooms.asm"\n'
            '.import source "generated_instances.asm"\n'
            '.import source "generated_variables.asm"\n'
            '.import source "generated_objects.asm"\n'
            '.import source "generated_events.asm"\n'
            '.import source "generated_sprites.asm"\n\n'
            + stubs + "\n"
            + '.import source "generated_vic_sprites.asm"\n'
        )
        (d/"game.asm").write_text(main,encoding="utf-8")

        (d/"game_project_manifest.json").write_text(
            json.dumps(self._project_dict(),indent=2),encoding="utf-8")

        (d/"build.bat").write_text(
            '@echo off\n'
            'cd /d "%~dp0"\n'
            'if not exist KickAss.jar (\n'
            '  echo Copy KickAss.jar into this folder, then run build.bat.\n'
            '  pause\n'
            '  exit /b 1\n'
            ')\n'
            'java -jar KickAss.jar game.asm -o game.prg\n'
            'pause\n',
            encoding="utf-8")
        return d

    def test_play_current_room(self):
        room=self.current_room()
        if not room:
            return messagebox.showwarning("Test Play","Create or select a room first.")
        if not self.project.objects:
            return messagebox.showwarning("Test Play","Create at least one object first.")

        old=getattr(self,"test_play_window",None)
        try:
            if old is not None and old.winfo_exists(): old.destroy()
        except Exception:
            pass

        win=tk.Toplevel(self)
        self.test_play_window=win
        win.title(f"Next64 Test Play - {room.name}")
        win.resizable(True,True)

        bar=ttk.Frame(win,padding=5); bar.pack(fill="x")
        status=tk.StringVar(value=f"Room {room.room_id}: {room.name}")
        ttk.Label(bar,textvariable=status).pack(side="left")
        ttk.Label(bar,text="Arrows + SPACE   ESC stops").pack(side="right")
        canvas=tk.Canvas(win,width=960,height=600,bg="#000000",highlightthickness=1)
        canvas.pack(fill="both",expand=True,padx=6,pady=(0,6))
        win.geometry("980x680")
        win.minsize(500,360)
        canvas.focus_set()

        rt={
            "room":room.room_id,
            "frame":0,
            "keys":set(),
            "last_keys":set(),
            "vars":{v.name:int(v.initial)&255 for v in self.project.variables},
            "inventory_items":list(self.project.inventory.initial_items),
            "inventory_quantities":list(self.project.inventory.initial_quantities),
            "inventory_selected":int(self.project.inventory.selected_slot),
            "inventory_overrides":{},
            "entities":[],
            "next_id":0,
            "collision_other":None,
            "running":True,
            "bg_image":None,
            "bg_room":None,
            "bg_dirty":True,
            "canvas_image_item":None,
            "canvas_hud_item":None,
            "canvas_photo":None,
        }
        self.test_play_runtime=rt

        def num(v,d=0):
            try:return int(str(v).strip(),0)
            except:
                try:return int(str(v).strip())
                except:return d

        def selector_ids(v):
            out=[]
            for part in str(v).replace(";",",").split(","):
                part=part.strip()
                if not part:continue
                if "-" in part:
                    try:
                        a,b=[int(x.strip(),0) for x in part.split("-",1)]
                        step=1 if b>=a else -1
                        out.extend(range(a,b+step,step))
                    except:pass
                else:
                    try:out.append(int(part,0))
                    except:pass
            return list(dict.fromkeys(out))

        def template(tid):
            return self.project.objects.get(tid)

        def sprite(e):
            o=template(e["template"])
            if not o:return None
            return self.project.sprites.get(self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id))

        def size(e):
            sp=sprite(e)
            if not sp:return (8,8)
            return ((sp.width*2 if sp.mode=="multicolor" else sp.width),sp.height)

        def add_entity(tid,x,y,rid,active=True,instance=None,properties=None,z_order=0):
            if tid not in self.project.objects:return None
            o=self.project.objects[tid]
            baseprops=(list(getattr(o,"properties",[0]*8))+[0]*8)[:8] if properties is None else (list(properties)+[0]*8)[:8]
            e={"id":rt["next_id"],"template":tid,"instance":instance,"x":int(x),"y":int(y),
               "room":int(rid),"active":bool(active),"frame":0,"anim":0,
               "props":baseprops,"z":int(z_order)&255,
               "path_point":0,"path_dir":1,"path_active":bool(getattr(o,"path_enabled",False)),
               "path_name":getattr(o,"path_name",""),"path_done":False,
               "created":rt["frame"]}
            rt["next_id"]+=1
            rt["entities"].append(e)
            return e

        def active(tid=None):
            return [e for e in rt["entities"] if e["active"] and e["room"]==rt["room"]
                    and (tid is None or e["template"]==tid)]

        def first(tid):
            a=active(tid)
            return a[0] if a else None

        # Unique object 0.
        o0=self.project.objects.get(0)
        if o0:
            if room.player_start_enabled and room.player_start_object_id==0:
                add_entity(0,room.player_start_x,room.player_start_y,room.room_id,True)
            elif o0.room_id==room.room_id and o0.scene==room.level_id:
                add_entity(0,o0.x,o0.y,room.room_id,o0.active)
            else:
                add_entity(0,156,180,room.room_id,True)

        # Reusable room instances are created once for all rooms. Their runtime
        # X/Y/Active state then persists when Test Play changes rooms.
        for inst in getattr(self.project,"instances",[]):
            add_entity(inst.object_id,inst.x,inst.y,inst.room_id,inst.active,inst.instance_id,
                       getattr(inst,"properties",None),getattr(inst,"z_order",0))

        # Compatibility with older projects: also create non-player definitions
        # once in their stored room.
        if not getattr(self.project,"instances",[]):
            for oid,o in self.project.objects.items():
                if oid:
                    add_entity(oid,o.x,o.y,o.room_id,o.active)

        key_names={"a":"A","d":"D","w":"W","s":"S","space":"SPACE",
                   "left":"LEFT","right":"RIGHT","up":"UP","down":"DOWN"}
        def kd(ev):
            k=key_names.get(ev.keysym.lower(),ev.keysym.upper())
            if k=="ESCAPE":
                stop(); return
            rt["keys"].add(k)
        def ku(ev):
            rt["keys"].discard(key_names.get(ev.keysym.lower(),ev.keysym.upper()))
        win.bind("<KeyPress>",kd); win.bind("<KeyRelease>",ku)

        def var(name): return rt["vars"].get(str(name),0)

        def overlap(a,b):
            aw,ah=size(a); bw,bh=size(b)
            return a["x"]<b["x"]+bw and a["x"]+aw>b["x"] and a["y"]<b["y"]+bh and a["y"]+ah>b["y"]

        def tile_code(v):
            return {"any":0,"solid":1,"hazard":2,"none":0}.get(str(v).strip().lower(),num(v,0))

        def tile_touch(e,wanted="Any"):
            room=self._room_by_id(e["room"])
            if not room:return False
            ts=self.project.tilesets.get(room.level_id)
            if not ts or not ts.tiles:return False
            while len(ts.tile_collision)<len(ts.tiles):ts.tile_collision.append(0)
            tw=max(1,int(getattr(ts,"tile_width",8)))
            th=max(1,int(getattr(ts,"tile_height",8)))
            w,h=size(e)
            left=max(0,int(e["x"])); top=max(0,int(e["y"]))
            right=min(319,int(e["x"]+max(1,w)-1))
            bottom=min(199,int(e["y"]+max(1,h)-1))
            if right<0 or bottom<0 or left>319 or top>199:return False
            c0=max(0,left//tw); c1=max(0,right//tw)
            r0=max(0,top//th); r1=max(0,bottom//th)
            wanted_code=tile_code(wanted)
            for ry in range(r0,r1+1):
                if ry>=len(room.tile_map):continue
                row=room.tile_map[ry]
                for cx in range(c0,c1+1):
                    if cx>=len(row):continue
                    try:tid=int(row[cx])
                    except:continue
                    if tid<0 or tid>=len(ts.tiles):continue
                    code=ts.tile_collision[tid] if tid<len(ts.tile_collision) else 0
                    if code and (wanted_code==0 or code==wanted_code):
                        return True
            return False

        def tile_property_touch(e,pindex,wanted):
            room=self._room_by_id(e["room"])
            if not room:return False
            ts=self.project.tilesets.get(room.level_id)
            if not ts or not ts.tiles:return False
            while len(ts.tile_properties)<len(ts.tiles):ts.tile_properties.append([0,0,0,0])
            pindex=max(0,min(3,num(pindex,0))); wanted=num(wanted,0)&255
            tw=max(1,int(getattr(ts,"tile_width",8)))
            th=max(1,int(getattr(ts,"tile_height",8)))
            w,h=size(e)
            left=max(0,int(e["x"])); top=max(0,int(e["y"]))
            right=min(319,int(e["x"]+max(1,w)-1))
            bottom=min(199,int(e["y"]+max(1,h)-1))
            if right<0 or bottom<0 or left>319 or top>199:return False
            for ry in range(max(0,top//th),max(0,bottom//th)+1):
                if ry>=len(room.tile_map):continue
                row=room.tile_map[ry]
                for cx in range(max(0,left//tw),max(0,right//tw)+1):
                    if cx>=len(row):continue
                    try:tid=int(row[cx])
                    except:continue
                    if tid<0 or tid>=len(ts.tiles):continue
                    vals=(list(ts.tile_properties[tid])+[0,0,0,0])[:4]
                    if (int(vals[pindex])&255)==wanted:return True
            return False

        def center_tile_property(e,pindex,wanted):
            room=self._room_by_id(e["room"])
            if not room:return False
            ts=self.project.tilesets.get(room.level_id)
            if not ts or not ts.tiles:return False
            while len(ts.tile_properties)<len(ts.tiles):ts.tile_properties.append([0,0,0,0])
            pindex=max(0,min(3,num(pindex,0))); wanted=num(wanted,0)&255
            tw=max(1,int(getattr(ts,"tile_width",8))); th=max(1,int(getattr(ts,"tile_height",8)))
            w,h=size(e); cx=int((e["x"]+w//2)//tw); cy=int((e["y"]+h//2)//th)
            if cy<0 or cy>=len(room.tile_map) or cx<0 or cx>=len(room.tile_map[cy]):return False
            try:tid=int(room.tile_map[cy][cx])
            except:return False
            if tid<0 or tid>=len(ts.tiles):return False
            vals=(list(ts.tile_properties[tid])+[0,0,0,0])[:4]
            return (int(vals[pindex])&255)==wanted

        def inventory_total(iid):
            iid=num(iid,255)&255
            return sum(q for x,q in zip(rt["inventory_items"],rt["inventory_quantities"]) if x==iid)

        def inventory_add(iid,amount):
            iid=num(iid,255)&255;remaining=max(1,num(amount,1));definition=next((x for x in self.project.inventory.items if x.item_id==iid),None)
            if not definition:return False
            maximum=max(1,int(definition.max_stack))
            for i,x in enumerate(rt["inventory_items"]):
                if x==iid:
                    take=min(remaining,max(0,maximum-rt["inventory_quantities"][i]));rt["inventory_quantities"][i]+=take;remaining-=take
                    if not remaining:return True
            for i,x in enumerate(rt["inventory_items"]):
                if x==255:
                    take=min(remaining,maximum);rt["inventory_items"][i]=iid;rt["inventory_quantities"][i]=take;remaining-=take
                    if not remaining:return True
            return False

        def inventory_remove(iid,amount):
            iid=num(iid,255)&255;amount=max(1,num(amount,1))
            if inventory_total(iid)<amount:return False
            remaining=amount
            for i,x in enumerate(rt["inventory_items"]):
                if x!=iid:continue
                take=min(remaining,rt["inventory_quantities"][i]);rt["inventory_quantities"][i]-=take;remaining-=take
                if rt["inventory_quantities"][i]<=0:rt["inventory_items"][i]=255;rt["inventory_quantities"][i]=0
                if not remaining:return True
            return True

        def inventory_render(room_id=None):
            inv=self.project.inventory;rid=inv.display_room_id if room_id is None else int(room_id)&255
            definitions={x.item_id:x.tile_id for x in inv.items};over=rt["inventory_overrides"]
            for slot,iid in enumerate(rt["inventory_items"]):
                row=inv.display_y+slot//max(1,inv.display_columns);col=inv.display_x+slot%max(1,inv.display_columns)
                over[(rid,row,col)]=inv.empty_tile_id if iid==255 else definitions.get(iid,inv.empty_tile_id)
            if rid==rt["room"]:rt["bg_dirty"]=True

        def event_ok(e,v):
            typ=v.get("event","Every Frame")
            a=v.get("event_arg1",""); b=v.get("event_arg2","")
            if typ=="Every Frame":return True
            if typ=="Create":return e["created"]==rt["frame"]
            if typ=="Every N Frames":return rt["frame"]%max(1,num(a,1))==0
            if typ=="Keyboard Held":return str(a).upper() in rt["keys"]
            if typ=="Keyboard Pressed":
                k=str(a).upper(); return k in rt["keys"] and k not in rt["last_keys"]
            if typ=="Keyboard Pressed Over Object":
                k=str(a).upper()
                if not (k in rt["keys"] and k not in rt["last_keys"]):return False
                tid=num(b,-1)
                hits=[x for x in active(tid) if x is not e and overlap(e,x)]
                rt["collision_other"]=max(hits,key=lambda x:(x.get("z",0),x["id"])) if hits else None
                return rt["collision_other"] is not None
            if typ=="Keyboard Pressed Over Topmost Object":
                k=str(a).upper()
                if not (k in rt["keys"] and k not in rt["last_keys"]):return False
                hits=[x for x in active() if x is not e and overlap(e,x)]
                rt["collision_other"]=max(hits,key=lambda x:(x.get("z",0),x["id"])) if hits else None
                return rt["collision_other"] is not None
            if typ=="Object Leaves Screen":
                w,h=size(e); return e["x"]+w<=0 or e["x"]>=320 or e["y"]+h<=0 or e["y"]>=200
            if typ=="Variable Equals":return var(a)==(num(b)&255)
            if typ=="Variable Greater Than":return var(a)>num(b)
            if typ=="Variable Less Than":return var(a)<num(b)
            if typ=="Collision With Object":
                tid=num(a,-1)
                for x in active(tid):
                    if x is not e and overlap(e,x):
                        rt["collision_other"]=x
                        return True
                rt["collision_other"]=None
                return False
            if typ=="Collision With Sprite":
                sid=num(a,-1)
                for x in active():
                    if x is e:continue
                    xo=template(x["template"])
                    if xo and xo.sprite_id==sid and overlap(e,x):
                        rt["collision_other"]=x
                        return True
                rt["collision_other"]=None
                return False
            if typ=="Collision With Topmost Object":
                hits=[x for x in active() if x is not e and overlap(e,x)]
                rt["collision_other"]=max(hits,key=lambda x:(x.get("z",0),x["id"])) if hits else None
                return rt["collision_other"] is not None
            if typ=="Tile Collision":
                return tile_touch(e,a or "Any")
            if typ=="Tile Property Equals":
                return tile_property_touch(e,a,b)
            if typ=="Animation Finished":
                sp=sprite(e)
                return bool(sp and len(sp.frames)>1 and e["frame"]==len(sp.frames)-1 and e["anim"]==0)
            if typ=="Path Finished":
                if e.get("path_done"):
                    e["path_done"]=False
                    return True
                return False
            return False

        def entity_prop(ent,prop):
            if ent is None:return 0
            prop=str(prop).strip().title()
            if prop=="X":return int(ent["x"])
            if prop=="Y":return int(ent["y"])
            if prop=="Active":return 1 if ent["active"] else 0
            if prop=="Room":return int(ent["room"])
            if prop=="Frame":return int(ent["frame"])
            if prop=="Sprite":
                o=template(ent["template"])
                return int(o.sprite_id) if o else 0
            if prop=="Object Id":return int(ent["template"])
            if prop=="Instance Id":return 255 if ent.get("instance") is None else int(ent["instance"])&255
            if prop.startswith("P") and prop[1:].isdigit():
                pi=int(prop[1:])
                if 0<=pi<8:return int(ent.get("props",[0]*8)[pi])&255
            return 0

        def set_entity_prop(ent,prop,value,add=False):
            if ent is None:return
            prop=str(prop).strip().title()
            value=int(value)
            current=entity_prop(ent,prop)
            result=current+value if add else value
            if prop=="X":ent["x"]=result
            elif prop=="Y":ent["y"]=result
            elif prop=="Active":ent["active"]=bool(result)
            elif prop=="Room":ent["room"]=result&255
            elif prop=="Frame":
                sp=sprite(ent)
                ent["frame"]=max(0,min((len(sp.frames)-1 if sp and sp.frames else 0),result))
            elif prop.startswith("P") and prop[1:].isdigit():
                pi=int(prop[1:])
                if 0<=pi<8:ent["props"][pi]=result&255

        def property_compare(value,op,cmp):
            if op=="Equals":return value==cmp
            if op=="Not Equals":return value!=cmp
            if op=="Greater Than":return value>cmp
            if op=="Less Than":return value<cmp
            if op=="One Greater Than":return value==((cmp+1)&255)
            if op=="One Less Than":return ((value+1)&255)==cmp
            return False

        def condition_ok(e,v):
            typ=v.get("condition","None")
            a=v.get("condition_arg1",""); b=v.get("condition_arg2","")
            if typ=="None":return True
            if typ.startswith("Variable"):
                value=var(a); cmp=num(b)&255
                if typ=="Variable Equals":return value==cmp
                if typ=="Variable Not Equals":return value!=cmp
                if typ=="Variable Greater Than":return value>cmp
                if typ=="Variable Less Than":return value<cmp
            if typ=="Self Touching Tile":
                return tile_touch(e,a or "Any")
            if typ=="Self Tile Property Equals":
                return tile_property_touch(e,a,b)
            if typ=="Self Center Tile Property Equals":
                return center_tile_property(e,a,b)
            if typ=="Self Tile Ahead Is":
                room=self._room_by_id(e["room"]); ts=self.project.tilesets.get(room.level_id) if room else None
                if not ts or not ts.tiles:return str(b).strip().lower()=="empty"
                tw=max(1,int(getattr(ts,"tile_width",8))); th=max(1,int(getattr(ts,"tile_height",8)))
                w,h=size(e); d=str(a).strip().lower()
                probe=dict(e)
                if d=="up":probe["y"]-=1
                elif d=="right":probe["x"]+=1
                elif d=="down":probe["y"]+=1
                else:probe["x"]-=1
                wanted=str(b).strip().lower()
                hit=tile_touch(probe,"Any" if wanted=="empty" else (b or "Any"))
                return (not hit) if wanted=="empty" else hit
            if typ=="Self Aligned To Tile":
                room=self._room_by_id(e["room"]); ts=self.project.tilesets.get(room.level_id) if room else None
                if not ts:return False
                tw=max(1,int(getattr(ts,"tile_width",8))); th=max(1,int(getattr(ts,"tile_height",8)))
                axis=str(a or "Both").lower()
                return ((axis in ("both","x") and int(e["x"])%tw==0) if axis=="x" else
                        (axis in ("both","y") and int(e["y"])%th==0) if axis=="y" else
                        int(e["x"])%tw==0 and int(e["y"])%th==0)
            if typ in ("Inventory Contains Item","Inventory Quantity At Least"):
                return inventory_total(a)>=max(1,num(b,1))
            if typ=="Inventory Slot Equals":
                slot=max(0,min(len(rt["inventory_items"])-1,num(a,0)))
                return rt["inventory_items"][slot]==(num(b,255)&255)
            if typ=="Self Overlaps Topmost Object":
                hits=[x for x in active() if x is not e and overlap(e,x)]
                rt["collision_other"]=max(hits,key=lambda x:(x.get("z",0),x["id"])) if hits else None
                return rt["collision_other"] is not None
            if typ=="Self Does Not Overlap Object":
                tids=selector_ids(a)
                hits=[x for tid in tids for x in active(tid) if x is not e and overlap(e,x)]
                rt["collision_other"]=hits[0] if hits else None
                return bool(tids) and not hits
            if typ.startswith("Self Property "):
                op=typ.split(" Property ",1)[1]
                if op.endswith(" Variable"):
                    return property_compare(entity_prop(e,a),op.replace(" Variable",""),var(b))
                if op.endswith(" Other Property"):
                    return property_compare(entity_prop(e,a),op.replace(" Other Property",""),entity_prop(rt.get("collision_other"),b))
                return property_compare(entity_prop(e,a),op,num(b))
            if typ.startswith("Other Property "):
                op=typ.split(" Property ",1)[1]
                if op.endswith(" Variable"):
                    return property_compare(entity_prop(rt.get("collision_other"),a),op.replace(" Variable",""),var(b))
                return property_compare(entity_prop(rt.get("collision_other"),a),op,num(b))
            tid=num(a,e["template"]) if str(a).strip() else e["template"]
            ents=active(tid)
            if typ=="Object Active":return bool(ents)
            if typ=="Object Inactive":return not bool(ents)
            if typ=="Object In Room":
                return any(x["template"]==tid and x["room"]==num(b,rt["room"]) for x in rt["entities"])
            target=ents[0] if ents else (e if tid==e["template"] else None)
            if not target:return False
            cmp=num(b)
            if typ=="Object X Greater Than":return target["x"]>cmp
            if typ=="Object X Less Than":return target["x"]<cmp
            if typ=="Object Y Greater Than":return target["y"]>cmp
            if typ=="Object Y Less Than":return target["y"]<cmp
            return True

        def spawn(tid,source=None):
            o=template(tid)
            if not o:return None
            if tid==0:
                existing=first(0)
                if existing:
                    existing["active"]=True
                    return existing
            x=o.x; y=o.y
            if source is not None:
                x=source["x"]
                sp=self.project.sprites.get(self._sprite_key(getattr(o,"sprite_level",o.scene),o.sprite_id))
                y=source["y"]-(sp.height if sp else 8)
            return add_entity(tid,x,y,rt["room"],True)

        def action(e,v):
            act=v.get("action","Move X")
            a=v.get("action_arg1",""); b=v.get("action_arg2","")
            if act=="Move X":e["x"]+=num(a)
            elif act=="Move Y":e["y"]+=num(a)
            elif act=="Set Position":e["x"]=num(a);e["y"]=num(b)
            elif act=="Set Frame":
                sp=sprite(e)
                if sp and sp.frames:e["frame"]=max(0,min(len(sp.frames)-1,num(a)))
            elif act=="Set Variable":rt["vars"][str(a)]=num(b)&255
            elif act=="Add To Variable":rt["vars"][str(a)]=(var(a)+num(b))&255
            elif act=="Destroy Object":
                tid=num(a,e["template"]) if str(a).strip() else e["template"]
                target=e if tid==e["template"] else first(tid)
                if target:target["active"]=False
            elif act=="Set Object Active":
                tid=num(a,e["template"]); state=bool(num(b))
                ents=active(tid)
                if ents:
                    for x in ents:x["active"]=state
                elif state:spawn(tid)
            elif act=="Create Object":spawn(num(a,e["template"]))
            elif act=="Create Object At Object":
                tid=num(a,e["template"])
                sid=num(b,e["template"]) if str(b).strip() else e["template"]
                src=e if sid==e["template"] else first(sid)
                if src:spawn(tid,src)
            elif act=="Start Path":
                e["path_active"]=True;e["path_done"]=False
            elif act=="Stop Path":
                e["path_active"]=False
            elif act=="Restart Path":
                e["path_point"]=0;e["path_dir"]=1;e["path_active"]=True;e["path_done"]=False
            elif act=="Set Path":
                if any(p.name==str(a) for p in self.project.paths):
                    e["path_name"]=str(a);e["path_point"]=0;e["path_dir"]=1;e["path_active"]=True;e["path_done"]=False
            elif act=="Move Toward Object":
                target=first(num(a,-1)); speed=max(1,min(16,num(b,1)))
                if target:
                    if e["x"]<target["x"]:e["x"]=min(target["x"],e["x"]+speed)
                    elif e["x"]>target["x"]:e["x"]=max(target["x"],e["x"]-speed)
                    if e["y"]<target["y"]:e["y"]=min(target["y"],e["y"]+speed)
                    elif e["y"]>target["y"]:e["y"]=max(target["y"],e["y"]-speed)
            elif act=="Set Direction":
                pi=max(0,min(7,num(str(a).strip()[1:] if str(a).strip().upper().startswith("P") else a,0)))
                e["props"][pi]={"up":0,"right":1,"down":2,"left":3}.get(str(b).strip().lower(),0)
            elif act=="Move In Direction Property":
                pi=max(0,min(7,num(str(a).strip()[1:] if str(a).strip().upper().startswith("P") else a,0))); speed=max(1,min(16,num(b,1)))
                dc=e["props"][pi]&3
                if dc==0:e["y"]-=speed
                elif dc==1:e["x"]+=speed
                elif dc==2:e["y"]+=speed
                else:e["x"]-=speed
            elif act=="Choose Available Direction":
                import random
                pi=max(0,min(7,num(str(a).strip()[1:] if str(a).strip().upper().startswith("P") else a,0)))
                cur=e["props"][pi]&3; reverse=(cur+2)&3
                dirs=[]
                for dc,name in enumerate(("Up","Right","Down","Left")):
                    probe=dict(e)
                    if dc==0:probe["y"]-=1
                    elif dc==1:probe["x"]+=1
                    elif dc==2:probe["y"]+=1
                    else:probe["x"]-=1
                    if not tile_touch(probe,"Solid"):dirs.append(dc)
                if str(b).strip().lower().startswith("avoid") and len(dirs)>1 and reverse in dirs:dirs.remove(reverse)
                if dirs:e["props"][pi]=random.choice(dirs)
            elif act=="Apply Queued Direction":
                current_pi=max(0,min(7,num(str(a).strip()[1:] if str(a).strip().upper().startswith("P") else a,0)))
                queued_pi=max(0,min(7,num(str(b).strip()[1:] if str(b).strip().upper().startswith("P") else b,1)))
                dc=e["props"][queued_pi]&3
                probe=dict(e)
                if dc==0:probe["y"]-=1
                elif dc==1:probe["x"]+=1
                elif dc==2:probe["y"]+=1
                else:probe["x"]-=1
                if not tile_touch(probe,"Solid"): e["props"][current_pi]=dc
            elif act=="Snap Self To Tile":
                room=self._room_by_id(e["room"]); ts=self.project.tilesets.get(room.level_id) if room else None
                if ts:
                    tw=max(1,int(getattr(ts,"tile_width",8))); th=max(1,int(getattr(ts,"tile_height",8))); axis=str(a or "Both").lower()
                    if axis in ("both","x"):e["x"]=(int(e["x"])//tw)*tw
                    if axis in ("both","y"):e["y"]=(int(e["y"])//th)*th
            elif act=="Set Tile Under Self":
                room=self._room_by_id(e["room"]); ts=self.project.tilesets.get(room.level_id) if room else None
                if room and ts:
                    tw=max(1,int(getattr(ts,"tile_width",8))); th=max(1,int(getattr(ts,"tile_height",8))); w,h=size(e)
                    cx=max(0,min(len(room.tile_map[0])-1,int((e["x"]+w//2)//tw))); cy=max(0,min(len(room.tile_map)-1,int((e["y"]+h//2)//th)))
                    new_tid=num(a,0)
                    if room.tile_map[cy][cx] != new_tid:
                        room.tile_map[cy][cx]=new_tid
                        rt["bg_dirty"]=True
            elif act=="Add Inventory Item":inventory_add(a,b)
            elif act in ("Remove Inventory Item","Use Inventory Item"):inventory_remove(a,b)
            elif act=="Move Inventory Slot":
                src=max(0,min(len(rt["inventory_items"])-1,num(a,0)));dst=max(0,min(len(rt["inventory_items"])-1,num(b,0)))
                rt["inventory_items"][src],rt["inventory_items"][dst]=rt["inventory_items"][dst],rt["inventory_items"][src]
                rt["inventory_quantities"][src],rt["inventory_quantities"][dst]=rt["inventory_quantities"][dst],rt["inventory_quantities"][src]
            elif act=="Set Selected Inventory Slot":rt["inventory_selected"]=max(0,min(len(rt["inventory_items"])-1,num(a,0)))
            elif act=="Render Inventory Tiles":inventory_render(None if str(a).strip().lower() in ("","configured room") else num(a))
            elif act=="Set Object X":
                tid=num(a,e["template"]); target=e if tid==e["template"] else first(tid)
                if target:target["x"]=num(b)
            elif act=="Set Object Y":
                tid=num(a,e["template"]); target=e if tid==e["template"] else first(tid)
                if target:target["y"]=num(b)
            elif act=="Set Object Room":
                tid=num(a,e["template"]); target=e if tid==e["template"] else first(tid)
                if target:target["room"]=num(b,rt["room"])
            elif act=="Destroy Colliding Object":
                other=rt.get("collision_other")
                if other:other["active"]=False
            elif act=="Destroy Collision Pair":
                other=rt.get("collision_other")
                if other:other["active"]=False
                e["active"]=False
            elif act=="Set Colliding Object Active":
                other=rt.get("collision_other")
                if other:other["active"]=bool(num(a,1))
            elif act=="Set Self Property":
                set_entity_prop(e,a,num(b),False)
            elif act=="Add To Self Property":
                set_entity_prop(e,a,num(b),True)
            elif act=="Set Other Property":
                set_entity_prop(rt.get("collision_other"),a,num(b),False)
            elif act=="Add To Other Property":
                set_entity_prop(rt.get("collision_other"),a,num(b),True)
            elif act=="Set Variable From Self Property":
                rt["vars"][str(a)]=entity_prop(e,b)&255
            elif act=="Set Variable From Other Property":
                rt["vars"][str(a)]=entity_prop(rt.get("collision_other"),b)&255
            elif act=="Set Self Property From Variable":
                set_entity_prop(e,a,var(b),False)
            elif act=="Set Other Property From Variable":
                set_entity_prop(rt.get("collision_other"),a,var(b),False)
            elif act=="Add Variable To Self Property":
                set_entity_prop(e,a,var(b),True)
            elif act=="Subtract Variable From Self Property":
                set_entity_prop(e,a,-var(b),True)
            elif act=="Add Variable To Other Property":
                set_entity_prop(rt.get("collision_other"),a,var(b),True)
            elif act=="Subtract Variable From Other Property":
                set_entity_prop(rt.get("collision_other"),a,-var(b),True)
            elif act=="Set Other Property From Self Property":
                set_entity_prop(rt.get("collision_other"),a,entity_prop(e,b),False)
            elif act=="Set Self Property From Other Property":
                set_entity_prop(e,a,entity_prop(rt.get("collision_other"),b),False)
            elif act=="Toggle Self Property":
                set_entity_prop(e,a,0 if entity_prop(e,a) else 1,False)
            elif act=="Toggle Other Property":
                other=rt.get("collision_other")
                if other:set_entity_prop(other,a,0 if entity_prop(other,a) else 1,False)
            elif act=="Set Frame From Self Property":
                sp=sprite(e); e["frame"]=max(0,min((len(sp.frames)-1 if sp and sp.frames else 0),entity_prop(e,a)))
            elif act=="Set Frame From Other Property":
                sp=sprite(e); e["frame"]=max(0,min((len(sp.frames)-1 if sp and sp.frames else 0),entity_prop(rt.get("collision_other"),a)))
            elif act=="Bring Self To Front":
                e["z"]=(max([x.get("z",0) for x in active()]+[-1])+1)&255
            elif act=="Bring Other To Front":
                other=rt.get("collision_other")
                if other:other["z"]=(max([x.get("z",0) for x in active()]+[-1])+1)&255
            elif act=="Send Self To Back":
                e["z"]=(min([x.get("z",0) for x in active()]+[1])-1)&255
            elif act=="Send Other To Back":
                other=rt.get("collision_other")
                if other:other["z"]=(min([x.get("z",0) for x in active()]+[1])-1)&255
            elif act=="Set Variable Random":
                import random
                rt["vars"][str(a)]=random.randint(0,max(0,min(255,num(b,255))))
            elif act=="Restore Self Position":
                e["x"]=e.get("prev_x",e["x"])
                e["y"]=e.get("prev_y",e["y"])
            elif act=="Change Room":
                change_room(num(a,rt["room"]))

        def change_room(rid):
            nr=self._room_by_id(rid)
            if not nr:return
            player=first(0)
            oldx=player["x"] if player else 156; oldy=player["y"] if player else 180
            rt["room"]=nr.room_id
            # All non-player entities remain in rt["entities"] with their
            # modified X/Y/Active/frame state. Only visibility/logic selection
            # changes with rt["room"].
            if player:
                player["room"]=nr.room_id
                if nr.player_start_enabled and nr.player_start_object_id==0:
                    player["x"]=nr.player_start_x;player["y"]=nr.player_start_y
                elif oldy>=200:player["x"]=oldx;player["y"]=0
                elif oldy<0:player["x"]=oldx;player["y"]=192
                elif oldx>=320:player["x"]=0;player["y"]=oldy
                elif oldx<0:player["x"]=312;player["y"]=oldy
            rt["bg_dirty"]=True
            status.set(f"Room {nr.room_id}: {nr.name}")

        def animate(e):
            sp=sprite(e)
            if not sp or len(sp.frames)<=1 or not bool(getattr(sp,"auto_animate",True)):return
            e["anim"]+=1
            if e["anim"]>=max(1,int(sp.frames[e["frame"]].duration)):
                e["anim"]=0;e["frame"]+=1
                if e["frame"]>=len(sp.frames):e["frame"]=0 if sp.loop else len(sp.frames)-1

        def test_view_metrics():
            cw=max(1,canvas.winfo_width())
            ch=max(1,canvas.winfo_height())
            scale=min(cw/320.0,ch/200.0)
            vw=320.0*scale
            vh=200.0*scale
            ox=(cw-vw)/2.0
            oy=(ch-vh)/2.0
            return scale,ox,oy

        def _hex_rgb(value):
            value=str(value).lstrip("#")
            if len(value)!=6:return (0,0,0)
            try:return tuple(int(value[i:i+2],16) for i in (0,2,4))
            except:return (0,0,0)

        def build_background_image():
            """Build the static 320x200 Test Play background once.

            VER 09.5: Tile-heavy rooms used to create thousands of Tk canvas
            rectangles every 16 ms.  The background is now cached as one PIL
            image and rebuilt only after a room/tile change.
            """
            if Image is None:
                return None
            r=self._room_by_id(rt["room"])
            if not r:return Image.new("RGB",(320,200),(0,0,0))
            lev=next((sc for sc in self.project.scenes if sc.name==r.level_id),None)
            bg_index=(lev.background_color if lev else 0)&15
            img=Image.new("RGB",(320,200),_hex_rgb(C64_RUNTIME_PALETTE[bg_index][1]))
            ts=self.project.tilesets.get(r.level_id)
            if ts and ts.tiles:
                tile_w=max(1,int(getattr(ts,"tile_width",8)))
                tile_h=max(1,int(getattr(ts,"tile_height",8)))
                ts_mode=getattr(ts,"mode","multicolor")
                pxw=2 if ts_mode=="multicolor" else 1
                pix=img.load()
                map_cols=min(40,(320+tile_w-1)//tile_w)
                map_rows=min(25,(200+tile_h-1)//tile_h)
                for ty,row in enumerate(r.tile_map[:map_rows]):
                    for tx,tid in enumerate(row[:map_cols]):
                        tid=rt.get("inventory_overrides",{}).get((r.room_id,ty,tx),tid)
                        try:tid=int(tid)
                        except:continue
                        if tid<0 or tid>=len(ts.tiles):continue
                        for py,pixels in enumerate(ts.tiles[tid][:tile_h]):
                            gy=ty*tile_h+py
                            if gy>=200:break
                            for px,val in enumerate(pixels):
                                if val==0:ci=lev.background_color if lev else 0
                                elif val==1:ci=lev.mc1 if lev else 5
                                elif val==2:ci=lev.mc2 if lev else 6
                                else:ci=lev.local if lev else 7
                                rgb=_hex_rgb(C64_RUNTIME_PALETTE[ci&15][1])
                                gx=tx*tile_w+px*pxw
                                for dx in range(pxw):
                                    xx=gx+dx
                                    if 0<=xx<320:pix[xx,gy]=rgb
            rt["bg_image"]=img
            rt["bg_room"]=rt["room"]
            rt["bg_dirty"]=False
            return img

        def cached_background():
            if (rt.get("bg_image") is None or rt.get("bg_room")!=rt["room"]
                    or rt.get("bg_dirty")):
                return build_background_image()
            return rt["bg_image"]

        def draw_tiles_fallback():
            r=self._room_by_id(rt["room"])
            if not r:return
            lev=next((sc for sc in self.project.scenes if sc.name==r.level_id),None)
            scale,ox,oy=test_view_metrics()
            bg=C64_RUNTIME_PALETTE[(lev.background_color if lev else 0)&15][1]
            canvas.create_rectangle(ox,oy,ox+320*scale,oy+200*scale,fill=bg,outline="")
            ts=self.project.tilesets.get(r.level_id)
            if not ts or not ts.tiles:return
            tile_w=max(1,int(getattr(ts,"tile_width",8))); tile_h=max(1,int(getattr(ts,"tile_height",8)))
            pxw=2 if getattr(ts,"mode","multicolor")=="multicolor" else 1
            map_cols=min(40,(320+tile_w-1)//tile_w); map_rows=min(25,(200+tile_h-1)//tile_h)
            for ty,row in enumerate(r.tile_map[:map_rows]):
                for tx,tid in enumerate(row[:map_cols]):
                    tid=rt.get("inventory_overrides",{}).get((r.room_id,ty,tx),tid)
                    try:tid=int(tid)
                    except:continue
                    if tid<0 or tid>=len(ts.tiles):continue
                    for py,pixels in enumerate(ts.tiles[tid][:tile_h]):
                        for px,val in enumerate(pixels):
                            if val==0:ci=lev.background_color if lev else 0
                            elif val==1:ci=lev.mc1 if lev else 5
                            elif val==2:ci=lev.mc2 if lev else 6
                            else:ci=lev.local if lev else 7
                            gx=tx*tile_w+px*pxw; gy=ty*tile_h+py
                            if gx>=320 or gy>=200:continue
                            canvas.create_rectangle(ox+gx*scale,oy+gy*scale,ox+min(320,gx+pxw)*scale,oy+min(200,gy+1)*scale,fill=C64_RUNTIME_PALETTE[ci&15][1],outline="")

        def draw_entity_fallback(e):
            if not e["active"] or e["room"]!=rt["room"]:return
            sp=sprite(e)
            if not sp or not sp.frames:return
            scale,ox,oy=test_view_metrics()
            fr=sp.frames[max(0,min(e["frame"],len(sp.frames)-1))]
            mul=2 if sp.mode=="multicolor" else 1
            for py,row in enumerate(fr.pixels):
                for px,val in enumerate(row):
                    if not val:continue
                    if sp.mode=="hires":ci=sp.colors.get("hires",1)
                    elif val==1:ci=sp.colors.get("mc1",5)
                    elif val==2:ci=sp.colors.get("mc2",6)
                    else:ci=sp.colors.get("local",7)
                    gx=e["x"]+px*mul; gy=e["y"]+py
                    canvas.create_rectangle(ox+gx*scale,oy+gy*scale,ox+(gx+mul)*scale,oy+(gy+1)*scale,fill=C64_RUNTIME_PALETTE[ci&15][1],outline="")

        def composite_entity(img,e):
            if not e["active"] or e["room"]!=rt["room"]:return
            sp=sprite(e)
            if not sp or not sp.frames:return
            fr=sp.frames[max(0,min(e["frame"],len(sp.frames)-1))]
            mul=2 if sp.mode=="multicolor" else 1
            draw=ImageDraw.Draw(img)
            for py,row in enumerate(fr.pixels):
                gy=int(e["y"])+py
                if gy<0 or gy>=200:continue
                for px,val in enumerate(row):
                    if not val:continue
                    if sp.mode=="hires":ci=sp.colors.get("hires",1)
                    elif val==1:ci=sp.colors.get("mc1",5)
                    elif val==2:ci=sp.colors.get("mc2",6)
                    else:ci=sp.colors.get("local",7)
                    gx=int(e["x"])+px*mul
                    x0=max(0,gx); x1=min(320,gx+mul)
                    if x0<x1:
                        draw.rectangle((x0,gy,x1-1,gy),fill=_hex_rgb(C64_RUNTIME_PALETTE[ci&15][1]))

        def render_test_frame():
            scale,ox,oy=test_view_metrics()
            vars_txt="  ".join(f"{k}={v}" for k,v in rt["vars"].items())
            if self.project.inventory.enabled:
                s=max(0,min(len(rt["inventory_items"])-1,rt["inventory_selected"]));iid=rt["inventory_items"][s];qty=rt["inventory_quantities"][s]
                vars_txt+=("  " if vars_txt else "")+f"INV[{s}]={iid if iid!=255 else 'EMPTY'} x{qty}"
            if Image is None or ImageTk is None or ImageDraw is None:
                canvas.delete("all")
                draw_tiles_fallback()
                for ent in sorted(rt["entities"],key=lambda x:(x.get("z",0),x["id"])):draw_entity_fallback(ent)
                canvas.create_text(ox+3*scale,oy+3*scale,anchor="nw",fill="#ffffff",text=f"TEST PLAY  frame {rt['frame']}  {vars_txt}",font=("Courier",max(7,int(5*scale)),"bold"))
                return
            base=cached_background()
            frame=base.copy() if base is not None else Image.new("RGB",(320,200),(0,0,0))
            for ent in sorted(rt["entities"],key=lambda x:(x.get("z",0),x["id"])):
                composite_entity(frame,ent)
            sw=max(1,int(round(320*scale))); sh=max(1,int(round(200*scale)))
            resample=getattr(getattr(Image,"Resampling",Image),"NEAREST",getattr(Image,"NEAREST",0))
            shown=frame.resize((sw,sh),resample=resample)
            photo=rt.get("canvas_photo")
            if photo is not None:
                try:
                    same_size=(photo.width()==sw and photo.height()==sh)
                except Exception:
                    same_size=False
            else:
                same_size=False
            if same_size and hasattr(photo,"paste"):
                # Reuse the Tk image allocation.  Creating a brand-new
                # PhotoImage every frame is surprisingly expensive on Windows.
                photo.paste(shown)
            else:
                photo=ImageTk.PhotoImage(shown)
                rt["canvas_photo"]=photo
            item=rt.get("canvas_image_item")
            if item is None:
                item=canvas.create_image(ox,oy,anchor="nw",image=photo)
                rt["canvas_image_item"]=item
            else:
                canvas.coords(item,ox,oy)
                if not same_size:canvas.itemconfigure(item,image=photo)
            hud=rt.get("canvas_hud_item")
            if hud is None:
                hud=canvas.create_text(ox+3*scale,oy+3*scale,anchor="nw",fill="#ffffff")
                rt["canvas_hud_item"]=hud
            canvas.coords(hud,ox+3*scale,oy+3*scale)
            canvas.itemconfigure(hud,text=f"TEST PLAY  frame {rt['frame']}  {vars_txt}",font=("Courier",max(7,int(5*scale)),"bold"))

        def update_path(e):
            o=template(e["template"])
            if not o or not e.get("path_active") or not e.get("path_name",getattr(o,"path_name","")):
                return
            pname=e.get("path_name",getattr(o,"path_name",""))
            pth=next((p for p in self.project.paths if p.name==pname and p.level_id==o.scene and p.points),None)
            if not pth:return
            idx=max(0,min(len(pth.points)-1,int(e.get("path_point",0))))
            tx=max(0,min(319,int(pth.points[idx][0]))); ty=max(0,min(199,int(pth.points[idx][1])))
            sp=max(1,min(16,int(pth.speed)))
            if e["x"]<tx:e["x"]=min(tx,e["x"]+sp)
            elif e["x"]>tx:e["x"]=max(tx,e["x"]-sp)
            if e["y"]<ty:e["y"]=min(ty,e["y"]+sp)
            elif e["y"]>ty:e["y"]=max(ty,e["y"]-sp)
            if e["x"]!=tx or e["y"]!=ty:return
            if len(pth.points)<=1:
                if pth.mode=="once":e["path_active"]=False;e["path_done"]=True
                return
            if pth.mode=="once":
                if idx>=len(pth.points)-1:e["path_active"]=False;e["path_done"]=True
                else:e["path_point"]=idx+1
            elif pth.mode=="patrol":
                if e.get("path_dir",1)>0:
                    if idx>=len(pth.points)-1:
                        e["path_dir"]=-1; e["path_point"]=idx-1
                    else:e["path_point"]=idx+1
                else:
                    if idx<=0:
                        e["path_dir"]=1; e["path_point"]=1
                    else:e["path_point"]=idx-1
            else:
                e["path_point"]=(idx+1)%len(pth.points)

        def tick():
            if not rt["running"]:return
            tick_started=time.perf_counter()
            try:
                if not win.winfo_exists():return
            except:return
            for _e in rt["entities"]:
                _e["prev_x"]=_e["x"]; _e["prev_y"]=_e["y"]
            for e in list(rt["entities"]):
                if not e["active"] or e["room"]!=rt["room"]:continue
                o=template(e["template"])
                if not o:continue
                for v in list(o.events):
                    if event_ok(e,v) and condition_ok(e,v):
                        for do in self._event_actions(v):
                            action(e,do)
                update_path(e)
                animate(e)
            render_test_frame()
            rt["last_keys"]=set(rt["keys"]);rt["frame"]+=1
            elapsed_ms=(time.perf_counter()-tick_started)*1000.0
            win.after(max(1,int(round(16.0-elapsed_ms))),tick)

        def stop():
            rt["running"]=False
            try:win.destroy()
            except:pass

        win.protocol("WM_DELETE_WINDOW",stop)
        win.bind("<Escape>",lambda e:stop())
        tick()

    def generate_asm_dialog(self):
        d=filedialog.askdirectory(title="Choose generated game folder")
        if not d:return
        try:
            self._generate_folder(d)
            self.status.set(f"Generated ASM: {d}")
            messagebox.showinfo("Generated","Generated Kick Assembler source, object/logic data, sprite binaries, and build.bat.")
        except Exception as e:
            messagebox.showerror("Generation failed",str(e))

    def browse_kickass(self):
        p=filedialog.askopenfilename(filetypes=[("KickAss.jar","KickAss.jar"),("JAR files","*.jar"),("All files","*.*")])
        if p:self.kickass_var.set(p)

    def build_prg_dialog(self):
        jar=self.kickass_var.get().strip()
        if not jar or not Path(jar).exists():
            return messagebox.showerror("KickAss.jar","Select KickAss.jar in the Build tab first.")
        d=filedialog.askdirectory(title="Choose build output folder")
        if not d:return
        try:
            d=self._generate_folder(d)
            p=subprocess.run(["java","-jar",jar,"game.asm","-o","game.prg"],cwd=d,text=True,capture_output=True)
            self.build_log.delete("1.0","end")
            self.build_log.insert("end",(p.stdout or "")+(p.stderr or ""))
            if p.returncode==0:messagebox.showinfo("Build complete",f"Created {Path(d)/'game.prg'}")
            else:messagebox.showerror("Build failed","Kick Assembler returned an error. See Build log.")
        except Exception as e:
            messagebox.showerror("Build failed",str(e))

if __name__=="__main__":
    App().mainloop()
