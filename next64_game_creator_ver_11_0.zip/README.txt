Next64 Studios C64 Game Creator VER 11.0

VER 11.0 persistent tile-based inventory update
================================================
- Adds a dedicated Inventory workspace with 1-32 persistent slots.
- Define item IDs, names, icon tile IDs, and maximum stack quantities.
- Configure initial item/quantity contents and the initially selected slot.
- Configure an inventory display room, starting tile cell, column count, and empty-slot tile.
- Adds Visual Logic conditions: Inventory Contains Item, Inventory Slot Equals, and Inventory Quantity At Least.
- Adds Visual Logic actions: Add/Remove/Use Inventory Item, Move Inventory Slot, Set Selected Inventory Slot, and Render Inventory Tiles.
- Generated C64 projects include persistent item and quantity arrays plus stacking, removal, slot swapping, selection, lookup, and tile-grid rendering routines.
- Test Play mirrors the inventory operations and tile renderer and shows the selected slot in its HUD.
- Inventory state remains intact across room changes.

The VER 10.0 integrated tile editor and all VER 09.12 runtime fixes remain included below.

VER 10.0 integrated tile-editor major update
============================================
- Adds a dedicated Tiles workspace based on the Sky Strike Level Editor VER 11.2 tile studio.
- Create and resize per-level hires or multicolor tilesets.
- Paint and erase C64-constrained tile pixels with Background, MC1, MC2, and Local values.
- Add, duplicate, delete, and clear tiles; deleted IDs are safely remapped in room tilemaps.
- Load a PNG into an individual tile and save the selected tile as PNG.
- Existing tile-sheet and Sky Strike ASM import remain available from both Tiles and Rooms.
- Tile edits immediately feed the Room preview, collision/property data, save format, test play, and ASM export.
- Software-to-VIC conversion now warns about fixed 24x21 geometry, artwork loss, and collision overlap.
- The recommended Duplicate and Convert option preserves the original software sprite.

The previous VER 09.12 runtime input/render reliability work remains included below.

VER 09.12 runtime input/render reliability update
- C64 W/A/S/D/SPACE input keeps the direct CIA1 matrix scan and now merges an independent KERNAL SCNKEY result into the same cached key state. This provides a reliable fallback in VICE/real-C64 environments while retaining multi-key support from the direct scan.
- Added generic Visual Logic action: Apply Queued Direction. Use one P property for current direction and another for requested direction; at a tile intersection the requested direction is adopted only when the tile ahead is not Solid.
- Maze-chase example now queues W/A/S/D immediately into P1 and applies P1 to P0 at valid intersections.
- Software-rendered hires sprites now set their foreground screen-RAM color from the sprite local color instead of appearing only black/white.
- VIC-II live sprite register updates are committed atomically with interrupts held during slot collection/sort/commit, so live object X/Y changes cannot be split by an IRQ during the refresh.
- Existing freeze, tile-render, software dirty-rectangle, and Test Play performance fixes remain intact.
- Golf Solitaire, Galaga-style, pathing, and maze-chase editable examples are retained.

Kick Assembler is required to compile generated ASM into a .prg. KickAss.jar is not bundled.
